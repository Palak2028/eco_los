import 'dart:async';
import 'package:eco_los/Utilities/globals.dart';
import 'package:eco_los/pages/workflow/SystemParameter/SystemParameterBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/CustomerFormationBusinessCashFlow3.dart';
import 'package:eco_los/pages/workflow/customerFormation/FullScreenDialogForMainOccupationSelection.dart';
import 'package:eco_los/pages/workflow/customerFormation/FullScreenDialogForSubOccupationSelection.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/AddressDetailsBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/AssetDetailsBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/BorrowingDetailsBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/BusinessExpenditureDetailsBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/CurrentAssetsBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/CustomerBusinessDetailsBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/CustomerListBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/ESMSBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/EquityBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/FamilyDetailsBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/FinancialStmntBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/FixedAssetsBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/HouseholdExpenditureDetailsBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/ImageBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/IncomeStatementBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/LongTermLiabilitiesBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/RiskRatingsBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/ShortTermLiabilitiesBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/TotalExpenditureDetailsBean.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:eco_los/Utilities/app_constant.dart' as constantResource;
import 'package:eco_los/Utilities/app_constant.dart';
import 'package:eco_los/db/AppDatabase.dart';
import 'package:eco_los/db/TablesColumnFile.dart';
import 'package:eco_los/pages/workflow/GroupFormation/FullScreenDialogForGroupSelection.dart';
import 'package:eco_los/pages/workflow/LoanApplication/FullScreenDialogForProductSelection.dart';
import 'package:eco_los/pages/workflow/LoanApplication/FullScreenDialogForPurposeSelection.dart';
import 'package:eco_los/pages/workflow/LoanApplication/List/CustomerLoanDetailsList.dart';
import 'package:eco_los/pages/workflow/LoanApplication/bean/CustomerLoanDetailsBean.dart';
import 'package:eco_los/pages/workflow/LoanApplication/bean/Product.dart';
import 'package:eco_los/pages/workflow/LoanApplication/bean/RepaymentFrequency.dart';
import 'package:eco_los/pages/workflow/LoanApplication/bean/TransactionMode.dart';
import 'package:eco_los/pages/workflow/LoanApplication/bean/PurposeOfLoan.dart';
import 'package:eco_los/pages/workflow/LookupMasterBean.dart';
import 'package:eco_los/pages/workflow/centerfoundation/FullScreenDialogForCenterSelection.dart';
import 'package:eco_los/Utilities/globals.dart' as globals;
import 'package:eco_los/pages/workflow/customerFormation/List/CustomerList.dart';
import 'package:eco_los/pages/workflow/statusDetails/CCGTab.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../translations.dart';
import 'FullScreenDialogForHbsUsers.dart';
import 'bean/HbsUserBean.dart';

class LoanLimitDetails extends StatefulWidget {
  final laonLimitPassedObject;
  LoanLimitDetails({Key key, this.laonLimitPassedObject}) : super(key: key);

  static Container _get(Widget child,
      [EdgeInsets pad = const EdgeInsets.all(6.0)]) =>
      new Container(
        padding: pad,
        child: child,
      );

  @override
  _LoanLimitDetailsState createState() => new _LoanLimitDetailsState();
}

class _LoanLimitDetailsState extends State<LoanLimitDetails> {
  FullScreenDialogForCenterSelection _myCenterDialog =
      new FullScreenDialogForCenterSelection();
  FullScreenDialogForGroupSelection _myGroupDialog =
      new FullScreenDialogForGroupSelection();

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final GlobalKey<FormState> _formKey = new GlobalKey<FormState>();
  TabController _tabController;
  ProductBean prodObj = new ProductBean();
  SubLookupForSubPurposeOfLoan purposeObj = new SubLookupForSubPurposeOfLoan();
  TransactionMode transObj = new TransactionMode();
  RepaymentFrequency RepayFreqObj = new RepaymentFrequency();
  SystemParameterBean sysBean = new SystemParameterBean();
  List isMemberOfGroupListLoan = [0];
  String mIsGroupLendingNeeded = "Y";
  bool isMemeberOfGroupForLoan = true;
  String multiplePurposeDesc = "";
  String multiplePurposeCode = "";

  SubLookupForSubPurposeOfLoan mainOcc = new SubLookupForSubPurposeOfLoan();
  SubLookupForSubPurposeOfLoan subOcc = new SubLookupForSubPurposeOfLoan();
  final formatDouble = new NumberFormat("#,##0.00", "en_US");

  double rateOfInterest;
  String purposeName = "";
  int purposeId = null;
  String subPurposeName = "";
  String subPurposeId;
  String disbursmentMode = "";
  int disbursmentModeId = null;
  String collectionMode = "";
  int collectionModeId = null;
  double canApplyMaxAmount = 0.0;
  double canApplyMaxInst = 0.0;
  LookupBeanData frequency;
  LookupBeanData repaymentmode;
  LookupBeanData modeofdisb;
  LookupBeanData purpose;

  DateTime selectedDate = DateTime.now();
  //final dateFormat = DateFormat("EEEE, MMMM d, yyyy");
  DateTime date;
  TimeOfDay time;
  //final dateFormat = DateFormat("yyyy/MM/dd");
  var formatter = new DateFormat('dd-MM-yyyy');
  String tempDate = "----/--/--";
  String tempYear;
  String tempDay;
  String tempMonth;
  bool boolValidate = false;
  int loanCycle = 0;
  int loanNumber;
  int branch;
  SharedPreferences prefs;
  String loginTime;
  int usrGrpCode = 0;
  String username;
  String usrRole;
  String geoLocation;
  String geoLatitude;
  String geoLongitude;
  String reportingUser;
  String loanDisbDt = "__-__-____";
  String loaninstStrtDt = "__-__-____";
  FocusNode monthFocus;
  FocusNode yearFocus;
  FocusNode monthInstStrtFocus;
  FocusNode yearInstStrtFocus;
  String tempInstStrtDate = "----/--/--";
  String tempInstStrtYear;
  String tempInstStrtDay;
  String tempInstStrtMonth;
  int mgrpID;
  CustomerLoanDetailsBean cusLoanObj = new CustomerLoanDetailsBean();
  @override
  void initState() {
    super.initState();
    //select amout salb based on tier field from customer
    if(widget.laonLimitPassedObject!=null){
      cusLoanObj = widget.laonLimitPassedObject;
      loanDisbDt = cusLoanObj.mloandisbdt.toString();
      loaninstStrtDt =cusLoanObj.minststrtdt.toString();
      //getSubpurposeOnEditMode();

    }
    else{
      cusLoanObj.mappliedasind =  '0';
    }
    getSessionVariables();
    //bhawpriya

    monthFocus = new FocusNode();
    yearFocus = new FocusNode();
    monthInstStrtFocus = new FocusNode();
    yearInstStrtFocus = new FocusNode();
      List<String> tempDropDownValues = new List<String>();
    tempDropDownValues.add(cusLoanObj.mpurposeofLoan.toString());
    tempDropDownValues.add(cusLoanObj.mfrequency);
    tempDropDownValues.add(cusLoanObj.mrepaymentmode.toString());
    tempDropDownValues.add(cusLoanObj.mmodeofdisb.toString());

    if (!loanDisbDt.contains("_")) {
      try {
        DateTime formattedDate = DateTime.parse(loanDisbDt);
        tempDay = formattedDate.day.toString();
        tempMonth = formattedDate.month.toString();
        tempYear = formattedDate.year.toString();
        loanDisbDt = tempDay.toString() +"-"+tempMonth.toString()+"-"+tempYear.toString();
        setState(() {});
      } catch (e) {
        print("Exception Occupred");
      }
    }
    if (!loaninstStrtDt.contains("_")) {
      try {
        DateTime formattedDate = DateTime.parse(loaninstStrtDt);
        tempInstStrtDay = formattedDate.day.toString();
        tempInstStrtMonth = formattedDate.month.toString();
        tempInstStrtYear = formattedDate.year.toString();
        loaninstStrtDt = tempInstStrtDay.toString() +"-"+tempInstStrtMonth.toString()+"-"+tempInstStrtYear.toString();
        setState(() {});
      } catch (e) {
        print("Exception Occupred");
      }
    }

    for (int k = 0;
    k < globals.dropdownCaptionsValuesCustLoanDetailsInfo.length;
    k++) {
      for (int i = 0;
      i < globals.dropdownCaptionsValuesCustLoanDetailsInfo[k].length;
      i++) {
        if (globals.dropdownCaptionsValuesCustLoanDetailsInfo[k][i].mcode ==
            tempDropDownValues[k]) {
          setValue(k, globals.dropdownCaptionsValuesCustLoanDetailsInfo[k][i]);
        }
      }
    }
    if (globals.applicationDate == null) {
      globals.applicationDate = DateTime.now();
    }
    //  cusLoanObj.customerNumber = custListObj.customerNumber;
    if (widget.laonLimitPassedObject != null) {
      cusLoanObj = widget.laonLimitPassedObject;
    } else {
      AppDatabase.get().getMaxCustomerLoanNumber().then((val) {
        setState(() {
          cusLoanObj.trefno = val;
        });

        //beanObj.segmentIdentifier;
      });
    }
  }
/*Future<Null> getSubpurposeOnEditMode()async{
  await AppDatabase.get()
      .getSunPurposeOfLoanListFromSubLookpTable(4000,cusLoanObj.mpurposeofLoan)
      .then((List<SubLookupForSubPurposeOfLoan> response){
    for(int subPurpose =0;subPurpose<response.length;subPurpose++){
      if(response[subPurpose].code!=null && cusLoanObj.msubpurposeofloan!=null) {
        if (response[subPurpose].code.trim() ==
            cusLoanObj.msubpurposeofloan.toString()) {
          cusLoanObj.msubpurposeofloandesc = response[subPurpose].codeDesc;
          break;
        }
      }
    }
  });
}*/
  Future<Null> getSessionVariables() async {
    prefs = await SharedPreferences.getInstance();
    setState(() {
      branch = prefs.get(TablesColumnFile.musrbrcode);
      reportingUser = prefs.getString(TablesColumnFile.mreportinguser);
      username = prefs.getString(TablesColumnFile.musrcode);
      usrRole = prefs.getString(TablesColumnFile.musrdesignation);
      usrGrpCode = prefs.getInt(TablesColumnFile.mgrpcd);
      loginTime = prefs.getString(TablesColumnFile.LoginTime);
      geoLocation = prefs.getString(TablesColumnFile.geoLocation);
      geoLatitude = prefs.get(TablesColumnFile.geoLatitude).toString();
      geoLongitude = prefs.get(TablesColumnFile.geoLongitude).toString();

      if (prefs.getString(TablesColumnFile.mIsGroupLendingNeeded) != null &&
          prefs.getString(TablesColumnFile.mIsGroupLendingNeeded).trim() !=
              "") {
        mIsGroupLendingNeeded =
            prefs.getString(TablesColumnFile.mIsGroupLendingNeeded);

        if (mIsGroupLendingNeeded != null &&
            mIsGroupLendingNeeded.trim().toUpperCase() == 'N') {
          isMemeberOfGroupForLoan = false;
        }
      }
      print(prefs.getString(TablesColumnFile.mIsGroupLendingNeeded));
    });
  }

  //LookupBeanData blankBean = new LookupBeanData(codeDesc: "",code: "",codeType: 0);

  List<DropdownMenuItem<LookupBeanData>> generateDropDown(int no) {
    List<DropdownMenuItem<LookupBeanData>> _dropDownMenuItems1;
    List<LookupBeanData> mapData = List<LookupBeanData>();
    LookupBeanData bean = new LookupBeanData();
    bean.mcodedesc = "";
    mapData.add(blankBean);
    for (int k = 0;
        k < globals.dropdownCaptionsValuesCustLoanDetailsInfo[no].length;
        k++) {
      mapData.add(globals.dropdownCaptionsValuesCustLoanDetailsInfo[no][k]);
    }
    _dropDownMenuItems1 = mapData.map((value) {
         return new DropdownMenuItem<LookupBeanData>(
        value: value,
        child: new Text(value.mcodedesc),
      );
    }).toList();

    return _dropDownMenuItems1;
  }

  void _onClick() {
    Navigator.push(
      context,
      new MaterialPageRoute(
          builder: (context) =>
              // new LoanLimitDetails()), //When Authorized Navigate to the next screen
              new CCGTab(cusLoanObj.mleadstatus, cusLoanObj.trefno)),
    );
  }

  showDropDown(LookupBeanData selectedObj, int no) {

      if (selectedObj.mcodedesc.isEmpty) {

      switch (no) {
        case 0:
          purpose = blankBean;
          cusLoanObj.mpurposeofLoan = 0;
          break;
        case 1:
          frequency = blankBean;
          cusLoanObj.mfrequency = blankBean.mcode;
          break;
        case 2:
          repaymentmode = blankBean;
          cusLoanObj.mrepaymentmode = 0;
          break;
        case 3:
          modeofdisb = blankBean;
          cusLoanObj.mmodeofdisb = 0;
          break;
        default:
          break;
      }
      setState(() {});
    } else {
      bool isBreak = false;
      for (int k = 0;
          k < globals.dropdownCaptionsValuesCustLoanDetailsInfo[no].length;
          k++) {

        if (globals.dropdownCaptionsValuesCustLoanDetailsInfo[no][k].mcodedesc
                .trim() ==
            selectedObj.mcodedesc.trim()) {
          setValue(no, selectedObj);
          isBreak = true;
          break;
        }
        if (isBreak) {
          break;
        }
      }
    }
  }

  setValue(int no, LookupBeanData value) async{
    setState(() {

      switch (no) {
        case 0:

          purpose = value;
          cusLoanObj.mpurposeofLoan = int.parse(value.mcode);
          if(widget.laonLimitPassedObject==null) {

          }

          break;
        case 1:

          frequency = value;
          cusLoanObj.mfrequency = value.mcode;

          break;
        case 2:
          repaymentmode = value;
          cusLoanObj.mrepaymentmode = int.parse(value.mcode);
          break;
        case 3:
          modeofdisb = value;
          cusLoanObj.mmodeofdisb = int.parse(value.mcode);
          break;
        default:
          break;
      }
    });

    if (cusLoanObj.mprdcd != null && cusLoanObj.mloancycle !=null &&
        cusLoanObj.mfrequency != null && branch!=null&&branch > 0){


      await AppDatabase.get()
          .selectMaxLoanAmtCanApply(
          cusLoanObj.mprdcd.trim().toString(),
          cusLoanObj.mloancycle+1,
          branch,
          cusLoanObj.mfrequency)
          .then((onValue) {

        for(int secondLoanCycle = 0;secondLoanCycle<onValue.length;secondLoanCycle++){
          if(onValue[secondLoanCycle].mruletype ==1){
            canApplyMaxAmount = onValue[secondLoanCycle].mmaxamount;
          }else if(onValue[secondLoanCycle].mruletype ==2)
            canApplyMaxInst  = onValue[secondLoanCycle].mmaxamount;
        }
        setState(() {

        });
      });
    }
  }

  LookupBeanData blankBean =
      new LookupBeanData(mcodedesc: "", mcode: "", mcodetype: 0);

  Widget getTextContainer(String textValue) {
    return new Container(
      padding: EdgeInsets.fromLTRB(5.0, 20.0, 0.0, 20.0),
      child: new Text(
        textValue,
        //textDirection: TextDirection,
        textAlign: TextAlign.start,
        /*overflow: TextOverflow.ellipsis,*/
        style: new TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.grey,
            fontStyle: FontStyle.normal,
            fontSize: 12.0),
      ),
    );
  }

  Widget groupLending() => LoanLimitDetails._get(new Row(
    children: _makeRadios(2, globals.radioCaptionValuesIsMemberOfGroup, 0),
    mainAxisAlignment: MainAxisAlignment.spaceAround,
  ));

  List<Widget> _makeRadios(int numberOfRadios, List textName, int position) {
    List<Widget> radios = new List<Widget>();
    for (int i = 0; i < numberOfRadios; i++) {
      radios.add(new Row(
        children: <Widget>[
          new Text(
            textName[i],
            textAlign: TextAlign.right,
            style: new TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey,
              fontStyle: FontStyle.normal,
              fontSize: 10.0,
            ),
          ),
          new Radio(
            value: i,
            groupValue: cusLoanObj.mappliedasind==null || cusLoanObj.mappliedasind=='null'?0:int.parse(cusLoanObj.mappliedasind) ,
            onChanged: (selection) {
              if (mgrpID != null &&
                  mgrpID == 0) {
                return null;
              }
              return _onRadioSelected(selection, position);
            },
            activeColor: Color(0xff07426A),
          ),
        ],
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
      ));
    }
    return radios;
  }

  _onRadioSelected(int selection, int position) {
    cusLoanObj.mprdname ="";
    cusLoanObj.mprdcd ="";
    setState(() => cusLoanObj.mappliedasind = selection.toString());
    if (position == 0) {      
      if (globals.radioCaptionValuesIsMemberOfGroup[selection] == 'Yes') {
        isMemeberOfGroupForLoan = true;
      } else {
        isMemeberOfGroupForLoan = false;
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomPadding: false,
      appBar: new AppBar(
        elevation: 1.0,
        leading: new IconButton(
          icon: new Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        backgroundColor: Color(0xff07426A),
        brightness: Brightness.light,
        title: new Text(
          'Loan Application',
          //textDirection: TextDirection,
          textAlign: TextAlign.center,
          overflow: TextOverflow.ellipsis,
          style: new TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.white,
              fontStyle: FontStyle.normal),
        ),
        actions: <Widget>[
          new IconButton(
            icon: new Icon(
              Icons.save,
              color: Colors.white,
              size: 40.0,
            ),
            onPressed: () {
              /* if(!validateSubmit()){

              }else{*/
              proceed();
              // }
            },
          ),
         /* new IconButton(
            icon: new Icon(
              Icons.border_color,
              color: Colors.white,
              size: 40.0,
            ),
            tooltip: 'Repair it',
            onPressed: () {
              _onClick();
              // }
            },
          ),*/
          new Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5.0),
          ),
        ],
      ),
      body: new Form(
        key: _formKey,
        autovalidate: false,
        onWillPop: () {
          return Future(() => true);
        },
        onChanged: () async {
          final FormState form = _formKey.currentState;
          form.save();
          await calculate();
          setState(() {});
        },
        child: ListView(
          shrinkWrap: true,
          padding: EdgeInsets.all(0.0),
          children: <Widget>[
            new Card(
              child: new ListTile(
                title: new Text("Loan Tablet Ref Number"),
                subtitle: new Text("${cusLoanObj.trefno}"),
              ),
            ),
            new Card(
              child: new ListTile(
                  title: new Text("Customer Number And Name"),
                  subtitle: cusLoanObj.mcustno == null
                      ? new Text("")
                      : new Text(
                          "${cusLoanObj.mcustno.toString() + " " + cusLoanObj.mcustname.toString()}"),
                  onTap: () => getCustomerNumber()),
            ),
            mIsGroupLendingNeeded == "Y"
                ? new Card(
                child:new Table(children: [
              new TableRow(
                  decoration: new BoxDecoration(
                    border: Border.all(color: Colors.grey, width: 0.1),
                  ),
                  children: [
                    getTextContainer(
                        globals.radioCaptionAppliedAsInd[0]),
                    groupLending(),
                  ]),
            ]))
                : Container(),

            cusLoanObj !=null && cusLoanObj.mcusttrefno !=null && cusLoanObj.mcusttrefno>0? new Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                new RaisedButton(
                  onPressed:  () async{
                    await addCashFlow(cusLoanObj);
                  },
                  child: const Text('Add Cashflow'),
                  color: Colors.green,
                ),

              ],
            ):Container(),


            new Card(
              child: new ListTile(
                title: new Text("Product"),
                subtitle: cusLoanObj.mprdname == null && cusLoanObj.mprdcd == null
                    ? new Text("")
                    : new Text("${cusLoanObj.mprdname.trim() == null || cusLoanObj.mprdname.trim() == 'null' ? "" : cusLoanObj.mprdname.trim()}/${cusLoanObj.mprdcd.trim()}"),
                onTap: getProduct,
              ),
            ),
           new Card(
              child: new ListTile(
                  title: new Text("Purpose Of Loan"),
                  subtitle: cusLoanObj.msubpurposeofloandesc == null
                      ? new Text("")
                      : new Container (
                   // height: 75.0,
                    child: new Row (
                      children: [
                        new Expanded(
                          child: new Text (cusLoanObj.msubpurposeofloandesc.toString()!=null&& cusLoanObj.msubpurposeofloandesc.toString()!="" && cusLoanObj.msubpurposeofloandesc.toString()!="null"?cusLoanObj.msubpurposeofloandesc.toString():'',
                            style: TextStyle(
                                fontSize: 20.0, color: Colors.black),
                          ),
                        ),
                      ],
                    ),
                    decoration: new BoxDecoration (
                      // backgroundColor: Colors.grey[300],
                    ),
                    width: 400.0,
                  ),
                  onTap: () => getPurpose("purpose",1)),
            ),

            new Card(
              child: new ListTile(
                  title: new Text("Industry"),
                  subtitle: cusLoanObj.mmainoccupn == null
                      ? new Text("")
                      : new Text("Industry : ${cusLoanObj.mmainoccupndesc}   And Code : ${cusLoanObj.mmainoccupn}"),
                  onTap: () => getMainOccupation("Industry",0)),
            ),
            new Card(
              child: new ListTile(
                  title: new Text("Sector"),
                  subtitle: cusLoanObj.msuboccupn == null
                      ? new Text("")
                      : new Text("Sector : ${cusLoanObj.msuboccupndesc}   And Code : ${cusLoanObj.msuboccupn}"),
                  onTap: () => getSubOccupation("Sector",
                      int.parse(cusLoanObj.mmainoccupn != null ? cusLoanObj.mmainoccupn : 0))),
            ),
            new Card(
              child: new ListTile(
                  title: new Text("HBS USER"),
                  subtitle: cusLoanObj.mrouteto == null
                      ? new Text("")
                      : new Text("User Code : ${cusLoanObj.mrouteto}"),
                  onTap: () => getHbsUser()),
            ),
            new Card(
              child: new DropdownButtonFormField(
                value: frequency,
                items: generateDropDown(1),
                onChanged: (LookupBeanData newValue) {
                  showDropDown(newValue, 1);
                },
                validator: (args) {

                },
                decoration: const InputDecoration(
                  hintText: 'Select Repayment Type Of loan',
                  labelText: 'Repayment Type Of loan',
                  hintStyle: TextStyle(color: Colors.grey),
                  labelStyle: TextStyle(color: Colors.grey),
                  border: UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                      )),
                  focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                      )),
                  contentPadding: EdgeInsets.all(20.0),
                ),
              ),

            ),
            new Column(
              children: <Widget>[
               /* new TextFormField(
                  enabled: false,
                  decoration: const InputDecoration(
                    //  hintText: 'Enter Applied Amount',
                    labelText: constantResource.maxAmountApply,
                    hintStyle: TextStyle(color: Colors.grey),
                    labelStyle: TextStyle(color: Colors.grey),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                      color: Colors.black,
                    )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                      color: Colors.black,
                    )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),
                  initialValue: canApplyMaxAmount == null
                      ? ""
                      : canApplyMaxAmount.toString(),
                ), */

               /* new Card(
                  child: new ListTile(
                      title: new Text(constantResource.maxAmountApply),
                      subtitle: canApplyMaxAmount == null
                          ? new Text("")
                          : new Text("${formatDouble.format(canApplyMaxAmount)}")),
                ),*/

               /* new TextFormField(
                  enabled: false,
                  decoration: const InputDecoration(
                    //  hintText: 'Enter Applied Amount',
                    labelText: constantResource.maxInstApply,
                    hintStyle: TextStyle(color: Colors.grey),
                    labelStyle: TextStyle(color: Colors.grey),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),
                  initialValue: canApplyMaxInst == null
                      ? ""
                      : canApplyMaxInst.toString(),
                ),*/

               /* new Card(
                  child: new ListTile(
                      title: new Text(constantResource.maxInstApply),
                      subtitle: canApplyMaxInst == null
                          ? new Text("")
                          : new Text("${canApplyMaxInst}")),
                ),*/

                new TextFormField(
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      hintText: 'Enter Applied Amount',
                      labelText: 'Applied Amount',
                      hintStyle: TextStyle(color: Colors.grey),
                      labelStyle: TextStyle(color: Colors.grey),
                      border: UnderlineInputBorder(
                          borderSide: BorderSide(
                        color: Colors.black,
                      )),
                      focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                        color: Colors.black,
                      )),
                      contentPadding: EdgeInsets.all(20.0),
                    ),
                    initialValue: cusLoanObj.mappldloanamt == null
                        ? ""
                        : cusLoanObj.mappldloanamt.toString(),
                    onSaved: (String value) {

                      if (value.isNotEmpty &&
                          value != "" &&
                          value != null &&
                          value != 'null') {
                        cusLoanObj.mappldloanamt = double.parse(value);
                      }
                      cusLoanObj.mloanamtdisbd = cusLoanObj.mappldloanamt;
                      cusLoanObj.mapprvdloanamt = cusLoanObj.mappldloanamt;
                    }),

              ],
            ),
            SizedBox(
              height: 20.0,
            ),
            Container(
              decoration: BoxDecoration(),
              child: new Row(
                children: <Widget>[Text(Constant.loandisbdt)],
              ),
            ),
            new Container(
              decoration: BoxDecoration(),
              child: new Row(
                children: <Widget>[
                  new Container(
                    width: 50.0,
                    child: new TextField(
                        decoration: InputDecoration(hintText: "DD"),
                        inputFormatters: [
                          new LengthLimitingTextInputFormatter(2),
                          globals.onlyIntNumber
                        ],
                        controller: tempDay == null
                            ? null
                            : new TextEditingController(text: tempDay),
                        keyboardType: TextInputType.numberWithOptions(),
                        onChanged: (val) {
                          if (val != "0") {
                            tempDay = val;

                            if (int.parse(val) <= 31 && int.parse(val) > 0) {
                              if (val.length == 2) {
                                loanDisbDt = loanDisbDt.replaceRange(0, 2, val);
                                FocusScope.of(context).requestFocus(monthFocus);
                              } else {
                                loanDisbDt =
                                    loanDisbDt.replaceRange(0, 2, "0" + val);
                              }
                            } else {
                              setState(() {
                                tempDay = "";
                              });
                            }
                          }
                        }),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: new Text("/"),
                  ),
                  new Container(
                    width: 50.0,
                    child: new TextField(
                      decoration: InputDecoration(
                        hintText: "MM",
                      ),
                      keyboardType: TextInputType.numberWithOptions(),
                      inputFormatters: [
                        new LengthLimitingTextInputFormatter(2),
                        globals.onlyIntNumber
                      ],
                      focusNode: monthFocus,
                      controller: tempMonth == null
                          ? null
                          : new TextEditingController(text: tempMonth),
                      onChanged: (val) {
                        if (val != "0") {
                          tempMonth = val;
                          if (int.parse(val) <= 12 && int.parse(val) > 0) {
                            if (val.length == 2) {
                              loanDisbDt = loanDisbDt.replaceRange(3, 5, val);

                              FocusScope.of(context).requestFocus(yearFocus);
                            } else {
                              loanDisbDt =
                                  loanDisbDt.replaceRange(3, 5, "0" + val);
                            }
                          } else {
                            setState(() {
                              tempMonth = "";
                            });
                          }
                        }
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: new Text("/"),
                  ),
                  Container(
                    width: 80,
                    child: new TextField(
                      decoration: InputDecoration(
                        hintText: "YYYY",
                      ),
                      keyboardType: TextInputType.numberWithOptions(),
                      inputFormatters: [
                        new LengthLimitingTextInputFormatter(4),
                        globals.onlyIntNumber
                      ],
                      focusNode: yearFocus,
                      controller: tempYear == null
                          ? null
                          : new TextEditingController(text: tempYear),
                      onChanged: (val) {
                        tempYear = val;
                        if (val.length == 4)
                          loanDisbDt = loanDisbDt.replaceRange(6, 10, val);
                      },
                    ),
                  ),
                  SizedBox(
                    width: 50.0,
                  ),
                  IconButton(
                      icon: Icon(Icons.calendar_today),
                      onPressed: () {
                        _selectDisDtDate(context);
                      })
                ],
              ),
            ),
//loanstart dt
            SizedBox(height: 20.0,),
            Container(
              decoration: BoxDecoration(),
              child: new Row(
                children: <Widget>[Text(Constant.loaninstStrtDt)],
              ),
            ),
            new Container(
              decoration: BoxDecoration(),
              child: new Row(
                children: <Widget>[
                  new Container(
                    width: 50.0,
                    child: new TextField(
                        decoration: InputDecoration(hintText: "DD"),
                        inputFormatters: [
                          new LengthLimitingTextInputFormatter(2),
                          globals.onlyIntNumber
                        ],
                        controller: tempInstStrtDay == null
                            ? null
                            : new TextEditingController(text: tempInstStrtDay),
                        keyboardType: TextInputType.numberWithOptions(),
                        onChanged: (val) {
                          if (val != "0") {
                            tempInstStrtDay = val;

                            if (int.parse(val) <= 31 && int.parse(val) > 0) {
                              if (val.length == 2) {
                                loaninstStrtDt = loaninstStrtDt.replaceRange(0, 2, val);
                                FocusScope.of(context).requestFocus(monthInstStrtFocus);
                              } else {
                                loaninstStrtDt =
                                    loaninstStrtDt.replaceRange(0, 2, "0" + val);
                              }
                            } else {
                              setState(() {
                                tempInstStrtDay = "";
                              });
                            }
                          }
                        }),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: new Text("/"),
                  ),
                  new Container(
                    width: 50.0,
                    child: new TextField(
                      decoration: InputDecoration(
                        hintText: "MM",
                      ),
                      keyboardType: TextInputType.numberWithOptions(),
                      inputFormatters: [
                        new LengthLimitingTextInputFormatter(2),
                        globals.onlyIntNumber
                      ],
                      focusNode: monthInstStrtFocus,
                      controller: tempInstStrtMonth == null
                          ? null
                          : new TextEditingController(text: tempInstStrtMonth),
                      onChanged: (val) {
                        if (val != "0") {
                          tempInstStrtMonth = val;
                          if (int.parse(val) <= 12 && int.parse(val) > 0) {
                            if (val.length == 2) {
                              loaninstStrtDt = loaninstStrtDt.replaceRange(3, 5, val);

                              FocusScope.of(context).requestFocus(yearInstStrtFocus);
                            } else {
                              loaninstStrtDt =
                                  loaninstStrtDt.replaceRange(3, 5, "0" + val);
                            }
                          } else {
                            setState(() {
                              tempInstStrtMonth = "";
                            });
                          }
                        }
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: new Text("/"),
                  ),
                  Container(
                    width: 80,
                    child: new TextField(
                      decoration: InputDecoration(
                        hintText: "YYYY",
                      ),
                      keyboardType: TextInputType.numberWithOptions(),
                      inputFormatters: [
                        new LengthLimitingTextInputFormatter(4),
                        globals.onlyIntNumber
                      ],
                      focusNode: yearInstStrtFocus,
                      controller: tempInstStrtYear == null
                          ? null
                          : new TextEditingController(text: tempInstStrtYear),
                      onChanged: (val) {
                        tempInstStrtYear = val;
                        if (val.length == 4)
                          loaninstStrtDt =  loaninstStrtDt.replaceRange(6, 10, val);

                      },

                    ),
                  ),
                  SizedBox(
                    width: 50.0,
                  ),
                  IconButton(
                      icon: Icon(Icons.calendar_today),
                      onPressed: () {
                        _selectStrtDtDate(context);
                      })
                ],
              ),
            ),

            //ends
            new TextFormField(
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  hintText: 'Enter Tenors(In Months)',
                  labelText: 'Tenors(In Months)',
                  hintStyle: TextStyle(color: Colors.grey),
                  labelStyle: TextStyle(color: Colors.grey),
                  border: UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                      )),
                  focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                      )),
                  contentPadding: EdgeInsets.all(20.0),
                ),
                initialValue:
                cusLoanObj.mperiod == null ? "" : "${cusLoanObj.mperiod}",
                validator: (String value) {
                  if (RegExp(r'[!@#<>?":_`~;[\]\\|=+)(*&^%0-9-]')
                      .hasMatch(value)) {
                    return "no special character allowed";
                  } else
                    return null;
                },
                onSaved: (String value) {
                  if (value.isNotEmpty &&
                      value != "" &&
                      value != null &&
                      value != 'null') {
                    cusLoanObj.mperiod = int.parse(value);
                  }
                }),


            new Card(
              child: new ListTile(
                title: new Text("Rate Of Interest"),
                subtitle: cusLoanObj.mintrate == null
                    ? new Text("")
                    : new Text("${cusLoanObj.mintrate}"),
              ),
            ),

            new Card(
              child: new ListTile(
                  title: new Text("Loan End Date"),
                  subtitle: cusLoanObj.mexpdt == null
                      ? new Text("")
                      : new Text("${formatter.format(cusLoanObj.mexpdt)}")),
            ),
            new Card(
              child: new ListTile(
                title: new Text("Interest Amount"),
                subtitle: cusLoanObj.minterestamount == null
                    ? new Text("")
                    : new Text("${formatDouble.format(cusLoanObj.minterestamount)}"),
              ),
            ),

            new Card(
              child: new ListTile(
                title: new Text("Instalment Amount"),
                subtitle: cusLoanObj.minstamt == null
                    ? new Text("")
                    : new Text("${formatDouble.format(cusLoanObj.minstamt)}"),
              ),
            ),
            new Card(
              child: new ListTile(
                title: new Text("Approved Amount"),
                subtitle: cusLoanObj.mapprvdloanamt == null
                    ? new Text("")
                    : new Text("${formatDouble.format(cusLoanObj.mapprvdloanamt)}"),
              ),
            ),
            new Card(
              child: new ListTile(
                title: new Text("Disbursment Amount"),
                subtitle: cusLoanObj.mloanamtdisbd == null
                    ? new Text("")
                    : new Text("${formatDouble.format(cusLoanObj.mloanamtdisbd)}"),
              ),
            ),
            new Card(
              child: new DropdownButtonFormField(
                value: repaymentmode,
                items: generateDropDown(2),
                onChanged: (LookupBeanData newValue) {
                  showDropDown(newValue, 2);
                },
                validator: (args) {

                },
                decoration: const InputDecoration(
                  isDense: true,
                  hintText: 'Select Mode Of Collection',
                  labelText: 'Mode Of Collection',
                  hintStyle: TextStyle(color: Colors.grey),
                  labelStyle: TextStyle(color: Colors.grey),
                  border: UnderlineInputBorder(
                      borderSide: BorderSide(
                    color: Colors.black,
                  )),
                  focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                    color: Colors.black,
                  )),
                  contentPadding: EdgeInsets.all(20.0),
                ),
              ),
            ),
            new Card(
              child: new Card(
                child: new DropdownButtonFormField(
                  value: modeofdisb,
                  items: generateDropDown(3),
                  onChanged: (LookupBeanData newValue) {
                    showDropDown(newValue, 3);
                  },
                  validator: (args) {

                  },
                  decoration: const InputDecoration(
                    hintText: 'Select Mode Of Disbursment',
                    labelText: 'Mode Of Disbursment',
                    hintStyle: TextStyle(color: Colors.grey),
                    labelStyle: TextStyle(color: Colors.grey),
                    filled: true,
                    isDense: true,
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                      color: Colors.black,
                    )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                      color: Colors.black,
                    )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),
                ),
              ),
            ),
            new Container(
              height: 20.0,
            ),
            /*   FloatingActionButton.extended(
              icon: Icon(Icons.assignment_turned_in),
              backgroundColor: Color(0xff07426A),
              label: Text("Submit"),
              onPressed: proceed,
            ),*/
            new Container(
              height: 20.0,
            )
          ],
        ),
      ),
    );
  }

  Future<Null> _selectDisDtDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(1800, 8),
        lastDate: DateTime(2101));
    if (picked != null && picked != cusLoanObj.mloandisbdt)
      setState(() {
        cusLoanObj.mloandisbdt = picked;
        tempDate = formatter.format(picked);
        if (picked.day.toString().length == 1) {
          tempDay = "0" + picked.day.toString();
        } else
          tempDay = picked.day.toString();
        loanDisbDt = loanDisbDt.replaceRange(0, 2, tempDay);
        tempYear = picked.year.toString();
        loanDisbDt = loanDisbDt.replaceRange(6, 10, tempYear);
        if (picked.month.toString().length == 1) {
          tempMonth = "0" + picked.month.toString();
        } else
          tempMonth = picked.month.toString();
        loanDisbDt = loanDisbDt.replaceRange(3, 5, tempMonth);
      });
  }


  Future<Null> _selectStrtDtDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(1800, 8),
        lastDate: DateTime(2101));
    if (picked != null && picked != cusLoanObj.minststrtdt)
      setState(() {
        cusLoanObj.minststrtdt = picked;
        tempInstStrtDate = formatter.format(picked);
        if (picked.day.toString().length == 1) {
          tempInstStrtDay = "0" + picked.day.toString();
        } else
          tempInstStrtDay = picked.day.toString();
        loaninstStrtDt = loaninstStrtDt.replaceRange(0, 2, tempInstStrtDay);
        tempInstStrtYear = picked.year.toString();
        loaninstStrtDt = loaninstStrtDt.replaceRange(6, 10, tempInstStrtYear);
        if (picked.month.toString().length == 1) {
          tempInstStrtMonth = "0" + picked.month.toString();
        } else
          tempInstStrtMonth = picked.month.toString();
        loaninstStrtDt = loaninstStrtDt.replaceRange(3, 5, tempInstStrtMonth);
      });
    calculate();
    setState(() {

    });
  }


/*  void _onTapItem(CustomerLoanDetailsBean item) {

    Navigator.push(
      context,
      new MaterialPageRoute(
          builder: (context) =>
              // new LoanLimitDetails()), //When Authorized Navigate to the next screen
              new CCGTab("CCG", 0)),
    );
  }*/

  Future getProduct() async {
    prodObj = await Navigator.push(
        context,
        new MaterialPageRoute(
          builder: (BuildContext context) =>
              FullScreenDialogForProductSelection(30,int.parse(cusLoanObj.mappliedasind)),
          fullscreenDialog: true,
        ));
    if (prodObj != null) {

      cusLoanObj.mprdcd = prodObj.mprdCd;
      cusLoanObj.mprdname = prodObj.mname.trim();
      cusLoanObj.mcurCd = prodObj.mcurCd;
      if (cusLoanObj.mcustno > 0 || cusLoanObj.mcustmrefno > 0 ||
          cusLoanObj.mcusttrefno > 0) {
        if (cusLoanObj.mprdcd != null && cusLoanObj.mloancycle !=null &&
            cusLoanObj.mfrequency != null && branch > 0){
          await AppDatabase.get()
              .selectMaxLoanAmtCanApply(
              cusLoanObj.mprdcd.trim().toString(),
              cusLoanObj.mloancycle+1,
              branch,
              cusLoanObj.mfrequency)
              .then((onValue) {

            for(int secondLoanCycle = 0;secondLoanCycle<onValue.length;secondLoanCycle++){
              if(onValue[secondLoanCycle].mruletype ==1){
                canApplyMaxAmount = onValue[secondLoanCycle].mmaxamount;
              }else if(onValue[secondLoanCycle].mruletype ==2)
                canApplyMaxInst  = onValue[secondLoanCycle].mmaxamount;
          }
            setState(() {

            });
          });
      }
    }
      }



  }

  Future getPurpose(String purposeMode, int selectedPosition) async {

    cusLoanObj.msubpurposeofloandesc ="";
    cusLoanObj.msubpurposeofloan ="";
    multiplePurposeDesc=null;
    multiplePurposeCode=null;
    purposeObj = (await Navigator.push(
        context,
        new MaterialPageRoute(
          builder: (BuildContext context) =>
              FullScreenDialogForPurposeSelection(position: selectedPosition),
          fullscreenDialog: true,
        )).then<List<SubLookupForSubPurposeOfLoan>>((purposeObjVal) {

      for(int itemsToAddOrRemove =0;itemsToAddOrRemove<purposeObjVal.length;itemsToAddOrRemove++) {
        multiplePurposeDesc = multiplePurposeDesc!=null && multiplePurposeDesc!=""?multiplePurposeDesc +"~"+purposeObjVal[itemsToAddOrRemove].codeDesc:purposeObjVal[itemsToAddOrRemove].codeDesc;
        multiplePurposeCode = multiplePurposeCode!=null && multiplePurposeCode!=""?multiplePurposeCode +"~"+purposeObjVal[itemsToAddOrRemove].code:purposeObjVal[itemsToAddOrRemove].code;
      }

      cusLoanObj.msubpurposeofloandesc = multiplePurposeDesc;
      cusLoanObj.msubpurposeofloan = multiplePurposeCode;
    })) as SubLookupForSubPurposeOfLoan;

  }

  Future<Null> calculate() async {

   // DateTime formattedLoanDisbDtDate = loanDisbDt!=null?DateTime.parse(loanDisbDt):null;
    if (cusLoanObj.mprdcd != null &&  cusLoanObj.mloancycle !=null &&
        cusLoanObj.mfrequency != null && branch > 0){
      await AppDatabase.get()
          .selectMaxLoanAmtCanApply(
          cusLoanObj.mprdcd.trim().toString(),
          cusLoanObj.mloancycle+1,
          branch,
          cusLoanObj.mfrequency)
          .then((onValue) {

              for(int secondLoanCycle = 0;secondLoanCycle<onValue.length;secondLoanCycle++){
                if(onValue[secondLoanCycle].mruletype ==1){
                  canApplyMaxAmount = onValue[secondLoanCycle].mmaxamount;
                }else if(onValue[secondLoanCycle].mruletype ==2)
                  canApplyMaxInst  = onValue[secondLoanCycle].mmaxamount;
              }
        setState(() {

        });
      });
    }
    try {
      DateTime formattedLoanDisbDtDate = DateTime.parse(loanDisbDt.substring(6) +
          "-" +
          loanDisbDt.substring(3, 5) +
          "-" +
          loanDisbDt.substring(0, 2));
      cusLoanObj.mloandisbdt=formattedLoanDisbDtDate;

      DateTime formattedInstStrtDtDate = DateTime.parse(loaninstStrtDt.substring(6) +
          "-" +
          loaninstStrtDt.substring(3, 5) +
          "-" +
          loaninstStrtDt.substring(0, 2));
      cusLoanObj.minststrtdt=formattedInstStrtDtDate;
    } catch (e) {
      print("date Exception");
    }

   // cusLoanObj.mloandisbdt=formattedLoanDisbDtDate;;
    if (cusLoanObj.mprdcd != null &&
        cusLoanObj.mcurCd != null &&
        cusLoanObj.mappldloanamt != null &&
        branch != null &&
        cusLoanObj.mperiod != null &&
        cusLoanObj.mloancycle != null) {
      await AppDatabase.get()
          .selectSlabIntRate(
              cusLoanObj.mprdcd.trim().toString(),
              cusLoanObj.mcurCd.trim().toString(),
              cusLoanObj.mappldloanamt,
              branch,
              cusLoanObj.mperiod,
              cusLoanObj.mloancycle)
          .then((onValue) {
        // print("intrate "+ onValue.mintrate.toString());
        cusLoanObj.mintrate = onValue;

        if (cusLoanObj.mappldloanamt != null &&
            cusLoanObj.mintrate != null &&
            cusLoanObj.mperiod != null &&
            cusLoanObj.mloandisbdt != null &&
            cusLoanObj.mfrequency != null) {
          cusLoanObj.minterestamount = (cusLoanObj.mloanamtdisbd) *
              (cusLoanObj.mintrate) *
              (cusLoanObj.mperiod / 12.0) /
              100.0;

          double totalPayingAmount =
              cusLoanObj.mloanamtdisbd + cusLoanObj.minterestamount;
          cusLoanObj.minstamt = (totalPayingAmount / cusLoanObj.mperiod).roundToDouble();
          if(cusLoanObj.mfrequency.trim() == "A"){
            cusLoanObj.mexpdt=DateTime.now();
          }else  if (cusLoanObj.mfrequency.trim() == "M") {
            cusLoanObj.mexpdt = new DateTime(
                cusLoanObj.minststrtdt.year,
                cusLoanObj.minststrtdt.month + cusLoanObj.mperiod,
                cusLoanObj.minststrtdt.day);

          } else if (cusLoanObj.mfrequency.trim() == "B") {
            if (cusLoanObj.mperiod.isOdd) {
              cusLoanObj.mexpdt = new DateTime(
                  cusLoanObj.minststrtdt.year,
                  cusLoanObj.minststrtdt.month +
                      ((cusLoanObj.mperiod - 1) / 2).round(),
                  cusLoanObj.minststrtdt.day + 15);

            } else if (cusLoanObj.mperiod.isEven) {
              cusLoanObj.mexpdt = new DateTime(
                  cusLoanObj.minststrtdt.year,
                  cusLoanObj.minststrtdt.month +
                      (cusLoanObj.mperiod / 2).round(),
                  cusLoanObj.minststrtdt.day);

            }
          }else if (cusLoanObj.mfrequency.trim() == "L") {
            cusLoanObj.mexpdt = new DateTime(
                cusLoanObj.minststrtdt.year,
                cusLoanObj.minststrtdt.month ,
                cusLoanObj.minststrtdt.day + (cusLoanObj.mperiod * 28));

          }else if (cusLoanObj.mfrequency.trim() == "F") {
            cusLoanObj.mexpdt = new DateTime(
                cusLoanObj.minststrtdt.year,
                cusLoanObj.minststrtdt.month ,
                cusLoanObj.minststrtdt.day + (cusLoanObj.mperiod * 14));

          }
          else if (cusLoanObj.mfrequency.trim() == "Q") {
            cusLoanObj.mexpdt = new DateTime(
                cusLoanObj.minststrtdt.year,
                cusLoanObj.minststrtdt.month +(cusLoanObj.mperiod * 3),
                cusLoanObj.minststrtdt.day );
          }
          else if (cusLoanObj.mfrequency.trim() == "W") {

            cusLoanObj.mexpdt = new DateTime(
                cusLoanObj.minststrtdt.year,
                cusLoanObj.minststrtdt.month,
                cusLoanObj.minststrtdt.day + (cusLoanObj.mperiod * 7));

          }
        }

      });
    }


  }

  Future getCustomerNumber() async {
    var customerdata;
    customerdata = await Navigator.push(
        context,
        new MaterialPageRoute(
            builder: (BuildContext context) =>
                CustomerList(null,"Loan Application")));


    await getChildEntitys(customerdata);
    bool isValidated = await validateTabs(customerdata);
    if (customerdata != null && isValidated) {

      //canApplyMaxAmount =
      cusLoanObj.mcustno =
          customerdata.mcustno != null ? customerdata.mcustno : 0;
      cusLoanObj.mcusttrefno =
      customerdata.trefno != null ? customerdata.trefno : 0;
      cusLoanObj.mcustmrefno =
      customerdata.mrefno != null ? customerdata.mrefno : 0;
      cusLoanObj.mcustname = customerdata.mlongname;
      cusLoanObj.mloancycle = customerdata.mtier != null  ? customerdata.mtier : 0;
      loanCycle = customerdata.mtier != null  ? customerdata.mtier : 0;
      mgrpID = customerdata.mgroupcd != null ? customerdata.mgroupcd : 0;
      
      
      
    }
  }

  Future<void> _successfulSubmit() async {
    return showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: new Icon(
              Icons.offline_pin,
              color: Colors.green,
              size: 60.0,
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[
                  Text('Loan Created '),
                ],
              ),
            ),
            actions: <Widget>[
              FlatButton(
                child: Text('Ok '),
                onPressed: () {
                 // CustomerLoanDetailsList.count = 1;
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        });
  }

  proceed() async {
    if (!validateSubmit()) {
      return;
    }

    if(cusLoanObj.mleadstatus ==99) {
      cusLoanObj.missynctocoresys = 0;
    }
    cusLoanObj.mleadstatus = 1;
    //"New";
    cusLoanObj.mrefno = cusLoanObj.mrefno != null ? cusLoanObj.mrefno : 0;
    if (cusLoanObj.mcreatedby == null ||
        cusLoanObj.mcreatedby == '' ||
        cusLoanObj.mcreatedby == 'null') {
      cusLoanObj.mcreatedby = username;
    }


    cusLoanObj.mlastupdateby = username;
    if (cusLoanObj.mcreateddt == null) {
      cusLoanObj.mcreatedby = username;
      cusLoanObj.mcreateddt = DateTime.now();
    }

    cusLoanObj.mlastupdatedt = DateTime.now();
    cusLoanObj.mgeolocation = geoLocation;
    cusLoanObj.mgeologd = geoLongitude;
    cusLoanObj.mgeolatd = geoLatitude;

    await AppDatabase.get()
        .updateCustomerLoanDetailsMaster(cusLoanObj)
        .then((val) {

    });
    _successfulSubmit();
  }

  Future<void> _showAlert(arg, error) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('$arg error'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('$error.'),
              ],
            ),
          ),
          actions: <Widget>[
            FlatButton(
              child: Text('ok'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  bool validateSubmit() {
    String error = "";

  /*  if ( cusLoanObj.mcusttrefno == null || cusLoanObj.mcusttrefno == "" || cusLoanObj.mcustname==null || cusLoanObj.mcustname=="" || cusLoanObj.mcustname=="null"  ) {
      _showAlert("Customer Tablet Ref Number And Name", "It is Mandatory");
     //
      return false;
    }*/
    if (cusLoanObj.mprdname == "" || cusLoanObj.mprdname == null) {
      _showAlert("Product Name", "It is Mandatory");
     //
      return false;
    }
 /*   if (cusLoanObj.mpurposeofloandesc == "" ||
        cusLoanObj.mpurposeofloandesc == null) {
      _showAlert("Purpose Of Loan", "It is Mandatory");
     
      return false;
    }*/
 /*   if (cusLoanObj.msubpurposeofloan == "" ||
        cusLoanObj.msubpurposeofloan == null) {
      _showAlert("Sub Purpose Of Loan", "It is Mandatory");
      //_tabController.animateTo(0);
      return false;
    }*/
    if (cusLoanObj.mintrate == "" || cusLoanObj.mintrate == null) {
      _showAlert("R.O.I", "It is Mandatory");
     //
      return false;
    }
    if (cusLoanObj.mfrequency == "" || cusLoanObj.mfrequency == null) {
      _showAlert("Repayment Type Of Loan", "It is Mandatory");
     //
      return false;
    }
 /*   if (cusLoanObj.mexpdt == "" || cusLoanObj.mexpdt == null) {
      _showAlert("End Date", "It is Mandatory");
     //
      return false;
    }
    if (cusLoanObj.minterestamount == "" ||
        cusLoanObj.minterestamount == null) {
      _showAlert("Interest Amount", "It is Mandatory");
     //
      return false;
    }
    if (cusLoanObj.minstamt == "" || cusLoanObj.minstamt == null) {
      _showAlert("Installment Amount", "It is Mandatory");
      //_tabController.animateTo(0);
      return false;
    }*/

    if(cusLoanObj.minststrtdt!=null&&cusLoanObj.mloandisbdt!=null){
      int diff;
      diff=cusLoanObj.minststrtdt.difference(cusLoanObj.mloandisbdt).inDays;
      if(diff>45){
        _showAlert("Tentative Installment start date ", "It should not be more that 45 days from Disbursement date");
        return false;
      }
    }

    if (cusLoanObj.mapprvdloanamt == "" || cusLoanObj.mapprvdloanamt == null) {
      _showAlert("Approved Amount", "It is Mandatory");
     //
      return false;
    }
    if (cusLoanObj.mloanamtdisbd == "" || cusLoanObj.mloanamtdisbd == null) {
      _showAlert("Disbursment Amount", "It is Mandatory");
     //
      return false;
    }
    if (cusLoanObj.mrepaymentmode == "" || cusLoanObj.mrepaymentmode == null || cusLoanObj.mrepaymentmode == 0 ) {
      _showAlert("Mode Of Collection", "It is Mandatory");
     //
      return false;
    }
    if (cusLoanObj.mmodeofdisb == "" || cusLoanObj.mmodeofdisb == null || cusLoanObj.mrepaymentmode == 0) {
      _showAlert("Mode Of Disbursment", "It is Mandatory");
     //
      return false;
    }

    if (cusLoanObj.mapprvdloanamt >canApplyMaxAmount || cusLoanObj.mappldloanamt >canApplyMaxAmount ) {
      _showAlert("Cannot apply more than  Max amount", "Please enter less amout");
      //
      return false;
    }

    if (cusLoanObj.mperiod >canApplyMaxInst ) {
      _showAlert("period cannot be more than max apply period", "Please entercorrect period");
      //
      return false;
    }


    return true;
  }

  Future<Null> addCashFlow(CustomerLoanDetailsBean bean) async{
    CustomerListBean custBean = new CustomerListBean();
      custBean.fixedAssetsList =   new FixedAssetsBean();
      custBean.currentAssetsList =    new CurrentAssetsBean();
      custBean.longTermLiabilitiesList =   new LongTermLiabilitiesBean();
      custBean.shortTermLiabilitiesList =     new ShortTermLiabilitiesBean();
      custBean.equityList =     new EquityBean();
      custBean.financialStmntList =     new FinancialStmntBean();
      custBean.incomeStatementList =     new IncomeStatementBean();
    custBean.trefno = bean.mcusttrefno;
    custBean.mrefno =  bean.mcustmrefno;
    await AppDatabase.get()
        .selectCustomerFixedAssetListIsDataSynced(bean.mcusttrefno, bean.mcustmrefno)
        .then(
            (FixedAssetsBean fixedAssetsBean) async {
              custBean.fixedAssetsList = fixedAssetsBean;
        });


    await AppDatabase.get()
        .selectCustomerCurrentAssetListIsDataSynced(bean.mcusttrefno, bean.mcustmrefno)
        .then(
            (CurrentAssetsBean currentAssetsBean) async {
          custBean.currentAssetsList = currentAssetsBean;
        });

    await AppDatabase.get()
        .selectCustomerCurrentAssetListIsDataSynced(bean.mcusttrefno, bean.mcustmrefno)
        .then(
            (CurrentAssetsBean currentAssetsBean) async {
              custBean.currentAssetsList = currentAssetsBean;
        });

    await AppDatabase.get()
        .selectCustomerLongTermLiabilitiesListIsDataSynced(bean.mcusttrefno, bean.mcustmrefno)
        .then(
            (LongTermLiabilitiesBean longTermLiabilitiesBean) async {
              custBean.longTermLiabilitiesList = longTermLiabilitiesBean;
        });

    await AppDatabase.get()
        .selectCustomerShortTermLiabilitiesListIsDataSynced(bean.mcusttrefno, bean.mcustmrefno)
        .then(
            (ShortTermLiabilitiesBean shortTermLiabilitiesBean) async {
              custBean.shortTermLiabilitiesList = shortTermLiabilitiesBean;
        });

    await AppDatabase.get()
        .selectCustomerEquityListIsDataSynced(bean.mcusttrefno, bean.mcustmrefno)
        .then(
            (EquityBean equityBean) async {
              custBean.equityList = equityBean;
        });



    await AppDatabase.get()
        .selectCustomerIncomeStatementListIsDataSynced(bean.mcusttrefno, bean.mcustmrefno)
        .then(
            (IncomeStatementBean incomeStatementBean) async {
              custBean.incomeStatementList = incomeStatementBean;

        });



    await AppDatabase.get()
        .selectCustomerFinancialStatementListIsDataSynced(bean.mcusttrefno, bean.mcustmrefno)
        .then(
            (FinancialStmntBean financialStmntBean) async {
          custBean.financialStmntList = financialStmntBean;

        });

    await routeToCustomerCashFlowScreenForModificationOfData(custBean);
  }

  routeToCustomerCashFlowScreenForModificationOfData(CustomerListBean bean) {
    Navigator.push(
        context,
        new MaterialPageRoute(
          builder: (BuildContext context) =>
           new CustomerFormationBusinessCashFlow3(customerObject: bean,),
        ));
  }

  Future getMainOccupation(String purposeMode, int selectedPosition) async {
    mainOcc = await Navigator.push(
        context,
        new MaterialPageRoute(
          builder: (BuildContext context) =>
              FullScreenDialogForMainOccupationSelection(position: selectedPosition),
          fullscreenDialog: true,
        )).then<SubLookupForSubPurposeOfLoan>((purposeObjVal) {

      //subPurposeName=purposeObjVal.codeDesc;
      //subPurposeId = purposeObjVal.code;
      cusLoanObj.mmainoccupndesc = purposeObjVal.codeDesc;
      cusLoanObj.mmainoccupn = (purposeObjVal.code.trim());
    });

  }

  Future getSubOccupation(String purposeMode, int selectedPosition) async {
    mainOcc = await Navigator.push(
        context,
        new MaterialPageRoute(
          builder: (BuildContext context) =>
              FullScreenDialogForSubOccupationSelection(type: "Sector Selection List",basicCode: 1800000,position: selectedPosition),
          fullscreenDialog: true,
        )).then<SubLookupForSubPurposeOfLoan>((purposeObjVal) {

      //subPurposeName=purposeObjVal.codeDesc;
      //subPurposeId = purposeObjVal.code;
      cusLoanObj.msuboccupndesc = purposeObjVal.codeDesc;
      cusLoanObj.msuboccupn = (purposeObjVal.code.trim());
    });
    /*  if (purposeMode == "subpurpose") {
//   if (purposeObj??  purposeObj.codeDesc??  purposeObj.code?? ) {
      subPurposeName = purposeObj.codeDesc ?? "";
      subPurposeId = purposeObj.code;
      // }
    }*/
  }


  Future getHbsUser() async {
     await Navigator.push(
        context,
        new MaterialPageRoute(
          builder: (BuildContext context) =>
              FullScreenDialogForHbsUsers(),
          fullscreenDialog: true,
        )).then<HbsUserBean>((hbsUsers) {
    //Set Super USer here on selection
       cusLoanObj.mrouteto = hbsUsers.musrcode;
    });
    /*  if (purposeMode == "subpurpose") {
//   if (purposeObj??  purposeObj.codeDesc??  purposeObj.code?? ) {
      subPurposeName = purposeObj.codeDesc ?? "";
      subPurposeId = purposeObj.code;
      // }
    }*/
  }


  Future<bool> validateTabs(CustomerListBean custListBean) async {
    String error = "";
    bool isMaxLengthExceed = false;

    /*if (custListBean.imageMaster == null) {
      custListBean.imageMaster =
      new List<ImageBean>();
      for (int i = 0; i < 23; i++) {
        custListBean.imageMaster
            .add(new ImageBean());
      }
    }*/


    if (custListBean.imageMaster[0].imgString == "" ||
        custListBean.imageMaster[0].imgString == null) {
      _showAlert("Customer Picture", "It is Mandatory");
      return false;
    }
    if (custListBean.mcustcategory == "" || custListBean.mcustcategory == null) {
     
      _showAlert("Applicant Type", "Field is mandatory");
      return false;
    }
    if (custListBean.mnationality == "" || custListBean.mnationality == null) {
     
      _showAlert("Nationality", "Field is mandatory");
      return false;
    }
    if (custListBean.mnametitle == "" || custListBean.mnametitle == null) {
     
      _showAlert("Title", "Field is mandatory");
      return false;
    }
    Utility ut = new Utility();
    error = ut.validateOnlyCharacterField(custListBean.mfname);
    if (error != null) {
      _showAlert("First Name", error);
     
      return false;
    }
    error = ut.validateOnlyCharacterField(custListBean.mlname);
    if (error != null) {
      //showInSnackBar("Last name has $error ",context);
      _showAlert("Last Name", error);
     
      return false;
    }
    error = ut.validateOnlyCharacterFieldKhmer(custListBean.mfname2);
    if (error != null) {
      _showAlert("First Name Khmer", error);
     
      return false;
    }

    error = ut.validateOnlyCharacterFieldKhmer(custListBean.mlname2);
    if (error != null) {
      _showAlert("Last Name Khmer", error);
     
      return false;
    }
    try {
    

      int age = DateTime.now().year-custListBean.mdob.year;
      print("custListBean.mdob.year"+age.toString());
      if (age < 18) {
        _showAlert("Date Of birth", "It should be greater than 18");
       
        return false;
      }
    } catch (e) {
      _showAlert("Applicant DOB", "It is Mandatory");
     
      return false;
    }
    if (custListBean.mgender == "" || custListBean.mgender == null) {
     
      _showAlert("Gender", "Field is mandatory");
      return false;
    }

    if (custListBean.mmaritialStatus == "" ||
        custListBean.mmaritialStatus == null) {
     
      _showAlert("Marital Status", "Field is mandatory");
      return false;
    }
    if(custListBean.mmaritialStatus!=null &&custListBean.mmaritialStatus=="2"){
      _showAlert("Spouse Name", "It is Mandatory");
     
      return false;
    }
    if (custListBean.mresstatus == "" ||
        custListBean.mresstatus == null) {
     
      _showAlert("Resedence Status", "Field is mandatory");
      return false;
    }
    if (custListBean.mrelegion == "" || custListBean.mrelegion == null) {
     
      _showAlert("Religion", "Field is mandatory");
      return false;
    }
    if (custListBean.mlangofcust == "" || custListBean.mlangofcust == null) {
     
      _showAlert("Language", "Field is mandatory");
      return false;
    }
    if (custListBean.moccupation == "" || custListBean.moccupation == null) {
     
      _showAlert("Occupation", "Field is mandatory");
      return false;
    }
    if (custListBean.miscpemp == "" || custListBean.miscpemp == null) {
     
      _showAlert("Is Bank Employee", "Field is mandatory");
      return false;
    }

    if (custListBean.mtarget == "" || custListBean.mtarget == null) {
     
      _showAlert("Target", "Field is mandatory");
      return false;
    }
    //TODO undone this

    if (custListBean.mownership == "" || custListBean.mownership == null) {
     
      _showAlert("Ownership", "Field is mandatory");
      return false;
    }
    if (custListBean.addressDetails == null ||
        custListBean.addressDetails == [] ||
        custListBean.addressDetails.length == 0) {
     
      _showAlert("Adress Detail", "Atleast one address is mandatory");

      return false;
    }
    bool isContain5 =false;
    for (int i = 0; i < custListBean.addressDetails.length; i++) {
      if(custListBean.addressDetails[i].maddrType ==5){
        isContain5 =true;
        break;
      }
    }

    if(!isContain5){
     
      _showAlert("Place Of Birth", "Place Of Birth Address Type is mandatory");
      isContain5 =false;
      return false;
    }
    bool isContain6 =false;
    for (int i = 0; i < custListBean.addressDetails.length; i++) {
      if(custListBean.addressDetails[i].maddrType ==6){
        isContain6 =true;
        break;
      }
    }

    if(!isContain6){
     
      _showAlert("NID Address", "NID Address is mandatory");
      isContain6 =false;
      return false;
    }
/*    if (custListBean.mbankacno == "" || custListBean.mbankacno == null) {
     
      _showAlert("Account number", "Field is mandatory");
      return false;
    }
    if (custListBean.mbanknamelk == "" || custListBean.mbanknamelk == null) {
     
      _showAlert("Bank Name", "Field is mandatory");
      return false;
    }
    if(custListBean.macctbal==null||custListBean.macctbal.toString().trim()==""){
     
      _showAlert("Account Balance", "Field is mandatory");
      return  false;
    }
    if (custListBean.mbankacyn == "" || custListBean.mbankacyn == null) {
     
      _showAlert("Is Use For Disbursment", "Field is mandatory");
      return false;
    }*/
    if (custListBean.customerBusinessDetailsBean == null ||
        custListBean.customerBusinessDetailsBean == [] ||
        custListBean.customerBusinessDetailsBean.length == 0) {
     
      _showAlert("Employment/Business Detail", "Atleast one Employment/Business is mandatory");

      return false;
    }
    if (custListBean.mpanno == "" || custListBean.mpanno == null) {
     
      _showAlert(Translations.of(context).text('idtype1'), "Field is mandatory");
      return false;
    }
    if (custListBean.mpannodesc == "" || custListBean.mpannodesc == null) {
     
      _showAlert(Translations.of(context).text('idtype1desc'), "Field is mandatory");
      return false;
    }else   if (custListBean.mpannodesc.length<8 ) {
     
      _showAlert(Translations.of(context).text('idtype1desc'), "Should not be less than 9 Char");
      return false;
    }
    if (custListBean.missngautryt1 == "" || custListBean.missngautryt1 == null) {
     
      _showAlert(Translations.of(context).text('idtype1issuing'), "Field is mandatory");
      return false;
    }


    try {

      try {
        if (DateTime.now().isBefore(custListBean.mid1issuedate)) {
          _showAlert("Id 1 Issue Date", "Cannot be Future Date");
        }
      }catch(_){
        _showAlert("Id 1 Issue Date", "Cannot be Future Date");
      }
    } catch (e) {
      _showAlert("Id 1 Issue Date", "It is Mandatory");
     
      return false;
    }


    try {

      if (custListBean.mid1expdate==DateTime.now() || custListBean.mid1expdate.isBefore(DateTime.now())) {
        _showAlert("Id 1 Expiry Date", "It should be greater than Current Date");
       
        return false;
      }
    } catch (e) {
      _showAlert("Id 1 Expiry Date", "It is Mandatory");
     
      return false;
    }

    if (custListBean.mTypeOfId == "" || custListBean.mTypeOfId == null) {
     
      _showAlert(Translations.of(context).text('idtype2'), "Field is mandatory");
      return false;
    }


    if (custListBean.mIdDesc == "" || custListBean.mIdDesc == null) {
     
      _showAlert(Translations.of(context).text('idtype2desc'), "Field is mandatory");
      return false;
    }


    if (custListBean.missngautryt2 == "" || custListBean.missngautryt2 == null) {
     
      _showAlert(Translations.of(context).text('idtype2issuing'), "Field is mandatory");
      return false;
    }

    try {

      try {
        if (DateTime.now().isBefore(custListBean.mid2issuedate)) {
          _showAlert("Id 2 Issue Date", "Cannot be Future Date");
        }
      }catch(_){
        _showAlert("Id 2 Issue Date", "Cannot be Future Date");
      }
    } catch (e) {
      _showAlert("Id 2 Issue Date", "It is Mandatory");
     
      return false;
    }

    try {

      if (custListBean.mid2expdate==DateTime.now() || custListBean.mid2expdate.isBefore(DateTime.now())) {
        _showAlert("Id 2 Expiry Date", "It should be greater than Current Date");
       
        return false;
      }
    } catch (e) {
      _showAlert("Id 2 Expiry Date", "It is Mandatory");
     
      return false;
    }

    if (custListBean.mtypeofid3 == "" || custListBean.mtypeofid3 == null) {
     
      _showAlert(Translations.of(context).text('idtype3'), "Field is mandatory");
      return false;
    }

    if (custListBean.middesc3 == "" || custListBean.middesc3 == null) {
     
      _showAlert(Translations.of(context).text('idtype3desc'), "Field is mandatory");
      return false;
    }

    if (custListBean.missngautryt3 == "" || custListBean.missngautryt3 == null) {
     
      _showAlert(Translations.of(context).text('idtype3issuing'), "Field is mandatory");
      return false;
    }

    try {

      try {
        if (DateTime.now().isBefore(custListBean.mid3issuedate)) {
          _showAlert("Id 3 Issue Date", "Cannot be Future Date");
        }
      }catch(_){
        _showAlert("Id 3 Issue Date", "Cannot be Future Date");
      }
    } catch (e) {
      _showAlert("Id 3 Issue Date", "It is Mandatory");
     
      return false;
    }
    if(custListBean.mid3expdate!=null) {

    try {

      if (custListBean.mid3expdate==DateTime.now() || custListBean.mid3expdate.isBefore(DateTime.now())) {
        _showAlert("Id 3 Expiry Date", "It should be greater than Current Date");
       
        return false;
      }

    } catch (e) {
    //  _showAlert("Id 3 Expiry Date", "It is Mandatory");
     
      return false;
    }}
    SystemParameterBean sysBean =
    await AppDatabase.get().getSystemParameter('11', 0);


    if (custListBean.imageMaster[11].imgString == null ||
        custListBean.imageMaster[11].imgString == "" ) {
      _showAlert("Customer Signature",
          "It is Mandatory");
     
      return false;
    }
    if (custListBean.imageMaster[12].imgString == null ||
        custListBean.imageMaster[12].imgString == "" ) {
      _showAlert("Spouse Signature",
          "It is Mandatory");
     
      return false;
    }
   

    return true;
  }

    getChildEntitys(CustomerListBean bean)async{


      bean.addressDetails = new List<AddressDetailsBean>();
      bean.familyDetailsList = new List<FamilyDetailsBean>();
      bean.customerBusinessDetailsBean =
      new List<CustomerBusinessDetailsBean>();
      // bean.pPIMasterBean = new List<PPIMasterBean>();
      bean.borrowingDetailsBean = new List<BorrowingDetailsBean>();
      bean.imageMaster = new List<ImageBean>();
      bean.businessExpendDetailsList =
      new List<BusinessExpenditureDetailsBean>();
      bean.householdExpendDetailsList =
      new List<HouseholdExpenditureDetailsBean>();
      bean.esmsentity = new ESMSBean();
      bean.riskratingsentity = new RiskRatingsBean();

      for (int i = 0; i < 23; i++) {
        bean.imageMaster.add(new ImageBean());
      }

      await AppDatabase.get()
          .selectCustomerFamilyDetailsListIsDataSynced(bean.trefno, bean.mrefno)
          .then((List<FamilyDetailsBean> familyDetailsBean) async {
        for (int i = 0; i < familyDetailsBean.length; i++) {
          bean.familyDetailsList.add(familyDetailsBean[i]);
        }
        // print("Family Details list is ${bean.familyDetailsList}");
      });

      await AppDatabase.get()
          .selectCustomerBussinessDetailsListIsDataSynced(
          bean.trefno, bean.mrefno)
          .then((List<CustomerBusinessDetailsBean>
      customerBusinessDetailsBean) async {
        for (int i = 0; i < customerBusinessDetailsBean.length; i++) {
          bean.customerBusinessDetailsBean.add(customerBusinessDetailsBean[i]);
        }
        // print("Family Details list is ${bean.familyDetailsList}");
      });
      await AppDatabase.get()
          .selectCustomerBorrowingDetailsListIsDataSynced(
          bean.trefno, bean.mrefno)
          .then((List<BorrowingDetailsBean> borrowingDetailsBean) async {
        for (int i = 0; i < borrowingDetailsBean.length; i++) {
          bean.borrowingDetailsBean.add(borrowingDetailsBean[i]);
        }

        //  print("Borrowing  Details list is ${bean.borrowingDetailsBean}");
      });

      await AppDatabase.get()
          .selectCustomerAddressDetailsListIsDataSynced(
          bean.trefno, bean.mrefno)
          .then((List<AddressDetailsBean> addressDetails) async {
        for (int i = 0; i < addressDetails.length; i++) {
          bean.addressDetails.add(addressDetails[i]);
        }

        // print("Addres  Details list is ${bean.addressDetails}");
      });

      await AppDatabase.get()
          .selectImagesListIsDataSynced(bean.trefno, bean.mrefno)
          .then((List<ImageBean> imageBean) async {
        for (int i = 0; i < imageBean.length; i++) {
          bean.imageMaster[imageBean[i].tImgrefno] = imageBean[i];

          /*     print(
              "for bean ${imageBean[i].tImgrefno} is ${bean.imageMaster[imageBean[i].tImgrefno]}");*/
        }
      });

      /*   await AppDatabase.get()
          .selectCustomerBusinessExpenseListIsDataSynced(
              bean.trefno, bean.mrefno)
          .then(
              (List<BusinessExpenditureDetailsBean> businessExpenseBean) async {
        for (int i = 0; i < businessExpenseBean.length; i++) {
          bean.businessExpendDetailsList.add(businessExpenseBean[i]);
        }
       // print("business expenditure list is ${bean.businessExpendDetailsList}");
      });*/

      /*   await AppDatabase.get()
          .selectCustomerHouseholdExpenseListIsDataSynced(
              bean.trefno, bean.mrefno)
          .then((List<HouseholdExpenditureDetailsBean>
              householdExpenseBean) async {
        for (int i = 0; i < householdExpenseBean.length; i++) {
          bean.householdExpendDetailsList.add(householdExpenseBean[i]);
        }
        */ /*print(
            "household expenditure list is ${bean.householdExpendDetailsList}");*/ /*
      });*/

      await AppDatabase.get()
          .selectCustomerAssetDetailListIsDataSynced(bean.trefno, bean.mrefno)
          .then((List<AssetDetailsBean> assetDetailsBean) async {
        for (int i = 0; i < assetDetailsBean.length; i++) {
          bean.assetDetailsList.add(assetDetailsBean[i]);
        }
        //  print("asset detail list is ${bean.assetDetailsList}");
      });

      await AppDatabase.get()
          .selectCustomerFixedAssetListIsDataSynced(bean.trefno, bean.mrefno)
          .then((FixedAssetsBean fixedAssetsBean) async {
        bean.fixedAssetsList = fixedAssetsBean;
      });

      await AppDatabase.get()
          .selectCustomerCurrentAssetListIsDataSynced(bean.trefno, bean.mrefno)
          .then((CurrentAssetsBean currentAssetsBean) async {
        bean.currentAssetsList = currentAssetsBean;
      });

      await AppDatabase.get()
          .selectCustomerCurrentAssetListIsDataSynced(bean.trefno, bean.mrefno)
          .then((CurrentAssetsBean currentAssetsBean) async {
        bean.currentAssetsList = currentAssetsBean;
      });

      await AppDatabase.get()
          .selectCustomerLongTermLiabilitiesListIsDataSynced(
          bean.trefno, bean.mrefno)
          .then((LongTermLiabilitiesBean longTermLiabilitiesBean) async {
        bean.longTermLiabilitiesList = longTermLiabilitiesBean;
      });

      await AppDatabase.get()
          .selectCustomerShortTermLiabilitiesListIsDataSynced(
          bean.trefno, bean.mrefno)
          .then((ShortTermLiabilitiesBean shortTermLiabilitiesBean) async {
        bean.shortTermLiabilitiesList = shortTermLiabilitiesBean;
      });

      await AppDatabase.get()
          .selectCustomerEquityListIsDataSynced(bean.trefno, bean.mrefno)
          .then((EquityBean equityBean) async {
        bean.equityList = equityBean;
      });

      await AppDatabase.get()
          .selectCustomerIncomeStatementListIsDataSynced(
          bean.trefno, bean.mrefno)
          .then((IncomeStatementBean incomeStatementBean) async {
        bean.incomeStatementList = incomeStatementBean;
      });

      await AppDatabase.get()
          .selectCustomerTotalExpndtrListIsDataSynced(bean.trefno, bean.mrefno)
          .then(
              (TotalExpenditureDetailsBean totalExpenditureDetailsBean) async {
            bean.totalExpenditureDetailsBean = totalExpenditureDetailsBean;
          });

      await AppDatabase.get()
          .selectCustomerFinancialStatementListIsDataSynced(
          bean.trefno, bean.mrefno)
          .then((FinancialStmntBean financialStmntBean) async {
        bean.financialStmntList = financialStmntBean;
      });

      await AppDatabase.get()
          .selectCustomerESMSDetails(bean.trefno, bean.mrefno)
          .then((ESMSBean customerESMSBean) async {
        // print("returned esms entity dust ${customerESMSBean.mdust}");
        bean.esmsentity = customerESMSBean;
      });

      await AppDatabase.get()
          .selectCustomerRiskRatingsDetails(
          bean.trefno, bean.mrefno)
          .then((RiskRatingsBean riskRatingsBean) async {
        bean.riskratingsentity = riskRatingsBean;
      });

      // print("esms entity   "+bean.esmsentity.mdust.toString());
    }
}
