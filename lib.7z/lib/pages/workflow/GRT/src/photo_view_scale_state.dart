enum PhotoViewScaleState { initial, covering, originalSize, zooming }
