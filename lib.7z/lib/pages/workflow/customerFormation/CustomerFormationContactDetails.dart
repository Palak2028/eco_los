import 'package:eco_los/db/TablesColumnFile.dart';
import 'package:eco_los/translations.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:eco_los/Utilities/app_constant.dart';
import 'package:eco_los/pages/workflow/LookupMasterBean.dart';
import 'package:eco_los/pages/workflow/address/FullScreenDialogForAreaSelection.dart';
import 'package:eco_los/pages/workflow/address/FullScreenDialogForCountrySelection.dart';
import 'package:eco_los/pages/workflow/address/FullScreenDialogForDistrictSelection.dart';
import 'package:eco_los/pages/workflow/address/FullScreenDialogForStateSelection.dart';
import 'package:eco_los/pages/workflow/address/FullScreenDialogForSubDistrictSelection.dart';
import 'package:eco_los/pages/workflow/address/beans/AreaDropDownBean.dart';
import 'package:eco_los/pages/workflow/address/beans/CountryDropDownBean.dart';
import 'package:eco_los/pages/workflow/address/beans/DistrictDropDownBean.dart';
import 'package:eco_los/pages/workflow/address/beans/StateDropDownBean.dart';
import 'package:eco_los/pages/workflow/address/beans/SubDistrictDropDownBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/CustomerFormationMasterTabs.dart';
import 'package:eco_los/pages/workflow/customerFormation/ViewCustomerFormationAddressDetails.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/AddressDetailsBean.dart';
import 'package:eco_los/Utilities/globals.dart' as globals;
import 'package:shared_preferences/shared_preferences.dart';

class CustomerFormationContactDetails extends StatefulWidget {
  CustomerFormationContactDetails({Key key}) : super(key: key);

  @override
  _CustomerFormationContactDetailsState createState() =>
      new _CustomerFormationContactDetailsState();
}

class _CustomerFormationContactDetailsState
    extends State<CustomerFormationContactDetails> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  static final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  FullScreenDialogForCountrySelection _myCountryDialog =
  new FullScreenDialogForCountrySelection();
  FullScreenDialogForStateSelection _myStateDialog =
  new FullScreenDialogForStateSelection();
  FullScreenDialogForDistrictSelection _myDistrictDialog =
  new FullScreenDialogForDistrictSelection();
  FullScreenDialogForSubDistrictSelection _mySubDistrictDialog =
  new FullScreenDialogForSubDistrictSelection();
  FullScreenDialogForAreaSelection _myAreaDialog =
  new FullScreenDialogForAreaSelection();
  final TextEditingController _controller = new TextEditingController();
  static bool isSubmitClicked = false;
  var _focusNode = new FocusNode();
  AddressDetailsBean addressBean = new AddressDetailsBean();
  final List<AddressDetailsBean> addressDetailsList = new List<AddressDetailsBean>();
  LookupBeanData addressType;
  LookupBeanData mownership;
  CountryDropDownBean tempContrybean = new CountryDropDownBean();
  StateDropDownList tempStateBean = new StateDropDownList();
  SubDistrictDropDownList tempSubDistrictBean = new SubDistrictDropDownList();
  DistrictDropDownList tempDistrictBean = new DistrictDropDownList();
  AreaDropDownList tempAreaDistrict = new AreaDropDownList();
  SharedPreferences prefs;
  String geoLatitude;
  String geoLongitude;


  Future<Null> getSessionVariables() async {
    prefs = await SharedPreferences.getInstance();
    setState(() {
      geoLatitude = prefs.get(TablesColumnFile.geoLatitude).toString();
      geoLongitude = prefs.get(TablesColumnFile.geoLongitude).toString();


    });
  }

  @override
  void initState() {
    super.initState();
    getSessionVariables();

    if(CustomerFormationMasterTabsState.addressBean!=null){
      print(CustomerFormationMasterTabsState.addressBean.maddrType);
      for (int k = 0; k < globals.dropdownCaptionsValuesKycDetails2.length; k++) {
        for (int i = 0;
        i < globals.dropdownCaptionsValuesKycDetails2[k].length;
        i++) {
          if (globals.dropdownCaptionsValuesKycDetails2[k][i].mcode ==
              CustomerFormationMasterTabsState.addressBean.maddrType.toString()) {

            print("matched value is ${globals.dropdownCaptionsValuesKycDetails2[k][i].mcode}");
            setValue(k, globals.dropdownCaptionsValuesKycDetails2[k][i]);
          }else  if (globals.dropdownCaptionsValuesKycDetails2[k][i].mcode ==
              CustomerFormationMasterTabsState.addressBean.mownership.toString()) {

            print("matched value is ${globals.dropdownCaptionsValuesKycDetails2[k][i].mcode}");
            setValue(k, globals.dropdownCaptionsValuesKycDetails2[k][i]);
          }
        }
      }

    }
    else{

      CustomerFormationMasterTabsState.addressBean= new AddressDetailsBean();
    }
  }

  void showMessage(String message, [MaterialColor color = Colors.red]) {
    _scaffoldKey.currentState.showSnackBar(
        new SnackBar(backgroundColor: color, content: new Text(message)));
  }

  List<DropdownMenuItem<LookupBeanData>> generateDropDown(int no) {
    //print("caption value : " + globals.dropdownCaptionsKycDetails2[no]);

    List<DropdownMenuItem<LookupBeanData>> _dropDownMenuItems1;
    List<LookupBeanData> mapData = List<LookupBeanData>();
    LookupBeanData bean = new LookupBeanData();
    bean.mcodedesc = "";
    mapData.add(blankBean);
    for (int k = 0;
    k < globals.dropdownCaptionsValuesKycDetails2[no].length;
    k++) {
      mapData.add(globals.dropdownCaptionsValuesKycDetails2[no][k]);
    }
    _dropDownMenuItems1 = mapData.map((value) {
      print("data here is of adress Type dropdownwale biayajai " +
          value.mcodedesc);
      return new DropdownMenuItem<LookupBeanData>(
        value: value,
        child: new Text(value.mcodedesc),
      );
    }).toList();

    return _dropDownMenuItems1;
  }

  Widget getTextContainer(String textValue) {
    return new Container(
      padding: EdgeInsets.fromLTRB(5.0, 20.0, 0.0, 20.0),
      child: new Text(
        textValue,
        //textDirection: TextDirection,
        textAlign: TextAlign.start,
        /*overflow: TextOverflow.ellipsis,*/
        style: new TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.grey,
            fontStyle: FontStyle.normal,
            fontSize: 12.0),
      ),
    );
  }
  LookupBeanData blankBean = new LookupBeanData(mcodedesc: "",mcode: "",mcodetype: 0);


  showDropDown(LookupBeanData selectedObj, int no) {


    if(selectedObj.mcodedesc.isEmpty){
      print("inside  code Desc is null");
      switch (no) {
        case 0:
          addressType = blankBean;
          CustomerFormationMasterTabsState.addressBean.maddrType = 0;
          break;
        case 1:
          mownership = blankBean;
          CustomerFormationMasterTabsState.addressBean.mownership = blankBean.mcode;
          break;
      }
      setState(() {

      });
    }else{
      for (int k = 0;
      k < globals.dropdownCaptionsValuesKycDetails2[no].length;
      k++) {
        if (globals.dropdownCaptionsValuesKycDetails2[no][k].mcodedesc ==
            selectedObj.mcodedesc) {
          setValue(no, globals.dropdownCaptionsValuesKycDetails2[no][k]);
        }
      }
    }

  }

  setValue(int no, LookupBeanData value) {
    setState(() {
      print("coming here");
      switch (no) {
        case 0:
          addressType = value;
          CustomerFormationMasterTabsState.addressBean.maddrType =
              int.parse(value.mcode);
          if(CustomerFormationMasterTabsState.custListBean.addressDetails.length>0){
            LookupBeanData tempBean = new LookupBeanData(mcodedesc: "",mcode: "",mcodetype: 0);
            for (int k = 0;
            k < globals.dropdownCaptionsValuesKycDetails2[no].length;
            k++) {
              print("lajbdlsdl"+CustomerFormationMasterTabsState.custListBean.addressDetails[CustomerFormationMasterTabsState.custListBean.addressDetails.length-1].maddrType.toString());
              print("globals.dropdownCaptionsValuesKycDetails2[no][k].mcode"+globals.dropdownCaptionsValuesKycDetails2[no][k].mcode.toString());
              if (globals.dropdownCaptionsValuesKycDetails2[no][k].mcode.trim() ==
                  CustomerFormationMasterTabsState.custListBean.addressDetails[CustomerFormationMasterTabsState.custListBean.addressDetails.length-1].maddrType.toString()) {
                tempBean.mcodedesc = globals.dropdownCaptionsValuesKycDetails2[no][k].mcodedesc;
                break;
              }
            }

            onSelectAddress(context,"Address","Is this address is same as previous address  which is ${tempBean.mcodedesc}");
          }
          break;
        case 1:
          mownership = value;
          CustomerFormationMasterTabsState.addressBean.mownership = value.mcode;
          break;
        default:
          break;
      }
    });
  }



  @override
  Widget build(BuildContext context) {
    return new SafeArea(
        top: false,
        bottom: false,
        child: new Form(
            key: _formKey,
            autovalidate: false,
            onWillPop: () {
              return Future(() => true);
            },
            onChanged: () {
              final FormState form = _formKey.currentState;
              form.save();
            },
            child: new ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              children: <Widget>[
                SizedBox(
                  height: 16.0,
                ),
            Container(
              color: Constant.mandatoryColor,
              child: new DropdownButtonFormField(
                  value: addressType,
                  items: generateDropDown(0),
                  onChanged: (LookupBeanData newValue) {
                    showDropDown(newValue, 0);
                  },
                  validator: (args) {
                    print(args);
                 },
                  decoration: InputDecoration(
                      labelText: globals.dropdownCaptionsKycDetails2[0]),
                ),),

                SizedBox(
                  height: 16.0,
                ),
                Container(
                  color: Constant.mandatoryColor,
                  child: new DropdownButtonFormField(
                    value: mownership,
                    items: generateDropDown(1),
                    onChanged: (LookupBeanData newValue) {
                      showDropDown(newValue, 1);
                    },
                    validator: (args) {
                      print(args);
                    },
                    decoration: InputDecoration(
                        labelText: globals.dropdownCaptionsKycDetails2[1]),
                  ),),

                SizedBox(height: 16.0),
                Container(
                  color:  Constant.semiMandatoryColor,
                  child: new ListTile(
                    title: new Text("Country"),
                    subtitle: CustomerFormationMasterTabsState.addressBean.mcountryCd == null ||
                        CustomerFormationMasterTabsState.addressBean.mcountryCd == "null"
                        ? new Text("")
                        : new Text("${CustomerFormationMasterTabsState.addressBean.mcountryCd} ${CustomerFormationMasterTabsState.addressBean.mcountryname}"),
                    onTap: () async {

                    tempContrybean = await
                    Navigator.push(
                        context,
                        new MaterialPageRoute(
                          builder: (BuildContext context) => _myCountryDialog,
                          fullscreenDialog: true,
                        ));

                    if(tempContrybean!=null){
                      CustomerFormationMasterTabsState.addressBean.mcountryCd = tempContrybean.cntryCd;
                      CustomerFormationMasterTabsState.addressBean.mcountryname = tempContrybean.countryName;
                    }
                  },
                ),
                ),
                new Divider(),//),
                SizedBox(height: 16.0),
                Container(
                  color: Constant.semiMandatoryColor,
                  child: new ListTile(

                    title: new Text(Translations.of(context).text('State')),
                    subtitle:
                    CustomerFormationMasterTabsState.addressBean.mState == null || CustomerFormationMasterTabsState.addressBean.mState == "null"
                        ? new Text("")
                        : new Text("${CustomerFormationMasterTabsState.addressBean.mState} ${CustomerFormationMasterTabsState.addressBean.mstatedesc}"),
                    onTap: () async {

                    tempStateBean = await
                    Navigator.push(
                        context,
                        new MaterialPageRoute(
                          builder: (BuildContext context) => _myStateDialog,
                          fullscreenDialog: true,
                        ));

                    if(tempStateBean!=null){
                      CustomerFormationMasterTabsState.addressBean.mState = tempStateBean.stateCd;
                      CustomerFormationMasterTabsState.addressBean.mstatedesc  = tempStateBean.stateDesc;
                    }
                    setState(() {

                    });
                  },
                ),
                ),

                new Divider(),
                SizedBox(height: 16.0),


                Container(
                  color: Constant.semiMandatoryColor,
                  child: new ListTile(

                  title: new Text(Translations.of(context).text('District')),
                  subtitle:
                  CustomerFormationMasterTabsState.addressBean.mDistCd == null || CustomerFormationMasterTabsState.addressBean.mDistCd == "null"
                      ? new Text("")
                      : new Text("${CustomerFormationMasterTabsState.addressBean.mDistCd} ${CustomerFormationMasterTabsState.addressBean.mdistdesc}"),
                  onTap: () async  {

                    tempDistrictBean =  await
                    Navigator.push(
                        context,
                        new MaterialPageRoute(
                          builder: (BuildContext context) => _myDistrictDialog,
                          fullscreenDialog: true,
                        ));


                    if(tempDistrictBean!=null){
                      try{
                        CustomerFormationMasterTabsState.addressBean.mDistCd = tempDistrictBean.distCd;
                        CustomerFormationMasterTabsState.addressBean.mdistdesc = tempDistrictBean.distDesc;
                      }catch(e){
                        print("District code exception");
                      }
                    }




                  },
                  ),
                ),

                new Divider(),
                SizedBox(height: 16.0),
                Container(
                  color: Constant.mandatoryColor,
                  child: new ListTile(

                    title: new Text(Translations.of(context).text('SubDistrict')),
                    subtitle: CustomerFormationMasterTabsState.addressBean.mplacecd == null ||
                        CustomerFormationMasterTabsState.addressBean.mplacecd == "null"
                        ? new Text("")
                        : new Text("${CustomerFormationMasterTabsState.addressBean.mplacecd} ${CustomerFormationMasterTabsState.addressBean.mplacedesc}"),
                    onTap: () async{

                      tempSubDistrictBean = await
                      Navigator.push(
                          context,
                          new MaterialPageRoute(
                            builder: (BuildContext context) =>
                            _mySubDistrictDialog,
                            fullscreenDialog: true,
                          ));
                      /*CustomerFormationMasterTabsState.addressBean.mP= int.parse(tempDistrictBean.distCd);*/
                      if(tempSubDistrictBean!=null){
                        CustomerFormationMasterTabsState.addressBean.mplacecd= tempSubDistrictBean.placeCd;
                        CustomerFormationMasterTabsState.addressBean.mplacedesc = tempSubDistrictBean.placeCdDesc;
                      }
                    },
                  ),
                ),

                new Divider(),
                SizedBox(height: 16.0),
                Container(
                  color: Constant.mandatoryColor,
                  child: new ListTile(
                    title: new Text(Translations.of(context).text('Area')),
                    subtitle:
                    CustomerFormationMasterTabsState.addressBean.marea == null || CustomerFormationMasterTabsState.addressBean.marea == "null"
                        ? new Text("")
                        : new Text("${CustomerFormationMasterTabsState.addressBean.marea} ${CustomerFormationMasterTabsState.addressBean.mareadesc}"),
                    onTap: () async {

                      tempAreaDistrict = await

                      Navigator.push(
                          context,
                          new MaterialPageRoute(
                            builder: (BuildContext context) => _myAreaDialog,
                            fullscreenDialog: true,
                          ));

                      if(tempAreaDistrict!=null){
                        try{
                          CustomerFormationMasterTabsState.addressBean.marea= tempAreaDistrict.areaCd;
                          CustomerFormationMasterTabsState.addressBean.mareadesc = tempAreaDistrict.areaDesc;
                        }catch(e){
                          print("area code exception");
                        }
                      }

                    },
                  ),
                ),


                new Divider(),

                Container(
                  color: Constant.semiMandatoryColor ,
                  child: new TextFormField(
                    textCapitalization: TextCapitalization.characters,
                  decoration:  InputDecoration(
                    hintText: Translations.of(context).text('AddrLine1Hint'),
                    labelText: Translations.of(context).text('AddrLine1'),
                    hintStyle: TextStyle(color: Colors.grey),
                    /*labelStyle: TextStyle(color: Colors.grey),*/
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff5c6bc0),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),
                  controller: CustomerFormationMasterTabsState.addressBean.maddr1 != null
                      ? TextEditingController(text: CustomerFormationMasterTabsState.addressBean.maddr1)
                      : TextEditingController(text: ""),
                  inputFormatters: [
                    new LengthLimitingTextInputFormatter(50)/*,
                    globals.onlyCharacter*/
                  ],
                  onSaved: (val) {
                    //  if(val!=null) {
                    CustomerFormationMasterTabsState.addressBean.maddr1 = val;
                    // }
                  },
                  ),
                ),Container(
                  color: Constant.semiMandatoryColor,
                  child: new TextFormField(
                    textCapitalization: TextCapitalization.characters,
                  decoration:  InputDecoration(
                    hintText: Translations.of(context).text('AddrLine2Hint'),
                    labelText: Translations.of(context).text('AddrLine2'),
                    hintStyle: TextStyle(color: Colors.grey),
                    /*labelStyle: TextStyle(color: Colors.grey),*/
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff5c6bc0),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),
                  controller: CustomerFormationMasterTabsState.addressBean.maddr2 != null
                      ? TextEditingController(text: CustomerFormationMasterTabsState.addressBean.maddr2)
                      : TextEditingController(text: ""),
                  inputFormatters: [
                    new LengthLimitingTextInputFormatter(50)/*,
                    globals.onlyCharacter*/
                  ],
                  onSaved: (val) {
                    //  if(val!=null) {
                    CustomerFormationMasterTabsState.addressBean.maddr2 = val;
                    // }
                  },
                  ),
                ),new TextFormField(
                  textCapitalization: TextCapitalization.characters,
                  decoration: const InputDecoration(
                    hintText: 'Enter Address Line 3  here',
                    labelText: 'Address Line 3',
                    hintStyle: TextStyle(color: Colors.grey),
                    /*labelStyle: TextStyle(color: Colors.grey),*/
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff5c6bc0),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),
                  controller: CustomerFormationMasterTabsState.addressBean.maddr3 != null
                      ? TextEditingController(text: CustomerFormationMasterTabsState.addressBean.maddr3)
                      : TextEditingController(text: ""),
                  inputFormatters: [
                    new LengthLimitingTextInputFormatter(50)/*,
                    globals.onlyCharacter*/
                  ],
                  onSaved: (val) {
                    //  if(val!=null) {
                    CustomerFormationMasterTabsState.addressBean.maddr3 = val;
                    // }
                  },
                )

               /* ,new TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Enter Thana here',
                    labelText: 'Thana',
                    hintStyle: TextStyle(color: Colors.grey),
                    *//*labelStyle: TextStyle(color: Colors.grey),*//*
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff5c6bc0),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),
                  controller: CustomerFormationMasterTabsState.addressBean.mThana != null
                      ? TextEditingController(text: CustomerFormationMasterTabsState.addressBean.mThana)
                      : TextEditingController(text: ""),
                  inputFormatters: [
                    new LengthLimitingTextInputFormatter(30),
                    globals.onlyCharacter
                  ],
                  onSaved: (val) {
                    //  if(val!=null) {
                    CustomerFormationMasterTabsState.addressBean.mThana = val;
                    // }
                  },
                )*/,Container(
          color: Constant.semiMandatoryColor,
          child: TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Enter year Of stay here',
                    labelText: 'Year of Stay',
                    hintStyle: TextStyle(color: Colors.grey),
                    /*labelStyle: TextStyle(color: Colors.grey),*/
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff5c6bc0),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),
                  keyboardType: TextInputType.number,
                  controller: CustomerFormationMasterTabsState.addressBean.mYearStay != null&&CustomerFormationMasterTabsState.addressBean.mYearStay != 0
                      ? TextEditingController(text: CustomerFormationMasterTabsState.addressBean.mYearStay.toString())
                      : TextEditingController(text: ""),
                  inputFormatters: [
                    new LengthLimitingTextInputFormatter(3),
                    globals.onlyIntNumber
                  ],
                  onSaved: (val) {
                    if(val!=null&&val!="") {
                      try{
                        CustomerFormationMasterTabsState.addressBean.mYearStay = int.parse(val);
                      }catch(e){

                      }

                    }

                  },
                ),
                ),
                Container(
                  color: Constant.semiMandatoryColor,
                  child: new TextFormField(
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    hintText: 'Enter Mobile Number here',
                    labelText: 'Mobile Number',
                    prefixText: "+855",
                    hintStyle: TextStyle(color: Colors.grey),
                    /*labelStyle: TextStyle(color: Colors.grey),*/
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff5c6bc0),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),
                  controller: CustomerFormationMasterTabsState.addressBean.mMobile != null
                      ? TextEditingController(text: CustomerFormationMasterTabsState.addressBean.mMobile)
                      : TextEditingController(text: ""),
                  inputFormatters: [
                    new LengthLimitingTextInputFormatter(12),
                    globals.onlyIntNumber
                  ],
                  onSaved: (val) {
                    //  if(val!=null) {
                    CustomerFormationMasterTabsState.addressBean.mMobile = val;
                    // }
                  },
                  ),
                ),
                Container(
                  color: Constant.semiMandatoryColor,
                  child:new TextFormField(
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      hintText: 'Enter TelePhone Number here',
                      labelText: 'TelePhone Number',
                      prefixText: "+855",
                      hintStyle: TextStyle(color: Colors.grey),
                      /*labelStyle: TextStyle(color: Colors.grey),*/
                      border: UnderlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.black,
                          )),
                      focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xff5c6bc0),
                          )),
                      contentPadding: EdgeInsets.all(20.0),
                    ),
                    controller: CustomerFormationMasterTabsState.addressBean.mtel1!= null
                        ? TextEditingController(text: CustomerFormationMasterTabsState.addressBean.mtel1)
                        : TextEditingController(text: ""),
                    inputFormatters: [
                      new LengthLimitingTextInputFormatter(12),
                      globals.onlyIntNumber
                    ],
                    onSaved: (val) {
                      //  if(val!=null) {
                      CustomerFormationMasterTabsState.addressBean.mtel1 = val;
                      // }
                    },
                  ),
                ),


                new Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Flexible(
                      child: new IconButton(
                        icon: new Icon(
                          Icons.format_list_bulleted,
                          color: Color(0xff07426A),
                          size: 50.0,
                        ),
                        onPressed: () {
                          _navigateAndDisplaySelection(context);
                        },
                      ),
                    ),
                    Flexible(
                        child: new IconButton(
                            padding: EdgeInsets.only(right: 30.0),
                            icon: new Icon(
                              Icons.add,
                              color: Color(0xff07426A),
                              size: 50.0,
                            ),
                            splashColor: Colors.red,
                            onPressed: () {
                              if (CustomerFormationMasterTabsState.addressBean.maddrType== "" ||
                                  CustomerFormationMasterTabsState.addressBean.maddrType == null) {
                                _showAlert(
                                    "Address Type", "Must Be Specified ");
                              }
                              else if(CustomerFormationMasterTabsState.addressBean.mownership==null||CustomerFormationMasterTabsState.addressBean.mownership==""){
                                _showAlert("Home Ownership", "Cannot be Empty");
                                return;
                              }
                              else if(CustomerFormationMasterTabsState.addressBean.mcountryCd==null||CustomerFormationMasterTabsState.addressBean.mcountryCd.toString().trim()==""){
                                _showAlert("Country", "Cannot be Empty");
                                return;
                              }
                              else if(CustomerFormationMasterTabsState.addressBean.mState==null||CustomerFormationMasterTabsState.addressBean.mState.trim()==""){
                                _showAlert("State", "Cannot be Empty");
                                return;
                              }
                              else if(CustomerFormationMasterTabsState.addressBean.mDistCd==null||CustomerFormationMasterTabsState.addressBean.mDistCd.toString().trim()==""){
                                _showAlert("district", "Cannot be Empty");
                                return;
                              }
                              else if(CustomerFormationMasterTabsState.addressBean.mplacecd==null||CustomerFormationMasterTabsState.addressBean.mplacecd.toString().trim()==""){
                                _showAlert("Subdistrict", "Cannot be Empty");
                                return;
                              }
                              else if(CustomerFormationMasterTabsState.addressBean.marea==null||CustomerFormationMasterTabsState.addressBean.marea.toString().trim()==""){
                                _showAlert("Village", "Cannot be Empty");
                                return;
                              }
                              else if(CustomerFormationMasterTabsState.addressBean.maddr1==null||CustomerFormationMasterTabsState.addressBean.maddr1.length<2){
                                _showAlert("Adress 1 ", "Must be more then 2 char");
                                return;
                              }
                              else if(CustomerFormationMasterTabsState.addressBean.maddr2==null||CustomerFormationMasterTabsState.addressBean.maddr2.length<2){
                                _showAlert("adress 2", "must be more than 2 char");
                                return;
                              }
                              else if(CustomerFormationMasterTabsState.addressBean.mYearStay==null||CustomerFormationMasterTabsState.addressBean.mYearStay.toString().trim()==""){
                                _showAlert("Years Of Stay", "Cannot be Empty");
                                return;
                              }
                              else if(CustomerFormationMasterTabsState.addressBean.mMobile==null||CustomerFormationMasterTabsState.addressBean.mMobile.length<8 || CustomerFormationMasterTabsState.addressBean.mMobile.length>11 ){
                                _showAlert("Mobile", "Must be 8/9/10 char long");
                                return;
                              }  else if(CustomerFormationMasterTabsState.addressBean.mtel1==null||CustomerFormationMasterTabsState.addressBean.mtel1.length<8  || CustomerFormationMasterTabsState.addressBean.mtel1.length>11){
                                _showAlert("Phone number", "Must be 8/9/10 char long");
                                return;
                              }
                              else
                                addToList();
                            })),
                  ],
                ),


                SizedBox(height: 30.0,)
              ],
            )));
  }

  _navigateAndDisplaySelection(BuildContext context) async {
    final result = Navigator.push(
        context,
        new MaterialPageRoute(
          builder: (BuildContext context) =>
          new ViewCustomerFormationAddressDetails(),
          fullscreenDialog: true,
        )).then((onValue) {
      setState(() {});
      //Scaffold.of(context).showSnackBar(SnackBar(content: Text("$onValue")));
    });
  }

  void addToList() {
   /* for (var items in globals.addressDetailsList) {
      print(items);
    }
*/
if(CustomerFormationMasterTabsState.custListBean.addressDetails==null){
  CustomerFormationMasterTabsState.custListBean.addressDetails= new  List<AddressDetailsBean>();
}
    CustomerFormationMasterTabsState.addressBean.trefno = CustomerFormationMasterTabsState.custListBean.trefno;
    if(CustomerFormationMasterTabsState.addressBean.mrefno==null) CustomerFormationMasterTabsState.addressBean.mrefno = 0;
    else CustomerFormationMasterTabsState.addressBean.mrefno = CustomerFormationMasterTabsState.custListBean.mrefno;

    CustomerFormationMasterTabsState.addressBean.maddressrefno = 0;

    CustomerFormationMasterTabsState.addressBean.taddrefno= CustomerFormationMasterTabsState.custListBean.addressDetails.length + 1;
    CustomerFormationMasterTabsState.addressBean.mgeolatd= geoLatitude;
    CustomerFormationMasterTabsState.addressBean.mgeologd=geoLongitude;


    CustomerFormationMasterTabsState.custListBean.addressDetails
        .add(CustomerFormationMasterTabsState.addressBean);

    print("adding");
    addressType = blankBean;
     mownership=blankBean;
    setState(() {
      CustomerFormationMasterTabsState.addressBean = new AddressDetailsBean();
    });


    print("local");

  }

  Future<void> _showAlert(arg, error) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('$arg error'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('$error.'),
              ],
            ),
          ),
          actions: <Widget>[
            FlatButton(
              child: Text('ok'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }


  Future<bool> onSelectAddress(
      BuildContext context, String agrs1, String args2) {
    return showDialog(
      context: context,
      builder: (context) => new AlertDialog(
        title: new Text(agrs1),
        content: new Text(args2),
        actions: <Widget>[
          new FlatButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: new Text('No'),
          ),
          new FlatButton(
            onPressed: () => setAddress(),
            child: new Text('Yes'),
          ),
        ],
      ),
    ) ??
        false;
  }

  setAddress() {

    int addressListFrom = CustomerFormationMasterTabsState.custListBean.addressDetails.length-1;
    CustomerFormationMasterTabsState.addressBean.maddr1= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].maddr1;
    CustomerFormationMasterTabsState.addressBean.maddr2= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].maddr2;
    CustomerFormationMasterTabsState.addressBean.maddr3= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].maddr3;
    CustomerFormationMasterTabsState.addressBean.mpinCd= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mpinCd;
    CustomerFormationMasterTabsState.addressBean.mtel1= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mtel1;
    CustomerFormationMasterTabsState.addressBean.mtel2= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mtel2;
    CustomerFormationMasterTabsState.addressBean.mcityCd= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mcityCd;
    CustomerFormationMasterTabsState.addressBean.mfax1= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mfax1;
    CustomerFormationMasterTabsState.addressBean.mfax2= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mfax2;


    CustomerFormationMasterTabsState.addressBean.mcountryCd= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mcountryCd;
    CustomerFormationMasterTabsState.addressBean.marea= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].marea;
    CustomerFormationMasterTabsState.addressBean.mHouseType= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mHouseType;
    CustomerFormationMasterTabsState.addressBean.mRntLeasAmt= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mRntLeasAmt;
    CustomerFormationMasterTabsState.addressBean.mRntLeasDep= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mRntLeasDep;
    CustomerFormationMasterTabsState.addressBean.mContLeasExp= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mContLeasExp;
    CustomerFormationMasterTabsState.addressBean.mRoofCond= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mRoofCond;


    CustomerFormationMasterTabsState.addressBean.mUtils= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mUtils;
    CustomerFormationMasterTabsState.addressBean.mAreaType= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mAreaType;
    CustomerFormationMasterTabsState.addressBean.mState= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mState;
    CustomerFormationMasterTabsState.addressBean.mYearStay= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mYearStay;
    CustomerFormationMasterTabsState.addressBean.mWardNo= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mWardNo;
    CustomerFormationMasterTabsState.addressBean.mMobile= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mMobile;
    CustomerFormationMasterTabsState.addressBean.mEmail= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mEmail;



    CustomerFormationMasterTabsState.addressBean.mDistCd= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mDistCd;
    CustomerFormationMasterTabsState.addressBean.mvillage= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mvillage;
    CustomerFormationMasterTabsState.addressBean.mSecMobile= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mSecMobile;
    CustomerFormationMasterTabsState.addressBean.mcountryname= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mcountryname;
    CustomerFormationMasterTabsState.addressBean.mstatedesc= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mstatedesc;
    CustomerFormationMasterTabsState.addressBean.mdistdesc= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mdistdesc;
    CustomerFormationMasterTabsState.addressBean.mplacecd= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mplacecd;

    CustomerFormationMasterTabsState.addressBean.mplacedesc= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mplacedesc;
    CustomerFormationMasterTabsState.addressBean.mareadesc= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mareadesc;
    CustomerFormationMasterTabsState.addressBean.mownership= CustomerFormationMasterTabsState.custListBean.addressDetails[addressListFrom].mownership;

    addToList();
    Navigator.of(context).pop(true);
  }

}

