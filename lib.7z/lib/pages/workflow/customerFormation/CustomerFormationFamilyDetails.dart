import 'package:eco_los/Utilities/app_constant.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:eco_los/pages/workflow/LookupMasterBean.dart';
import 'package:eco_los/pages/workflow/centerfoundation/bean/CenterFormationMasterListViewBean.dart';
import 'dart:async';
import 'package:eco_los/Utilities/globals.dart' as globals;

import 'package:eco_los/pages/workflow/centerfoundation/bean/CenterFormationMasterSubmissionBean.dart';
import 'package:eco_los/pages/workflow/centerfoundation/CenterFormationSubmissionService.dart';
import 'package:eco_los/pages/workflow/customerFormation/CustomerFormationMasterTabs.dart';
import 'package:eco_los/pages/workflow/customerFormation/ViewCustomerFormationFamilyDetails.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/FamilyDetailsBean.dart';

class CustomerFormationFamilyDetails extends StatefulWidget {
  CustomerFormationFamilyDetails({Key key}) : super(key: key);

  static Container _get(Widget child,
          [EdgeInsets pad = const EdgeInsets.all(6.0)]) =>
      new Container(
        padding: pad,
        child: child,
      );

  @override
  _CustomerFormationFamilyDetailsState createState() =>
      new _CustomerFormationFamilyDetailsState();
}

class _CustomerFormationFamilyDetailsState
    extends State<CustomerFormationFamilyDetails> {

  var formatter = new DateFormat('dd-MM-yyyy');
  final GlobalKey<FormState> _formKey = new GlobalKey<FormState>();
  LookupBeanData education;
  LookupBeanData relationShip;
  LookupBeanData occupation;
  LookupBeanData married;
  LookupBeanData title;
  LookupBeanData reverseRelationship;
  LookupBeanData mdesignatio;
  String tempDobDay;
  String tempDobMonth;
  String tempDobYear;

  FocusNode DobMonthFocus;
  FocusNode DobYearFocus;


  int count = 0;
  final TextEditingController _controller = new TextEditingController();
  static bool isSubmitClicked = false;
  FamilyDetailsBean fdb = new FamilyDetailsBean();
  final List<FamilyDetailsBean> familyObjectListLoacl =
      new List<FamilyDetailsBean>();

  bool isBool = false;
  int i = 0;

  bool ifNullCheck(String value) {
    bool isNull = false;
    try {
      if (value == null || value == 'null' || value.trim()=='') {
        isNull = true;
      }
    }catch(_){
      isNull =true;
    }
    return isNull;
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    DobMonthFocus= new FocusNode();
    DobYearFocus= new FocusNode();


    if(!CustomerFormationMasterTabsState.famDob.contains("_")){
      try{
        print("inside try");

        String tempDobDate = CustomerFormationMasterTabsState.famDob;
        DateTime  formattedDate =  DateTime.parse(tempDobDate.substring(6)+"-"+tempDobDate.substring(3,5)+"-"+tempDobDate.substring(0,2));
        print(formattedDate);

        tempDobDay = formattedDate.day.toString();
        if(tempDobDay.length ==1)tempDobDay = "0"+tempDobDay;
        print(tempDobDay);
        tempDobMonth = formattedDate.month.toString();
        if(tempDobMonth.length ==1)tempDobMonth= "0"+tempDobMonth;
        print(tempDobMonth);
        tempDobYear = formattedDate.year.toString();
        if(tempDobYear.length ==1)tempDobYear= "0"+tempDobYear;
        print(tempDobYear);
        setState(() {

        });

      }catch(e){

        print("Exception Occupred fam dob");
      }
    }

    if (!isBool) {
      isBool = true;
    }

    if(CustomerFormationMasterTabsState.fdb!=null){


      for (int k = 0; k < globals.dropdownCaptionsValuesFamilyDetails.length; k++) {
        for (int i = 0; i < globals.dropdownCaptionsValuesFamilyDetails[k].length; i++) {


          if (k == 0) {
            print("for k = 0 codes are ${globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode}");
            if (globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode ==
                CustomerFormationMasterTabsState.fdb.meducation) {

              setValue(k, globals.dropdownCaptionsValuesFamilyDetails[k][i]);


            }
          }

          if (k == 1) {
            print("for k = 1 codes are ${globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode}");
            if (globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode ==
                CustomerFormationMasterTabsState.fdb.mrelationwithcust) {

              setValue(k, globals.dropdownCaptionsValuesFamilyDetails[k][i]);


            }



          }

          if (k == 2) {
            print("for k = 2 codes are ${globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode}");
            if (globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode ==
                CustomerFormationMasterTabsState.fdb.moccuptype.toString()) {

              setValue(k, globals.dropdownCaptionsValuesFamilyDetails[k][i]);


            }
          }

          if (k == 3) {
            print("for k = 2 codes are ${globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode}");
            if (globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode ==
                CustomerFormationMasterTabsState.fdb.maritalstatus.toString()) {

              setValue(k, globals.dropdownCaptionsValuesFamilyDetails[k][i]);


            }
          }

          if (k == 4) {
            print("for k = 2 codes are ${globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode}");
            if (globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode ==
                CustomerFormationMasterTabsState.fdb.mnametitle.toString()) {

              setValue(k, globals.dropdownCaptionsValuesFamilyDetails[k][i]);


            }
          }

          if (k == 5) {
            print("for k = 2 codes are ${globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode}");
            if (globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode ==
                CustomerFormationMasterTabsState.fdb.mreverseRelationship.toString()) {

              setValue(k, globals.dropdownCaptionsValuesFamilyDetails[k][i]);


            }
          }    if (k == 6) {
            print("for k = 2 codes are ${globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode}");
            if (globals.dropdownCaptionsValuesFamilyDetails[k][i].mcode ==
                CustomerFormationMasterTabsState.fdb.mdesignation.toString()) {

              setValue(k, globals.dropdownCaptionsValuesFamilyDetails[k][i]);


            }
          }
        }


      }
    }else{
      CustomerFormationMasterTabsState.fdb= new FamilyDetailsBean();
    }


    for(int i = 0;i<CustomerFormationMasterTabsState.familyDependantRadio.length;i++){
      if(CustomerFormationMasterTabsState.familyDependantRadio[i]==null)CustomerFormationMasterTabsState.familyDependantRadio[i]= 0;
    }
    if (!ifNullCheck(CustomerFormationMasterTabsState.fdb.mmemberno)) {
      CustomerFormationMasterTabsState.familyDependantRadio[0] =
          int.parse(CustomerFormationMasterTabsState.fdb.mmemberno);
    }
    else{
      CustomerFormationMasterTabsState.fdb.mmemberno = "0";
    }

    if (CustomerFormationMasterTabsState.fdb.misearngmembr !=null) {
      CustomerFormationMasterTabsState.familyDependantRadio[1] =
          CustomerFormationMasterTabsState.fdb.misearngmembr;
    }
    else{
      CustomerFormationMasterTabsState.fdb.misearngmembr = 0;
    }


    if (CustomerFormationMasterTabsState.fdb.misstudyingmembr !=null) {
      CustomerFormationMasterTabsState.familyDependantRadio[2] =
          CustomerFormationMasterTabsState.fdb.misstudyingmembr;
    }
    else{
      CustomerFormationMasterTabsState.fdb.misstudyingmembr = 0;
    }
  }

  Widget dependantRadio() => CustomerFormationFamilyDetails._get(new Row(
        children: _makeRadios(2, globals.radioCaptionValuesIsDependant, 0),
        mainAxisAlignment: MainAxisAlignment.spaceAround,
      ));

  Widget misearngmembr() => CustomerFormationFamilyDetails._get(new Row(
    children: _makeRadios(2, globals.radioCaptionValuesIsDependant, 1),
    mainAxisAlignment: MainAxisAlignment.spaceAround,
  ));

  Widget misstudyingmembr() => CustomerFormationFamilyDetails._get(new Row(
    children: _makeRadios(2, globals.radioCaptionValuesIsDependant, 2),
    mainAxisAlignment: MainAxisAlignment.spaceAround,
  ));
  Widget misleavingwithappcnt() => CustomerFormationFamilyDetails._get(new Row(
    children: _makeRadios(2, globals.radioCaptionValuesIsDependant, 3),
    mainAxisAlignment: MainAxisAlignment.spaceAround,
  ));



  List<Widget> _makeRadios(int numberOfRadios, List textName, int position) {
    /*print(
        "dumper " + CustomerFormationMasterTabsState.fdb.mmemberno.toString());*/
    List<Widget> radios = new List<Widget>();
    for (int i = 0; i < numberOfRadios; i++) {
      radios.add(new Row(
        children: <Widget>[
          new Text(
            textName[i],
            textAlign: TextAlign.right,
            style: new TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey,
              fontStyle: FontStyle.normal,
              fontSize: 10.0,
            ),
          ),
          new Radio(
            value: i,
            groupValue: CustomerFormationMasterTabsState.familyDependantRadio[position],
            onChanged: (selection) => _onRadioSelected(selection, position),
            activeColor: Color(0xff07426A),
          ),
        ],
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
      ));
    }
    return radios;
  }

  _onRadioSelected(int selection, int position) {
    setState(() => CustomerFormationMasterTabsState.familyDependantRadio[position] = selection);
    if (position == 0) {
      CustomerFormationMasterTabsState.fdb.mmemberno = selection.toString();
    }

    if (position == 1) {
      CustomerFormationMasterTabsState.fdb.misearngmembr = selection;
    }

    if (position == 2) {
      CustomerFormationMasterTabsState.fdb.misstudyingmembr = selection;
    }

    if (position == 3) {
      CustomerFormationMasterTabsState.fdb.misstudyingmembr = selection;
    }
  }

  Widget getTextContainer(String textValue) {
    return new Container(
      padding: EdgeInsets.fromLTRB(5.0, 20.0, 0.0, 20.0),
      child: new Text(
        textValue,
        //textDirection: TextDirection,
        textAlign: TextAlign.start,
        /*overflow: TextOverflow.ellipsis,*/
        style: new TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.grey,
            fontStyle: FontStyle.normal,
            fontSize: 12.0),
      ),
    );
  }

  showDropDown(LookupBeanData selectedObj, int no) {

    print("selected Obj is ${selectedObj}");
    if(selectedObj.mcodedesc.isEmpty){
      print("inside  code Desc is null");
      switch (no) {
        case 0:
          education = blankBean;
          CustomerFormationMasterTabsState.fdb.meducation = selectedObj.mcode;
          break;
        case 1:
          relationShip = blankBean;
          CustomerFormationMasterTabsState.fdb.mrelationwithcust = selectedObj.mcode;
          break;
        case 2:
          occupation = blankBean;
          CustomerFormationMasterTabsState.fdb.moccuptype = int.parse(selectedObj.mcode);
          break;
        case 3:
          married = blankBean;
          CustomerFormationMasterTabsState.fdb.maritalstatus = selectedObj.mcode;
          break;
        case 4:
          title = blankBean;
          CustomerFormationMasterTabsState.fdb.mnametitle = selectedObj.mcode;
          break;
        case 5:
          reverseRelationship = blankBean;
          CustomerFormationMasterTabsState.fdb.mreverseRelationship = selectedObj.mcode;
          break;
        case 6:
          mdesignatio = blankBean;
          CustomerFormationMasterTabsState.fdb.mdesignation = blankBean.mcode;
          break;
        default:
          break;
      }
    setState(() {

    });
    }
    else {
      bool isBreak = false;
      for (int k = 0;
      k < globals.dropdownCaptionsValuesFamilyDetails[no].length;
      k++) {
        if (globals.dropdownCaptionsValuesFamilyDetails[no][k].mcodedesc ==
            selectedObj.mcodedesc) {
          setValue(no, globals.dropdownCaptionsValuesFamilyDetails[no][k]);
          isBreak=true;
          break;
        }
        if(isBreak){
          break;
        }
      }
    }


  }
  LookupBeanData blankBean = new LookupBeanData(mcodedesc: "",mcode: "",mcodetype: 0);


  setValue(int no, LookupBeanData value) {
    print("value is ${value}");
    setState(() {
      print("coming here");
      switch (no) {
        case 0:
          education = value;
          CustomerFormationMasterTabsState.fdb.meducation = value.mcode;
          /*CustomerFormationMasterTabsState.custListBean.familyDetailsList.last.education = value.code;*/

          break;
        case 1:
          relationShip = value;
          CustomerFormationMasterTabsState.fdb.mrelationwithcust = value.mcode;
          /*CustomerFormationMasterTabsState.custListBean.familyDetailsList.last.relationship = value.code;*/
          break;
        case 2:
          occupation = value;
          CustomerFormationMasterTabsState.fdb.moccuptype = int.parse(value.mcode);
          break;
        case 3:
          married = value;
          CustomerFormationMasterTabsState.fdb.maritalstatus = value.mcode;
          break;
        case 4:
          title = value;
          CustomerFormationMasterTabsState.fdb.mnametitle = value.mcode;
          break;
        case 5:
          reverseRelationship = value;
          CustomerFormationMasterTabsState.fdb.mreverseRelationship = value.mcode;
          break;
        case 6:
          mdesignatio = value;
          CustomerFormationMasterTabsState.fdb.mdesignation = value.mcode;
          break;
        default:
          break;
      }
    });
  }

  List<DropdownMenuItem<LookupBeanData>> generateDropDown(int no) {
    print("caption value : " + globals.dropdownCaptionsFamilyDetails[no]);

    List<DropdownMenuItem<LookupBeanData>> _dropDownMenuItems1;
    List<LookupBeanData> mapData = List<LookupBeanData>();
    LookupBeanData bean = new LookupBeanData();
    bean.mcodedesc = "";
    bean.mcode = "";
    bean.mcodetype = 0;
    mapData.add(blankBean);
    for (int k = 0;
    k < globals.dropdownCaptionsValuesFamilyDetails[no].length;
    k++) {
      mapData.add(globals.dropdownCaptionsValuesFamilyDetails[no][k]);
    }
    _dropDownMenuItems1 = mapData.map((value) {
      print("data here is of  dropdownwale biayajai " + value.mcodedesc);
      return new DropdownMenuItem<LookupBeanData>(
        value: value,
        child: new Text(value.mcodedesc),
      );
    }).toList();
    /*   if(no==0){
      print(mapData);
      testString = mapData;
    }*/
    return _dropDownMenuItems1;
  }




  @override
  Widget build(BuildContext context) {
    return new SafeArea(
        top: false,
        bottom: false,
        child: new Form(
            key: _formKey,
            /* onWillPop: () {
              return Future(() => true);
            },*/
            onChanged: () {
              final FormState form = _formKey.currentState;
              form.save();
            },
            autovalidate: true,
            child: new ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              children: <Widget>[
                SizedBox(height: 10.0,),

                new DropdownButtonFormField(
                  value: title==null?null:title,
                  items: generateDropDown(4),
                  onChanged: (LookupBeanData newValue) {
                    showDropDown(newValue, 4);
                  },
                  validator: (args) {
                    print(args);
                  },
                  //  isExpanded: true,
                  //hint:Text("Select"),
                  decoration: InputDecoration(labelText: globals.dropdownCaptionsFamilyDetails[4]),
                  // style: TextStyle(color: Colors.grey),
                ),

                new TextFormField(
                  keyboardType: TextInputType.text,
                  textCapitalization: TextCapitalization.characters,
                  decoration: const InputDecoration(
                    hintText: 'Enter First Name',
                    labelText: 'First Name',
                    hintStyle: TextStyle(color: Colors.grey),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                      color: Color(0xff07426A),
                    )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),
                  controller: CustomerFormationMasterTabsState.fdb.mfname != null
                      ? TextEditingController(text: CustomerFormationMasterTabsState.fdb.mfname)
                      : TextEditingController(text: ""),
                  inputFormatters: [new LengthLimitingTextInputFormatter(50),globals.onlyCharacter],
                  onSaved: (val) {
                    //if(val!=null) {
                    //globals.familyMember = val;
                    /*CustomerFormationMasterTabsState.custListBean
                        .familyDetailsList.last.name = val;*/
                    CustomerFormationMasterTabsState.fdb.mfname = val;
                    //}
                  },
                ),
                SizedBox(height: 10.0,),
                new TextFormField(
                  keyboardType: TextInputType.text,
                    textCapitalization: TextCapitalization.characters,
                  decoration: const InputDecoration(
                  hintText: 'Enter Middle Name',
                  labelText: 'Middle Name',
                  hintStyle: TextStyle(color: Colors.grey),
                  focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Color(0xff07426A),
                      )),
                  contentPadding: EdgeInsets.all(20.0),
                ),
                  controller: CustomerFormationMasterTabsState.fdb.mmname != null
                      ? TextEditingController(text: CustomerFormationMasterTabsState.fdb.mmname)
                      : TextEditingController(text: ""),
                  inputFormatters: [new LengthLimitingTextInputFormatter(50),globals.onlyCharacter],
                  onSaved: (val) {
                    //if(val!=null) {
                    //globals.familyMember = val;
                    /*CustomerFormationMasterTabsState.custListBean
                        .familyDetailsList.last.name = val;*/
                    CustomerFormationMasterTabsState.fdb.mmname = val;
                    //}
                  },
                ),

                SizedBox(height: 10.0,),
                new TextFormField(
                  keyboardType: TextInputType.text,
    textCapitalization: TextCapitalization.characters
                  ,decoration: const InputDecoration(
                  hintText: 'Enter Last Name',
                  labelText: 'Last Name',
                  hintStyle: TextStyle(color: Colors.grey),
                  focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Color(0xff07426A),
                      )),
                  contentPadding: EdgeInsets.all(20.0),
                ),
                  controller: CustomerFormationMasterTabsState.fdb.mlname != null
                      ? TextEditingController(text: CustomerFormationMasterTabsState.fdb.mlname)
                      : TextEditingController(text: ""),
                  inputFormatters: [new LengthLimitingTextInputFormatter(50),globals.onlyCharacter],
                  onSaved: (val) {
                    //if(val!=null) {
                    //globals.familyMember = val;
                    /*CustomerFormationMasterTabsState.custListBean
                        .familyDetailsList.last.name = val;*/
                    CustomerFormationMasterTabsState.fdb.mlname = val;
                    //}
                  },
                ),
                SizedBox(height: 20.0,),
                Container(
                  decoration: BoxDecoration(color: Constant.mandatoryColor),
                  child: new Row(

                    children: <Widget>[Text("Date Of Birth")],
                  ),
                ),

                new Container(
                  decoration: BoxDecoration(color: Constant.mandatoryColor,),



                  child: new Row(
                    children: <Widget>[
                      new Container(
                        width: 50.0,
                        child: new TextField(
                          decoration:
                          InputDecoration(
                              hintText: "DD"
                          ),
                          inputFormatters: [
                            new LengthLimitingTextInputFormatter(2),
                            globals.onlyIntNumber
                          ],
                          controller: tempDobDay == null?null:new TextEditingController(text: tempDobDay),
                          keyboardType: TextInputType.numberWithOptions(),

                          onChanged: (val){

                            if(val!="0"){
                              tempDobDay = val;


                              if(int.parse(val)<=31&&int.parse(val)>0){



                                if(val.length==2){
                                  CustomerFormationMasterTabsState.famDob = CustomerFormationMasterTabsState.famDob.replaceRange(0, 2, val);
                                  FocusScope.of(context).requestFocus(DobMonthFocus);
                                }
                                else{
                                  CustomerFormationMasterTabsState.famDob = CustomerFormationMasterTabsState.famDob.replaceRange(0, 2, "0"+val);
                                }


                              }
                              else {
                                setState(() {
                                  tempDobDay ="";
                                });

                              }
                            }



                          },
                        ),

                      )
                      ,


                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: new Text("/"),
                      ),
                      new Container(
                        width: 50.0,
                        child: new TextField(
                          decoration: InputDecoration(
                            hintText: "MM",


                          ),

                          keyboardType: TextInputType.numberWithOptions(),
                          inputFormatters: [
                            new LengthLimitingTextInputFormatter(2),
                            globals.onlyIntNumber
                          ],
                          focusNode: DobMonthFocus,
                          controller: tempDobMonth== null?null:new TextEditingController(text: tempDobMonth),
                          onChanged: (val){

                            if(val!="0"){
                              tempDobMonth = val;
                              if(int.parse(val)<=12&&int.parse(val)>0){

                                if(val.length==2){
                                  CustomerFormationMasterTabsState.famDob = CustomerFormationMasterTabsState.famDob.replaceRange(3, 5, val);

                                  FocusScope.of(context).requestFocus(DobYearFocus);

                                }
                                else{
                                  CustomerFormationMasterTabsState.famDob = CustomerFormationMasterTabsState.famDob.replaceRange(3, 5, "0"+val);
                                }
                              }
                              else {
                                setState(() {
                                  tempDobMonth ="";
                                });

                              }
                            }


                          },

                        ),
                      )
                      ,
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: new Text("/"),
                      ),

                      Container(
                        width:80,

                        child:new TextField(


                          decoration: InputDecoration(
                            hintText: "YYYY",

                          ),

                          keyboardType: TextInputType.numberWithOptions(),
                          inputFormatters: [
                            new LengthLimitingTextInputFormatter(4),
                            globals.onlyIntNumber
                          ],


                          focusNode: DobYearFocus,
                          controller: tempDobYear== null?null:new TextEditingController(text: tempDobYear),
                          onChanged: (val){
                            tempDobYear = val;
                            if(val.length==4){
                              CustomerFormationMasterTabsState.famDob = CustomerFormationMasterTabsState.famDob.replaceRange(6, 10,val);
                              print(CustomerFormationMasterTabsState.famDob);
                            }

                          },
                        ),)
                      ,

                      SizedBox(
                        width: 50.0,
                      ),
                      IconButton(icon: Icon(Icons.calendar_today), onPressed:(){
                        _selectDobDate(context);
                      } )
                    ],



                  ),

                ),

              /*  new TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Enter Age here',
                    labelText: 'Age',
                    hintStyle: TextStyle(color: Colors.grey),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                      color: Colors.red,
                    )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                      color: Color(0xff07426A),
                    )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),

                  controller:  CustomerFormationMasterTabsState.fdb.mage != null&& CustomerFormationMasterTabsState.fdb.mage != 0
                      ? TextEditingController(text: CustomerFormationMasterTabsState.fdb.mage.toString())
                      : TextEditingController(text:""),
                  keyboardType: TextInputType.number,
                  inputFormatters: [new LengthLimitingTextInputFormatter(2),globals.onlyIntNumber],
                  onSaved: (val) {
                     if(val!=null&&val!="") {
                      // globals.age = int.parse(val);
                       *//*CustomerFormationMasterTabsState.custListBean
                           .familyDetailsList.last.age =  int.parse(val);*//*
                       try{
                         CustomerFormationMasterTabsState.fdb.mage = int.parse(val);
                       }catch(e){

                       }

                     }
                     else{
                      // globals.age = 0;
                       *//*CustomerFormationMasterTabsState.custListBean
                           .familyDetailsList.last.age =0;*//*
                       CustomerFormationMasterTabsState.fdb.mage = 0;
                     }

                    //}
                  },
                ),

*/
                new DropdownButtonFormField(
                  value: education==null?null: education,
                  items: generateDropDown(0),
                  onChanged: (LookupBeanData newValue) {
                    print("new Value is ${newValue}");
                    showDropDown(newValue, 0);
                  },
                  validator: (args) {
                    print(args);
                  },
                  //  isExpanded: true,
                  //hint:Text("Select"),
                  decoration: InputDecoration(labelText: globals.dropdownCaptionsFamilyDetails[0]),
                  // style: TextStyle(color: Colors.grey),
                ),
                new DropdownButtonFormField(
                  value: relationShip==null?null:relationShip,
                  items: generateDropDown(1),
                  onChanged: (LookupBeanData newValue) {
                    showDropDown(newValue, 1);
                  },
                  validator: (args) {
                    print(args);
                  },
                  //  isExpanded: true,
                  //hint:Text("Select"),
                  decoration: InputDecoration(labelText: globals.dropdownCaptionsFamilyDetails[1]),
                  // style: TextStyle(color: Colors.grey),
                ),
                new DropdownButtonFormField(
                  value: reverseRelationship==null?null: reverseRelationship,
                  items: generateDropDown(5),
                  onChanged: (LookupBeanData newValue) {
                    print("new Value is ${newValue}");
                    showDropDown(newValue, 5);
                  },
                  validator: (args) {
                    print(args);
                  },
                  //  isExpanded: true,
                  //hint:Text("Select"),
                  decoration: InputDecoration(labelText: globals.dropdownCaptionsFamilyDetails[5]),
                  // style: TextStyle(color: Colors.grey),
                ),
                new DropdownButtonFormField(
                  value: married==null?null:married,
                  items: generateDropDown(3),
                  onChanged: (LookupBeanData newValue) {
                    showDropDown(newValue, 3);
                  },
                  validator: (args) {
                    print(args);
                  },
                  //  isExpanded: true,
                  //hint:Text("Select"),
                  decoration: InputDecoration(labelText: globals.dropdownCaptionsFamilyDetails[3]),
                  // style: TextStyle(color: Colors.grey),
                ),
                new DropdownButtonFormField(
                  value: occupation==null?null:occupation,
                  items: generateDropDown(2),
                  onChanged: (LookupBeanData newValue) {
                    showDropDown(newValue, 2);
                  },
                  validator: (args) {
                    print(args);
                  },
                  //  isExpanded: true,
                  //hint:Text("Select"),
                  decoration: InputDecoration(labelText: globals.dropdownCaptionsFamilyDetails[2]),
                  // style: TextStyle(color: Colors.grey),
                ),
                SizedBox(height: 10.0,),

                new DropdownButtonFormField(
                  value: mdesignatio==null?null: mdesignatio,
                  items: generateDropDown(6),
                  onChanged: (LookupBeanData newValue) {
                    print("new Value is ${newValue}");
                    showDropDown(newValue, 6);
                  },
                  validator: (args) {
                    print(args);
                  },
                  //  isExpanded: true,
                  //hint:Text("Select"),
                  decoration: InputDecoration(labelText: globals.dropdownCaptionsFamilyDetails[6]),
                  // style: TextStyle(color: Colors.grey),
                ),

              /*  new TextFormField(
                  keyboardType: TextInputType.text,
                  textCapitalization: TextCapitalization.sentences
                  ,decoration: const InputDecoration(
                  hintText: 'Enter Designation',
                  labelText: 'Designation',
                  hintStyle: TextStyle(color: Colors.grey),
                  focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Color(0xff07426A),
                      )),
                  contentPadding: EdgeInsets.all(20.0),
                ),
                  controller: CustomerFormationMasterTabsState.fdb.mdesignation != null
                      ? TextEditingController(text: CustomerFormationMasterTabsState.fdb.mdesignation)
                      : TextEditingController(text: ""),
                  inputFormatters: [new LengthLimitingTextInputFormatter(50),globals.onlyCharacter],
                  onSaved: (val) {
                    //if(val!=null) {
                    //globals.familyMember = val;
                    *//*CustomerFormationMasterTabsState.custListBean
                        .familyDetailsList.last.name = val;*//*
                    CustomerFormationMasterTabsState.fdb.mdesignation = val;
                    //}
                  },
                ),*/
                new Table(children: [
                  new TableRow(
                      decoration: new BoxDecoration(
                        border: Border.all(color: Colors.grey, width: 0.1),
                      ),
                      children: [
                        getTextContainer(globals.radioCaptionDependantYN[0]),
                        dependantRadio(),
                      ]),
                ]),
                new Table(children: [
                  new TableRow(
                      decoration: new BoxDecoration(
                        border: Border.all(color: Colors.grey, width: 0.1),
                      ),
                      children: [
                        getTextContainer(globals.radioCaptionDependantYN[1]),
                        misearngmembr(),
                      ]),
                ]),
                new Table(children: [
                  new TableRow(
                      decoration: new BoxDecoration(
                        border: Border.all(color: Colors.grey, width: 0.1),
                      ),
                      children: [
                        getTextContainer(globals.radioCaptionDependantYN[2]),
                        misstudyingmembr(),
                      ]),
                ]),
                new Table(children: [
                  new TableRow(
                      decoration: new BoxDecoration(
                        border: Border.all(color: Colors.grey, width: 0.1),
                      ),
                      children: [
                        getTextContainer(globals.radioCaptionDependantYN[3]),
                        misleavingwithappcnt(),
                      ]),
                ]),
                new Container(
                  width: 300.0,
                  height: 10.0,
                ),
                new Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Flexible(
                      child: new IconButton(
                        icon: new Icon(
                          Icons.format_list_bulleted,
                          color: Color(0xff07426A),
                          size: 50.0,
                        ),
                        onPressed: () {
                          _navigateAndDisplaySelection(context);
                        },
                      ),
                    ),
                    Flexible(
                        child: new IconButton(
                            padding: EdgeInsets.only(right: 30.0),
                            icon: new Icon(
                              Icons.add,
                              color: Color(0xff07426A),
                              size: 50.0,
                            ),
                            splashColor: Colors.red,
                            onPressed: () {

                              if(!CustomerFormationMasterTabsState.famDob.contains("_")){
                                try{
                                  String tempLoanDate = CustomerFormationMasterTabsState.famDob;
                                 //print(tempLoanDate.substring(6)+"-"+tempLoanDate.substring(3,5)+"-"+tempLoanDate.substring(0,2));
                                  CustomerFormationMasterTabsState.fdb.mdob=  DateTime.parse(tempLoanDate.substring(6)+"-"+tempLoanDate.substring(3,5)+"-"+tempLoanDate.substring(0,2));
                                }catch( e){
                                  _showAlert("DOB", "Birth Date Error");
                                  return;
                                }
                              }else {

                              }
                              addToList();
                            })),
                  ],
                ),
              ],
            )));
  }

  _navigateAndDisplaySelection(BuildContext context) async {
    final result = Navigator.push(
        context,
        new MaterialPageRoute(
          builder: (BuildContext context) =>
              new ViewCustomerFormationFamilyDetails(),
          fullscreenDialog: true,
        )).then((onValue) {
      setState(() {});
      //Scaffold.of(context).showSnackBar(SnackBar(content: Text("$onValue")));
    });
  }

  void addToList() {

    if(CustomerFormationMasterTabsState.custListBean.familyDetailsList==null){
      CustomerFormationMasterTabsState.custListBean.familyDetailsList= new  List<FamilyDetailsBean>();
    }


    if(CustomerFormationMasterTabsState.fdb.mfname!=null&&CustomerFormationMasterTabsState.fdb.mfname!="null"){
     // int listLength = globals.familyDetailsList.length;
      print("adding ${CustomerFormationMasterTabsState.fdb}");
      CustomerFormationMasterTabsState.fdb.trefno = CustomerFormationMasterTabsState.custListBean.trefno;
      if(CustomerFormationMasterTabsState.custListBean.mrefno==null) CustomerFormationMasterTabsState.fdb.mrefno = 0;
     else  CustomerFormationMasterTabsState.fdb.mrefno = CustomerFormationMasterTabsState.custListBean.mrefno;

      CustomerFormationMasterTabsState.fdb.mfamilyrefno = 0;



      CustomerFormationMasterTabsState.fdb.tfamilyrefno = CustomerFormationMasterTabsState.custListBean.familyDetailsList.length + 1;

      CustomerFormationMasterTabsState.custListBean.familyDetailsList.add(CustomerFormationMasterTabsState.fdb);

      education = blankBean;
      relationShip = blankBean;
      occupation = blankBean;
      reverseRelationship = blankBean;
      married = blankBean;
      title = blankBean;
      //globals.familyDetailsList.insert(listLength, fdb);

        setState(() {
          tempDobDay = "";
          tempDobMonth= "";
          tempDobYear= "";
          CustomerFormationMasterTabsState.famDob = "__-__-____";
          CustomerFormationMasterTabsState.fdb = new FamilyDetailsBean();
        });

    } else {
      globals.Dialog.alertPopup(context,"Error","Please Add Member name, Member name should not be blank","Family" );
    }
  }


    Future<Null> _selectDobDate(BuildContext context) async {
      final DateTime picked = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime(1800, 8),
          lastDate: DateTime.now());
      if (picked != null )
        setState(() {
          CustomerFormationMasterTabsState
              .famDob=formatter.format(picked);
          if(picked.day.toString().length==1){
            tempDobDay= "0"+picked.day.toString();
          }
          else tempDobDay= picked.day.toString();

          if(picked.month.toString().length==1){
            tempDobMonth= "0"+picked.month.toString();
          }
          else
            tempDobMonth= picked.month.toString();
          tempDobYear= picked.year.toString();
        });
    }
  Future<void> _showAlert(String error, String message) async {
    return showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("${error} error"),
            content: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[
                  new Text("${error} error"),
                  new Text("${message}"),
                ],
              ),
            ),
            actions: <Widget>[
              new FlatButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text("Ok")),
            ],
          );
        });
  }
}

