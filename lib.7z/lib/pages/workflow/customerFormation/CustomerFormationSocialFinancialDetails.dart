import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:eco_los/Utilities/app_constant.dart';
import 'package:eco_los/Utilities/globals.dart' as globals;
import 'package:eco_los/Utilities/globals.dart';
import 'package:eco_los/pages/workflow/LookupMasterBean.dart';
import 'package:eco_los/pages/workflow/customerFormation/CustomerFormationMasterTabs.dart';
import 'package:eco_los/pages/workflow/customerFormation/ViewAssetDetails.dart';
import 'package:eco_los/pages/workflow/customerFormation/bean/AssetDetailsBean.dart';
import 'package:intl/intl.dart';

import '../../../translations.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
class CustomerFormationSocialFinancialDetails extends StatefulWidget {
  CustomerFormationSocialFinancialDetails();
  /* final isNewCustomerComingFromList ;
  CustomerFormationSocialFinancialDetails(
      {Key key, @required this.isNewCustomerComingFromList})
      : super(key: key);
*/
  static Container _get(Widget child,
      [EdgeInsets pad = const EdgeInsets.all(6.0)]) =>
      new Container(
        padding: pad,
        child: child,
      );

  @override
  _CustomerFormationSocialFinancialDetailsState createState() =>
      new _CustomerFormationSocialFinancialDetailsState();
}

class _CustomerFormationSocialFinancialDetailsState
    extends State<CustomerFormationSocialFinancialDetails> {


  LookupBeanData blankBean = new LookupBeanData(mcodedesc: "",mcode: "",mcodetype: 0);
  final formatDouble = new NumberFormat("#,##0.00", "en_US");
  final TextEditingController _typeAheadController = TextEditingController();
  final GlobalKey<FormState> _formKey = new GlobalKey<FormState>();
  /*List<DropdownMenuItem<String>> generateDropDown(int no) {
    List<DropdownMenuItem<String>> _dropDownMenuItems1;
    int i=0;
    List mapdata = List();
    globals.dropDownCaptionValuesCOdeKeysSocialFinancial[no].forEach((mapValue) {
      var keys = mapValue.keys.toList();
      for(int i = 0; i <keys.length;i++){
        var val = mapValue[keys[i]];
        mapdata.add(val);
      }
    });
    mapdata.add("null");
    _dropDownMenuItems1 =  mapdata.map((value){
      return new DropdownMenuItem<String>(
        value: value ,
        child: new Text(value),
      );
    }).toList();
    return _dropDownMenuItems1;
  }*/

  List<DropdownMenuItem<LookupBeanData>> generateDropDown(int no) {
    //print("caption value : " + globals.dropdownCaptionsPersonalInfo[no]);

    List<DropdownMenuItem<LookupBeanData>> _dropDownMenuItems1;
    List<LookupBeanData> mapData = List<LookupBeanData>();
    LookupBeanData bean = new LookupBeanData();
    bean.mcodedesc = "";
    mapData.add(blankBean);
    for (int k = 0;
    k < globals.dropDownCaptionValuesCOdeKeysSocialFinancial[no].length;
    k++) {
      mapData.add(globals.dropDownCaptionValuesCOdeKeysSocialFinancial[no][k]);
    }
    _dropDownMenuItems1 = mapData.map((value) {

      return new DropdownMenuItem<LookupBeanData>(
        value: value,
        child: new Text(value.mcodedesc,overflow: TextOverflow.ellipsis,maxLines: 3,),
      );
    }).toList();
    /*   if(no==0){
      print(mapData);
      testString = mapData;
    }*/
    return _dropDownMenuItems1;
  }

  bool chkBankAccount= true;



  bool ifNullCheck(String value) {
    bool isNull = false;
    try {
      if (value == null || value == 'null' || value.trim()=='') {
        isNull = true;
      }
    }catch(_){
      isNull =true;
    }
    return isNull;
  }

  @override
  void initState() {


    for(int i = 0;i<CustomerFormationMasterTabsState.socialFinancialRadios.length;i++){
      if(CustomerFormationMasterTabsState.socialFinancialRadios[i]==null)CustomerFormationMasterTabsState.socialFinancialRadios[i]= 0;
    }

    if(CustomerFormationMasterTabsState.custListBean.mConstruct!=null)CustomerFormationMasterTabsState.socialFinancialRadios[0] = CustomerFormationMasterTabsState.custListBean.mConstruct;
    if(CustomerFormationMasterTabsState.custListBean.mToilet!=null)CustomerFormationMasterTabsState.socialFinancialRadios[1] = CustomerFormationMasterTabsState.custListBean.mToilet;

    if (!ifNullCheck(CustomerFormationMasterTabsState.custListBean.mbankacyn)) {

      try {
        CustomerFormationMasterTabsState.socialFinancialRadios[2] =
            int.parse(CustomerFormationMasterTabsState.custListBean.mbankacyn);
      } catch(_){
        CustomerFormationMasterTabsState.socialFinancialRadios[2] =0;
      }
    }
    else{
      CustomerFormationMasterTabsState.custListBean
          .mbankacyn = "0";
    }

    _typeAheadController.text=CustomerFormationMasterTabsState.custListBean.mbanknamelk;


  }


  showDropDown(LookupBeanData selectedObj, int no) {

  }

  setValue(int no, LookupBeanData value) {
  }

  Widget constructionRadio() =>
      CustomerFormationSocialFinancialDetails._get(new Row(
        children:
        _makeRadios(2, globals.radioCaptionValuesSocialFinancial[0], 0),
        mainAxisAlignment: MainAxisAlignment.spaceAround,
      ));

  Widget toiletRadio() => CustomerFormationSocialFinancialDetails._get(new Row(
    children:
    _makeRadios(2, globals.radioCaptionValuesSocialFinancial[1], 1),
    mainAxisAlignment: MainAxisAlignment.spaceAround,
  ));

  Widget bankAccountRadio() =>
      CustomerFormationSocialFinancialDetails._get(new Row(
        children:
        _makeRadios(2, globals.radioCaptionValuesSocialFinancial[2], 2),
        mainAxisAlignment: MainAxisAlignment.spaceAround,
      ));

  List<Widget> _makeRadios(int numberOfRadios, List textName, int position) {
    List<Widget> radios = new List<Widget>();
    for (int i = 0; i < numberOfRadios; i++) {
      radios.add(new Row(
        children: <Widget>[
          new Text(
            textName[i],
            textAlign: TextAlign.right,
            style: new TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey,
              fontStyle: FontStyle.normal,
              fontSize: 10.0,
            ),
          ),
          new Radio(
            value: i,
            groupValue: CustomerFormationMasterTabsState.socialFinancialRadios[position],
            onChanged: (selection) {


              return _onRadioSelected(selection, position);
            } ,
            activeColor:  Color(0xff07426A),
          ),
        ],
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
      ));
    }
    return radios;
  }

  Widget getTextContainer(String textValue) {
    return new Container(
      padding: EdgeInsets.fromLTRB(5.0, 20.0, 0.0, 20.0),
      child: new Text(
        textValue,
        //textDirection: TextDirection,
        textAlign: TextAlign.start,
        /*overflow: TextOverflow.ellipsis,*/
        style: new TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.grey,
            fontStyle: FontStyle.normal,
            fontSize: 12.0),
      ),
    );
  }

  _onRadioSelected(int selection, int position) {
    setState(() => CustomerFormationMasterTabsState.socialFinancialRadios[position] = selection);
    if (position == 0) {
      CustomerFormationMasterTabsState.custListBean.mConstruct = selection;

    } else if (position == 1) {
      CustomerFormationMasterTabsState.custListBean.mToilet = selection;
    } else if (position == 2) {
      CustomerFormationMasterTabsState.custListBean.mbankacyn = selection.toString().trim();
    }
  }

  @override
  Widget build(BuildContext context) {
    return    new Form(
      key: _formKey,
      autovalidate: false,

      onChanged: () {
        final FormState form = _formKey.currentState;
        form.save();
      },
      child: Container(
        child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.symmetric(horizontal: 5.0),
            children: <Widget>[

              new Container(

                child: new Column(
                  children: <Widget>[

                    new Card(
                      child: new Text("Banks Details"),
                    ),
                    new TextFormField(

                      decoration: const InputDecoration(

                        hintText: 'Enter Account Number',
                        labelText: 'Account Number',
                        hintStyle: TextStyle(color: Colors.grey),
                        /* labelStyle: TextStyle(color: Colors.grey),*/
                        border: UnderlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.black,
                            )),
                        focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.blue,
                            )),
                        contentPadding: EdgeInsets.all(20.0),
                      ),
                      keyboardType: TextInputType.text,
                      inputFormatters: [new LengthLimitingTextInputFormatter(20),globals.onlyAphaNumeric]
                      ,
                      // validator: (arg)=>Utility.validateOnlyNumberField(arg),
                      initialValue:
                      CustomerFormationMasterTabsState.custListBean.mbankacno==null ||
                          CustomerFormationMasterTabsState.custListBean.mbankacno=="null"?
                      "":CustomerFormationMasterTabsState.custListBean.mbankacno.toString(),
                      onSaved: (val) {
                        if(val!=null&&val!="")
                          CustomerFormationMasterTabsState.custListBean.mbankacno = val;

                        else CustomerFormationMasterTabsState.custListBean.mbankacno = "";

                      } ,
                    ),
                    TypeAheadFormField<LookupBeanData>(
                      textFieldConfiguration: TextFieldConfiguration(
                          controller: this._typeAheadController,
                          decoration: InputDecoration(
                              labelText: 'Bank Name'
                          )
                      ),
                      suggestionsCallback: (pattern) {
                        return returnLookup(pattern);
                      },

                      itemBuilder: (context, item) {
                        return ListTile(
                          title: Text(item.mcodedesc),
                        );
                      },
                      transitionBuilder: (context, suggestionsBox, controller) {
                        return suggestionsBox;
                      },
                      onSuggestionSelected: (item) {
                        this._typeAheadController.text = item.mcodedesc;
                      },
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Bank Name';
                        }
                      },
                      onSaved: (value) => CustomerFormationMasterTabsState.custListBean.mbanknamelk = value,
                    ),


                    new TextFormField(
                      textCapitalization: TextCapitalization.characters,
                      keyboardType: TextInputType.text,
                      decoration: const InputDecoration(

                        hintText: 'Enter Branch',
                        labelText: 'Branch',
                        hintStyle: TextStyle(color: Colors.grey),
                        /* labelStyle: TextStyle(color: Colors.grey),*/
                        border: UnderlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.black,
                            )),
                        focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.blue,
                            )),
                        contentPadding: EdgeInsets.all(20.0),
                      ),
                      inputFormatters: [new LengthLimitingTextInputFormatter(25),globals.onlyAphaNumeric],
                      initialValue: CustomerFormationMasterTabsState.custListBean.mbankbranch==null||
                          CustomerFormationMasterTabsState.custListBean.mbankbranch=="null"? "":
                      CustomerFormationMasterTabsState.custListBean.mbankbranch,
                      onSaved: (val) {
                        CustomerFormationMasterTabsState.custListBean.mbankbranch= val;

                      } ,
                    ),

                    /* new TextFormField(
                  decoration: const InputDecoration(

                    hintText: 'Enter IFSC Code ',
                    labelText: 'IFSC Code',
                    hintStyle: TextStyle(color: Colors.grey),
                    *//* labelStyle: TextStyle(color: Colors.grey),*//*
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                      color: Colors.black,
                    )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                      color: Colors.blue,
                    )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),
               inputFormatters: [LengthLimitingTextInputFormatter(11),globals.onlyAphaNumeric],
               validator: (arg)=>Utility.validateCharacterAndNumberField(arg),
                  initialValue: CustomerFormationMasterTabsState.custListBean.mbankifsc==null||
                      CustomerFormationMasterTabsState.custListBean.mbankifsc=="null"? "":
                  CustomerFormationMasterTabsState.custListBean.mbankifsc,
                  onSaved: (val) => CustomerFormationMasterTabsState.custListBean.mbankifsc= val,
                ),


                ]),
      ),
*/
                    SizedBox(height: 10.0,),
                    new TextFormField(
                      controller: CustomerFormationMasterTabsState
                          .custListBean !=
                          null &&
                          CustomerFormationMasterTabsState
                              .custListBean.macctbal !=
                              null
                          ? TextEditingController(
                          text: formatDouble.format(CustomerFormationMasterTabsState
                              .custListBean.macctbal))
                          : TextEditingController(text: "0.0"),
                      onSaved: (String value) {
                        try {
                          CustomerFormationMasterTabsState.custListBean.macctbal = double.parse(value);
                          //addToList(context,0);
                        } catch (_) {}
                      },
                      keyboardType: TextInputType.numberWithOptions(decimal: true),
                      decoration: new InputDecoration(
                          border: new OutlineInputBorder(
                              borderSide: new BorderSide(color: Colors.teal)),
                          hintText: Translations.of(context).text('acctBalhint'),
                          labelText: Translations.of(context).text('acctBallabel'),
                          prefixText: '',
                          suffixText: '',
                          suffixStyle: const TextStyle(color: Colors.green)),
                    ),
                  ],
                ),
              ),
              new Table(children: [
                new TableRow(
                    decoration: new BoxDecoration(
                      border: Border.all(color: Colors.grey, width: 0.1),
                    ),
                    children: [
                      getTextContainer(globals.radioCaptionSocialFinancial[2]),
                      bankAccountRadio(),
                    ]),
              ]),

            ]),
      ),

    );


  }



  List<LookupBeanData> returnLookup(String pattern) {

    List<LookupBeanData> beanList=new List<LookupBeanData>();
    for (int i = 0;
    i < globals.dropDownCaptionValuesCOdeKeysSocialFinancial[2].length;
    i++) {
      try {
        if (globals.dropDownCaptionValuesCOdeKeysSocialFinancial[2][i].mcodedesc.toString().trim().toUpperCase().contains(pattern.trim().toUpperCase())){
          print(globals.dropDownCaptionValuesCOdeKeysSocialFinancial[2][i].mcodedesc.toString().trim().toUpperCase());
          beanList.add(globals.dropDownCaptionValuesCOdeKeysSocialFinancial[2][i]);

        }
      }catch(_){
        print("Exception Occured");
      }
    }

    return beanList;


  }
}

class CustomModel {
  static const TITLE_KEY = 'title';

  String id;
  String title;
  bool isChecked = false;


  @override
  String toString() {
    return 'CustomModel{id: $id, title: $title, isChecked: $isChecked}';
  }

  void setIsChecked(bool isChecked) {
    this.isChecked = isChecked;
  }

  bool getIsChecked() {
    return isChecked;
  }



  CustomModel(String ex) {
    title = ex;
  }

}

class SocialFinancialDetailsBean {
  String house;
  String construction;
  String toilet;
  String bankAccount;
  String agriculturalLandOwner;
  String loanFromOtherBankOrPerson;

  SocialFinancialDetailsBean(
      {this.house,
        this.construction,
        this.toilet,
        this.bankAccount,
        this.agriculturalLandOwner,
        this.loanFromOtherBankOrPerson});
}
