import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

class VillageServeyExtraInformation extends StatefulWidget {
  VillageServeyExtraInformation({Key key}) : super(key: key);

  @override
  _VillageServeyExtraInformationState createState() =>
      new _VillageServeyExtraInformationState();
}

class _VillageServeyExtraInformationState
    extends State<VillageServeyExtraInformation> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return new Container(
      width: 0.0,
      height: 0.0,
    );
  }
}
