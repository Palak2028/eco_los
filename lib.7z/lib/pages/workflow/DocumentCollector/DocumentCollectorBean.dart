

import 'package:eco_los/db/TablesColumnFile.dart';

class DocumentCollectorBean{

  int trefno;
  int mrefno;
  int loantrefno;
  int loanmrefno;
  String mforeignindicator;
  String  mdoctno;
  String  missuingauth;
  DateTime missuedate;
  DateTime mexpdate;
  String mimgtype;
  String mimgtypedesc;
  String mimgsubtype;
  String mcomment;
  String imgstring;
  DateTime mcreateddt;
  String mcreatedby;
  DateTime mlastupdatedt;
  String mlastupdateby;
  String mgeolocation;
  String mgeolatd;
  String mgeologd;
  DateTime mlastsynsdate;
  String merrormessage;


  @override
  String toString() {
    return 'DocumentCollectorBean{trefno: $trefno, mrefno: $mrefno, loantrefno: $loantrefno, loanmrefno: $loanmrefno, mforeignindicator: $mforeignindicator, mdoctno: $mdoctno, missuingauth: $missuingauth, missuedate: $missuedate, mexpdate: $mexpdate, mimgtype: $mimgtype, mimgtypedesc: $mimgtypedesc, mimgsubtype: $mimgsubtype, mcomment: $mcomment, imgstring: $imgstring, mcreateddt: $mcreateddt, mcreatedby: $mcreatedby, mlastupdatedt: $mlastupdatedt, mlastupdateby: $mlastupdateby, mgeolocation: $mgeolocation, mgeolatd: $mgeolatd, mgeologd: $mgeologd, mlastsynsdate: $mlastsynsdate, merrormessage: $merrormessage}';
  }

  DocumentCollectorBean(
      {this.mforeignindicator,this.trefno,this.mimgtype,this.mrefno, this.mimgtypedesc, this.mimgsubtype,
        this.mcomment, this.imgstring,this.loantrefno,
        this.loanmrefno,this.mdoctno,this.missuingauth,this.missuedate,this.mexpdate, this.mcreateddt,
        this.mcreatedby,
        this.mlastupdatedt,
        this.mlastupdateby,
        this.mgeolocation,
        this.mgeolatd,
        this.mgeologd,
        this.mlastsynsdate,
        this.merrormessage,});

  factory DocumentCollectorBean.fromMap(Map<String, dynamic> map) {
    return DocumentCollectorBean(
      trefno: 	 map[TablesColumnFile.trefno] as int,
      mrefno: 	 map[TablesColumnFile.mrefno] as int,
      loanmrefno:	map[TablesColumnFile.loanmrefno] as int,
      loantrefno:	map[TablesColumnFile.loantrefno] as int,
      mforeignindicator: 	 map[TablesColumnFile.mforeignindicator] as String,
      mimgtype: 	 map[TablesColumnFile.mimgtype] as String,
      mimgtypedesc: map[TablesColumnFile.mimgtypedesc] as String,
      mimgsubtype: map[TablesColumnFile.mimgsubtype] as String,
      mcomment: map[TablesColumnFile.mcomment] as String,
      imgstring: map[TablesColumnFile.imgstring] as String,
      mdoctno: 	 map[TablesColumnFile.mdoctno] as String,
      missuingauth: 	 map[TablesColumnFile.missuingauth] as String,
      missuedate:(map[TablesColumnFile.missuedate]=="null"||map[TablesColumnFile.missuedate]==null)?null:DateTime.parse(map[TablesColumnFile.missuedate]) as DateTime,
      mexpdate:(map[TablesColumnFile.mexpdate]=="null"||map[TablesColumnFile.mexpdate]==null)?null:DateTime.parse(map[TablesColumnFile.mexpdate]) as DateTime,

      mcreateddt:	(map[TablesColumnFile.mcreateddt]=="null"||map[TablesColumnFile.mcreateddt]==null)?null:DateTime.parse(map[TablesColumnFile.mcreateddt]) as DateTime,
      mcreatedby:map[TablesColumnFile.mcreatedby] as String,
      mlastupdatedt:(map[TablesColumnFile.mlastupdatedt]=="null"||map[TablesColumnFile.mlastupdatedt]==null)?null:DateTime.parse(map[TablesColumnFile.mlastupdatedt]) as DateTime,
      mlastupdateby:map[TablesColumnFile.mlastupdateby] as String,
      mgeolocation:map[TablesColumnFile.mgeolocation] as String,
      mgeolatd:map[TablesColumnFile.mgeolatd] as String,
      mgeologd:map[TablesColumnFile.mgeologd] as String,
      mlastsynsdate:(map[TablesColumnFile.mlastsynsdate]=="null"||map[TablesColumnFile.mlastsynsdate]==null)?null:DateTime.parse(map[TablesColumnFile.mlastsynsdate]) as DateTime,

    );
  }

  factory DocumentCollectorBean.fromMapFromMiddleWare(Map<String, dynamic> map) {
    return DocumentCollectorBean(
      trefno: 	 map[TablesColumnFile.trefno] as int,
      mrefno: 	 map[TablesColumnFile.mrefno] as int,
      loanmrefno:	map[TablesColumnFile.loanmrefno] as int,
      loantrefno:	map[TablesColumnFile.loantrefno] as int,
      mforeignindicator: 	 map[TablesColumnFile.mforeignindicator] as String,
      mimgtype: 	 map[TablesColumnFile.mimgtype] as String,
      mimgtypedesc: map[TablesColumnFile.mimgtypedesc] as String,
      mimgsubtype: map[TablesColumnFile.mimgsubtype] as String,
      mcomment: map[TablesColumnFile.mcomment] as String,
      imgstring: map[TablesColumnFile.imgstring] as String,
      mdoctno: 	 map[TablesColumnFile.mdoctno] as String,
      missuingauth: 	 map[TablesColumnFile.missuingauth] as String,
      missuedate:(map[TablesColumnFile.missuedate]=="null"||map[TablesColumnFile.missuedate]==null)?null:DateTime.parse(map[TablesColumnFile.missuedate]) as DateTime,
      mexpdate:(map[TablesColumnFile.mexpdate]=="null"||map[TablesColumnFile.mexpdate]==null)?null:DateTime.parse(map[TablesColumnFile.mexpdate]) as DateTime,

      mcreateddt:	(map[TablesColumnFile.mcreateddt]=="null"||map[TablesColumnFile.mcreateddt]==null)?null:DateTime.parse(map[TablesColumnFile.mcreateddt]) as DateTime,
      mcreatedby:map[TablesColumnFile.mcreatedby] as String,
      mlastupdatedt:(map[TablesColumnFile.mlastupdatedt]=="null"||map[TablesColumnFile.mlastupdatedt]==null)?null:DateTime.parse(map[TablesColumnFile.mlastupdatedt]) as DateTime,
      mlastupdateby:map[TablesColumnFile.mlastupdateby] as String,
      mgeolocation:map[TablesColumnFile.mgeolocation] as String,
      mgeolatd:map[TablesColumnFile.mgeolatd] as String,
      mgeologd:map[TablesColumnFile.mgeologd] as String,
      mlastsynsdate:(map[TablesColumnFile.mlastsynsdate]=="null"||map[TablesColumnFile.mlastsynsdate]==null)?null:DateTime.parse(map[TablesColumnFile.mlastsynsdate]) as DateTime,

    );
  }


    factory DocumentCollectorBean.fromMapFromMiddleWareOnMrefno(Map<String, dynamic> map) {
    print("map "+map.toString());
    return DocumentCollectorBean(
      trefno: 	 map[TablesColumnFile.trefno] as int,
      mrefno: 	 map[TablesColumnFile.mrefno] as int,
      loanmrefno:	map[TablesColumnFile.loanmrefno] as int,
      loantrefno:	map[TablesColumnFile.loantrefno] as int,
      mcreateddt:	(map[TablesColumnFile.mcreateddt]=="null"||map[TablesColumnFile.mcreateddt]==null)?null:DateTime.parse(map[TablesColumnFile.mcreateddt]) as DateTime,
      mcreatedby:map[TablesColumnFile.mcreatedby] as String,
      mlastupdatedt:(map[TablesColumnFile.mlastupdatedt]=="null"||map[TablesColumnFile.mlastupdatedt]==null)?null:DateTime.parse(map[TablesColumnFile.mlastupdatedt]) as DateTime,
      mlastupdateby:map[TablesColumnFile.mlastupdateby] as String,
      mgeolocation:map[TablesColumnFile.mgeolocation] as String,
      mgeolatd:map[TablesColumnFile.mgeolatd] as String,
      mgeologd:map[TablesColumnFile.mgeologd] as String,
      mlastsynsdate:(map[TablesColumnFile.mlastsynsdate]=="null"||map[TablesColumnFile.mlastsynsdate]==null)?null:DateTime.parse(map[TablesColumnFile.mlastsynsdate]) as DateTime,


    );
  }

}