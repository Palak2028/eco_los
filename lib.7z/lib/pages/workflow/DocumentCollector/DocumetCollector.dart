import 'dart:io';

import 'package:eco_los/Utilities/GetSubLookupAsMis.dart';
import 'package:eco_los/Utilities/app_constant.dart';
import 'package:eco_los/db/AppDatabase.dart';
import 'package:eco_los/db/TablesColumnFile.dart';
import 'package:eco_los/pages/workflow/DocumentCollector/ViewDocuments.dart';
import 'package:eco_los/pages/workflow/GRT/Photo_view.dart';
import 'package:eco_los/pages/workflow/LoanApplication/bean/PurposeOfLoan.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:eco_los/Utilities/globals.dart' as globals;
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../translations.dart';
import '../LookupMasterBean.dart';
import 'DocumentCollectorBean.dart';

class DocumetCollector extends StatefulWidget {
  final String mleadsId;
  final int mrefno;
  final int trefno;
  DocumetCollector(this.mleadsId,this.mrefno,this.trefno);


  @override
  _DocumetCollectorState createState() => new _DocumetCollectorState();
}

class _DocumetCollectorState extends State<DocumetCollector> {
  static final GlobalKey<FormState> _formKey = new GlobalKey<FormState>();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  List<DocumentCollectorBean> documentCollectorBeanList = new List<DocumentCollectorBean>();
  DocumentCollectorBean documentCollectorBean = new DocumentCollectorBean();
  LookupBeanData blankBean =
      new LookupBeanData(mcodedesc: "", mcode: "", mcodetype: 0);
  LookupBeanData documenttype;

  String customerName;
  String branch = "";
  SharedPreferences prefs;
  String loginTime;
  int usrGrpCode = 0;
  String username;
  String usrRole;
  String geoLocation;
  String geoLatitude;
  String geoLongitude;
  String reportingUser;

  var formatter = new DateFormat('dd-MM-yyyy');
  String tempIssueDateYear;
  String tempIssueDateDay;
  String tempIssueDateMonth;
  String tempIssueDateDate = "----/--/--";

  String issueDate = "__-__-____";
  FocusNode monthIssueDateFocus;
  FocusNode yearIssueDateFocus;


  String tempExpDateYear;
  String tempExpDateDay;
  String tempExpDateMonth;
  String tempExpDateDate = "----/--/--";

  String expDate = "__-__-____";
  FocusNode monthExpDateFocus;
  FocusNode yearExpDateFocus;


  @override
  void initState() {
    monthIssueDateFocus = new FocusNode();
    yearIssueDateFocus = new FocusNode();
    monthExpDateFocus = new FocusNode();
    yearExpDateFocus = new FocusNode();

      if (widget.mleadsId != null &&
          widget.mleadsId != "null" &&
          widget.mleadsId != "") {
        documentCollectorBean.mforeignindicator = widget.mleadsId;
      }
      if (widget.mrefno != null &&
          widget.mrefno != "null" &&
          widget.mrefno != "") {
        documentCollectorBean.loanmrefno = widget.mrefno;
      }
      if (widget.trefno != "null" &&
          widget.trefno != "" &&
          widget.trefno != null) {
        documentCollectorBean.loantrefno = widget.trefno;
      }

    getSessionVariables();


   }


  Future<Null> getSessionVariables() async {
    setState(() {});
    prefs = await SharedPreferences.getInstance();
    await AppDatabase.get().getDocuments(widget.trefno,widget.mrefno).then((List<DocumentCollectorBean> documentCollectorBean) async{
      print("onValue.toString()"+documentCollectorBean.toString());
      if(documentCollectorBean!=null && documentCollectorBean.length>0) {
          print("onValue.toString()1"+documentCollectorBean.toString());
        documentCollectorBeanList = documentCollectorBean;
      }
    });
    if (documentCollectorBean.trefno == "" ||
        documentCollectorBean.trefno == null ||
        documentCollectorBean.trefno == "null") {
      print("documentCollectorBean.trefno"+documentCollectorBean.trefno.toString());
      await AppDatabase.get().generateTrefnoForDocuments().then((onValue) {
        print("onValue"+onValue.toString());
        documentCollectorBean.trefno = onValue;
      });
    }
    setState(() {
      branch = prefs.get(TablesColumnFile.musrbrcode).toString();
      username = prefs.getString(TablesColumnFile.musrcode);
      usrRole = prefs.getString(TablesColumnFile.usrDesignation);
      usrGrpCode = prefs.getInt(TablesColumnFile.grpCd);
      loginTime = prefs.getString(TablesColumnFile.LoginTime);
      geoLocation = prefs.getString(TablesColumnFile.geoLocation);
      geoLatitude = prefs.get(TablesColumnFile.geoLatitude).toString();
      geoLongitude = prefs.get(TablesColumnFile.geoLongitude).toString();
      reportingUser = prefs.getString(TablesColumnFile.reportingUser);
    });
  }

  showDropDown(LookupBeanData selectedObj, int no) {
    if (selectedObj.mcodedesc.isEmpty) {
      //   print("inside  code Desc is null");
      switch (no) {
        case 0:
          documenttype = blankBean;
          documentCollectorBean.mimgtype = blankBean.mcode;
          break;
        default:
          break;
      }
      setState(() {});
    } else {
      bool isBreak = false;
      for (int k = 0;
          k < globals.dropDownCaptionDocumentCollecter[no].length;
          k++) {
        if (globals.dropDownCaptionDocumentCollecter[no][k].mcodedesc ==
            selectedObj.mcodedesc) {
          setValue(no, globals.dropDownCaptionDocumentCollecter[no][k]);
          isBreak = true;
          break;
        }
        if (isBreak) {
          break;
        }
      }
    }
  }

  setValue(int no, LookupBeanData value) {
    setState(() {
      // print("coming here");
      switch (no) {
        case 0:
          documenttype = value;
          documentCollectorBean.mimgtype = value.mcode;
          documentCollectorBean.mimgtypedesc = value.mcodedesc;
          break;
        default:
          break;
      }
    });
  }

  List<DropdownMenuItem<LookupBeanData>> generateDropDown(int no) {
    List<DropdownMenuItem<LookupBeanData>> _dropDownMenuItems1;
    List<LookupBeanData> mapData = List<LookupBeanData>();
    LookupBeanData bean = new LookupBeanData();
    bean.mcodedesc = "";
    mapData.add(blankBean);
    for (int k = 0;
        k < globals.dropDownCaptionDocumentCollecter[no].length;
        k++) {
      mapData.add(globals.dropDownCaptionDocumentCollecter[no][k]);
    }
    _dropDownMenuItems1 = mapData.map((value) {    
      return new DropdownMenuItem<LookupBeanData>(
        value: value,
        child: new Text(value.mcodedesc),
      );
    }).toList();
    
    return _dropDownMenuItems1;
  }

  @override
  Widget build(BuildContext context) {
    return new WillPopScope(
        onWillPop: () {
          Navigator.of(context).pop();
          // callDialog();
        },
        child: new Scaffold(
            key: _scaffoldKey,
            appBar: new AppBar(
              elevation: 1.0,
              leading: new IconButton(
                  icon: new Icon(Icons.arrow_back, color: Colors.white),
                  onPressed: () {
                    Navigator.of(context).pop();
                    //  callDialog();
                  }),
              backgroundColor: Color(0xff07426A),
              brightness: Brightness.light,
              title: new Text(
                'Document Collector',
                //textDirection: TextDirection,
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
                style: new TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontStyle: FontStyle.normal),
              ),
              actions: <Widget>[
                new IconButton(
                  icon: new Icon(
                    Icons.save,
                    color: Colors.white,
                    size: 40.0,
                  ),
                  onPressed: () {
                    proceed();
                  },
                ),
                new Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5.0),
                ),
              ],
            ),
            body: new Form(
              key: _formKey,
              autovalidate: false,
              onChanged: () async {
                final FormState form = _formKey.currentState;
                form.save();
                //await calculate();
              },
              child:  ListView(
                  shrinkWrap: true,
                  //padding: const EdgeInsets.symmetric(horizontal: 0.0),
                  children: <Widget>[
                    SizedBox(height: 16.0),
                    Center(
                      child: new Column(children: [
                        Container(
                          child:new DropdownButtonFormField(
                            value: documenttype,
                            items: generateDropDown(0),
                            onChanged: (LookupBeanData newValue) {
                              showDropDown(newValue, 0);
                            },
                            validator: (args) {
                              print(args);
                            },
                            decoration: new InputDecoration(
                              border: new OutlineInputBorder(
                                  borderSide: new BorderSide(color: Colors.teal)),

                              labelText: "Document Type",
                              hintText: "Document Type",
                            ),
                          ),)
                      ]),
                    ),
                    SizedBox(height: 10.0,),

                    Container(
                      color:  Constant.mandatoryColor,
                      child: new TextFormField(
                        textCapitalization: TextCapitalization.characters,
                        keyboardType: TextInputType.text,
                        decoration: const InputDecoration(

                          hintText: 'Enter ID Number',
                          labelText: 'ID Number',
                          hintStyle: TextStyle(color: Colors.grey),
                          /*labelStyle: TextStyle(color: Colors.grey),*/
                          border: UnderlineInputBorder(
                              borderSide: BorderSide(
                                color: Colors.black,
                              )),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                color: Colors.blue,
                              )),
                          contentPadding: EdgeInsets.all(20.0),
                        ),
                        //inputFormatters: [new LengthLimitingTextInputFormatter(30),globals.onlyAphaNumeric],
                        controller:  documentCollectorBean.mdoctno != null
                            ? TextEditingController(text:  documentCollectorBean.mdoctno)
                            : TextEditingController(text: ""),
                        onSaved: (val) => documentCollectorBean.mdoctno = val,
                      ),
                    ),


                    Container(
                      color: Constant.mandatoryColor,
                      child: new TextFormField(
                        textCapitalization: TextCapitalization.characters,
                        keyboardType: TextInputType.text,
                        decoration: const InputDecoration(

                          hintText: 'Enter Issuing authority',
                          labelText: 'Issuing authority',
                          hintStyle: TextStyle(color: Colors.grey),
                          /*labelStyle: TextStyle(color: Colors.grey),*/
                          border: UnderlineInputBorder(
                              borderSide: BorderSide(
                                color: Colors.black,
                              )),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                color: Colors.blue,
                              )),
                          contentPadding: EdgeInsets.all(20.0),
                        ),
                        //inputFormatters: [new LengthLimitingTextInputFormatter(30),globals.onlyAphaNumeric],
                        controller:  documentCollectorBean.missuingauth != null
                            ? TextEditingController(text:  documentCollectorBean.missuingauth)
                            : TextEditingController(text: ""),
                        onSaved: (val) => documentCollectorBean.missuingauth = val,
                      ),
                    ),
                      SizedBox(height: 10.0,),
                    new Container(
                        height: 250.0,
                        child: new Column(
                          children: <Widget>[
                            new ListTile(
                              title: new ListTile(
                                title: documentCollectorBean.imgstring !=
                                    null &&
                                    documentCollectorBean.imgstring !=
                                        null &&
                                    documentCollectorBean.imgstring !=
                                        null &&
                                    documentCollectorBean.imgstring !=
                                        ""
                                    ? new Image.file(
                                  File(documentCollectorBean.imgstring),
                                  height: 200.0,
                                  width: 200.0,
                                )

                                    :  new Icon(
                                          Icons.camera_alt,
                                          size: 200.0,
                                          color: Color(0xff07426A),
                             ),
                                subtitle: new Text(
                                  Translations.of(context)
                                      .text("Click_Here_To_Take_A_Picture"),
                                  textAlign: TextAlign.center,
                                ),
                                onTap: () {
                                  if(documentCollectorBean.mimgtype==null /*|| documentCollectorBean.mimgtype ==""*/) {
                                    showMessageWithoutProgress("Please Select Type");
                                    return ;
                                  }
                                  _PickImage(0);
                                  /*_navigateAndDisplaySelection(
                                  context, 'customer picture')*/
                                  ;
                                },
                              ),
                            ),
                          ],
                        )),

                    SizedBox(height: 20.0,),
                    Container(
                      decoration: BoxDecoration(),
                      child: new Row(
                        children: <Widget>[Text("Issue Date")],
                      ),
                    ),
                    new Container(
                      decoration: BoxDecoration(),
                      child: new Row(
                        children: <Widget>[
                          new Container(
                            width: 50.0,
                            child: new TextField(
                                decoration: InputDecoration(hintText: "DD"),
                                inputFormatters: [
                                  new LengthLimitingTextInputFormatter(2),
                                  globals.onlyIntNumber
                                ],
                                controller: tempIssueDateDay == null
                                    ? null
                                    : new TextEditingController(text: tempIssueDateDay),
                                keyboardType: TextInputType.numberWithOptions(),
                                onChanged: (val) {
                                  if (val != "0") {
                                    tempIssueDateDay = val;

                                    if (int.parse(val) <= 31 && int.parse(val) > 0) {
                                      if (val.length == 2) {
                                        issueDate = issueDate.replaceRange(0, 2, val);
                                        FocusScope.of(context).requestFocus(monthIssueDateFocus);
                                      } else {
                                        issueDate =
                                            issueDate.replaceRange(0, 2, "0" + val);
                                      }
                                    } else {
                                      setState(() {
                                        tempIssueDateDay = "";
                                      });
                                    }
                                  }
                                }),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: new Text("/"),
                          ),
                          new Container(
                            width: 50.0,
                            child: new TextField(
                              decoration: InputDecoration(
                                hintText: "MM",
                              ),
                              keyboardType: TextInputType.numberWithOptions(),
                              inputFormatters: [
                                new LengthLimitingTextInputFormatter(2),
                                globals.onlyIntNumber
                              ],
                              focusNode: monthIssueDateFocus,
                              controller: tempIssueDateMonth == null
                                  ? null
                                  : new TextEditingController(text: tempIssueDateMonth),
                              onChanged: (val) {
                                if (val != "0") {
                                  tempIssueDateMonth = val;
                                  if (int.parse(val) <= 12 && int.parse(val) > 0) {
                                    if (val.length == 2) {
                                      issueDate = issueDate.replaceRange(3, 5, val);

                                      FocusScope.of(context).requestFocus(yearIssueDateFocus);
                                    } else {
                                      issueDate =
                                          issueDate.replaceRange(3, 5, "0" + val);
                                    }
                                  } else {
                                    setState(() {
                                      tempIssueDateMonth = "";
                                    });
                                  }
                                }
                              },
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: new Text("/"),
                          ),
                          Container(
                            width: 80,
                            child: new TextField(
                              decoration: InputDecoration(
                                hintText: "YYYY",
                              ),
                              keyboardType: TextInputType.numberWithOptions(),
                              inputFormatters: [
                                new LengthLimitingTextInputFormatter(4),
                                globals.onlyIntNumber
                              ],
                              focusNode: yearIssueDateFocus,
                              controller: tempIssueDateYear == null
                                  ? null
                                  : new TextEditingController(text: tempIssueDateYear),
                              onChanged: (val) {
                                tempIssueDateYear = val;
                                if (val.length == 4)
                                  issueDate =  issueDate.replaceRange(6, 10, val);

                              },

                            ),
                          ),
                          SizedBox(
                            width: 50.0,
                          ),
                          IconButton(
                              icon: Icon(Icons.calendar_today),
                              onPressed: () {
                                _selectIssueDtDate(context);
                              })
                        ],
                      ),
                    ),




            SizedBox(height: 20.0,),
            Container(
              decoration: BoxDecoration(),
              child: new Row(
                children: <Widget>[Text("Expiry Date")],
              ),
            ),
            new Container(
              decoration: BoxDecoration(),
              child: new Row(
                children: <Widget>[
                  new Container(
                    width: 50.0,
                    child: new TextField(
                        decoration: InputDecoration(hintText: "DD"),
                        inputFormatters: [
                          new LengthLimitingTextInputFormatter(2),
                          globals.onlyIntNumber
                        ],
                        controller: tempExpDateDay == null
                            ? null
                            : new TextEditingController(text: tempExpDateDay),
                        keyboardType: TextInputType.numberWithOptions(),
                        onChanged: (val) {
                          if (val != "0") {
                            tempExpDateDay = val;

                            if (int.parse(val) <= 31 && int.parse(val) > 0) {
                              if (val.length == 2) {
                                expDate = expDate.replaceRange(0, 2, val);
                                FocusScope.of(context).requestFocus(monthExpDateFocus);
                              } else {
                                expDate =
                                    expDate.replaceRange(0, 2, "0" + val);
                              }
                            } else {
                              setState(() {
                                tempExpDateDay = "";
                              });
                            }
                          }
                        }),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: new Text("/"),
                  ),
                  new Container(
                    width: 50.0,
                    child: new TextField(
                      decoration: InputDecoration(
                        hintText: "MM",
                      ),
                      keyboardType: TextInputType.numberWithOptions(),
                      inputFormatters: [
                        new LengthLimitingTextInputFormatter(2),
                        globals.onlyIntNumber
                      ],
                      focusNode: monthExpDateFocus,
                      controller: tempExpDateMonth == null
                          ? null
                          : new TextEditingController(text: tempExpDateMonth),
                      onChanged: (val) {
                        if (val != "0") {
                          tempExpDateMonth = val;
                          if (int.parse(val) <= 12 && int.parse(val) > 0) {
                            if (val.length == 2) {
                              expDate = expDate.replaceRange(3, 5, val);

                              FocusScope.of(context).requestFocus(yearExpDateFocus);
                            } else {
                              expDate =
                                  expDate.replaceRange(3, 5, "0" + val);
                            }
                          } else {
                            setState(() {
                              tempExpDateMonth = "";
                            });
                          }
                        }
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: new Text("/"),
                  ),
                  Container(
                    width: 80,
                    child: new TextField(
                      decoration: InputDecoration(
                        hintText: "YYYY",
                      ),
                      keyboardType: TextInputType.numberWithOptions(),
                      inputFormatters: [
                        new LengthLimitingTextInputFormatter(4),
                        globals.onlyIntNumber
                      ],
                      focusNode: yearExpDateFocus,
                      controller: tempExpDateYear == null
                          ? null
                          : new TextEditingController(text: tempExpDateYear),
                      onChanged: (val) {
                        tempExpDateYear = val;
                        if (val.length == 4)
                          expDate =  expDate.replaceRange(6, 10, val);

                      },

                    ),
                  ),
                  SizedBox(
                    width: 50.0,
                  ),
                  IconButton(
                      icon: Icon(Icons.calendar_today),
                      onPressed: () {
                        _selectExpDtDate(context);
                      })
                ],
              ),
            ),
                    new Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Flexible(
                          child: new IconButton(
                            icon: new Icon(
                              Icons.format_list_bulleted,
                              color: Color(0xff07426A),
                              size: 50.0,
                            ),
                            onPressed: () {
getDocumentsList(widget.mrefno,widget.trefno);                            },
                          ),
                        ),
                        Flexible(
                            child: new IconButton(
                                padding: EdgeInsets.only(right: 30.0),
                                icon: new Icon(
                                  Icons.add,
                                  color: Color(0xff07426A),
                                  size: 50.0,
                                ),
                                splashColor: Colors.red,
                                onPressed: () {
                                  proceed();

                                 /* else {
                                    addToList();
                                  }*/
                                })),
                      ],
                    ),

                          ]
              ),
            )));
  }


  Future<void> _PickImage(int imageNo) async {
    return showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: new Icon(
              Icons.touch_app,
              color: Colors.blue[800],
              size: 40.0,
            ),
            content: SingleChildScrollView(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                children: <Widget>[

                  Card(
                    child: new ListTile(
                        title: new Text(('Take Picture From Camera')),
                        onTap: () {

                          Navigator.of(context).pop();
                          getImage(imageNo);

                        }),),

                  Card(
                    child: new ListTile(
                        title: new Text(('Choose From Gallery')),
                        onTap: () {

                          Navigator.of(context).pop();
                          getImageFromGallery(imageNo);

                        }),),


                ],
              ),
            ),
          );
        });
  }

  Future getImageFromGallery(int imageNo) async {

    var image = await ImagePicker.pickImage(
        source: ImageSource.gallery, maxHeight: 400.0, maxWidth: 400.0);


    /*final croppedFile = await ImageCrop.cropImage(
      file: image.path,
      area: image.area,
    );

*/
    File croppedFile = await ImageCropper.cropImage(
      sourcePath: image.path,
      ratioX: 1.0,
      ratioY: 1.5,
      maxWidth: 512,
      maxHeight: 512,
    );
    String st = croppedFile.path;
    documentCollectorBean.imgstring= croppedFile.path;
    setState(() {

    });
     }


  Future getImage(imageNo) async {
    File f;
    var image = await ImagePicker.pickImage(
        source: ImageSource.camera, maxHeight: 400.0, maxWidth: 400.0);
    File croppedFile = await ImageCropper.cropImage(
      sourcePath: image.path,
      ratioX: 1.0,
      ratioY: 1.5,
      maxWidth: 512,
      maxHeight: 512,
    );
    //String st = croppedFile.path;


    f =   File(croppedFile.path);
    documentCollectorBean.imgstring= croppedFile.path;

    setState(() {

    });
  }

_navigateAndDisplaySelection(BuildContext context) async {
  final result = Navigator.push(
      context,
      new MaterialPageRoute(
        builder: (BuildContext context) =>
        new ViewDocuments(documentCollectorBeanList),
        fullscreenDialog: true,
      )).then((onValue) {
    setState(() {});
    //Scaffold.of(context).showSnackBar(SnackBar(content: Text("$onValue")));
  });
}



  void showMessageWithoutProgress(String message,
      [MaterialColor color = Colors.red]) {
    try {
      _scaffoldKey.currentState.hideCurrentSnackBar();
    } catch (e) {}
    _scaffoldKey.currentState.showSnackBar(
        new SnackBar(backgroundColor: color, content: new Text(message)));
  }


  Future<Null> _selectIssueDtDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(1800, 8),
        lastDate: DateTime(2101));
    if (picked != null && picked != documentCollectorBean.missuedate)
      setState(() {
        documentCollectorBean.missuedate = picked;
        tempIssueDateDate = formatter.format(picked);
        if (picked.day.toString().length == 1) {
          tempIssueDateDay = "0" + picked.day.toString();
        } else
          tempIssueDateDay = picked.day.toString();
        issueDate = issueDate.replaceRange(0, 2, tempIssueDateDay);
        tempIssueDateYear = picked.year.toString();
        issueDate = issueDate.replaceRange(6, 10, tempIssueDateYear);
        if (picked.month.toString().length == 1) {
          tempIssueDateMonth = "0" + picked.month.toString();
        } else
          tempIssueDateMonth = picked.month.toString();
        issueDate = issueDate.replaceRange(3, 5, tempIssueDateMonth);
      });
    setState(() {

    });
  }


  Future<Null> _selectExpDtDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(1800, 8),
        lastDate: DateTime(2101));
    if (picked != null && picked != documentCollectorBean.mexpdate)
      setState(() {
        documentCollectorBean.mexpdate = picked;
        tempExpDateDate = formatter.format(picked);
        if (picked.day.toString().length == 1) {
          tempExpDateDay = "0" + picked.day.toString();
        } else
          tempExpDateDay = picked.day.toString();
        expDate = expDate.replaceRange(0, 2, tempExpDateDay);
        tempExpDateYear = picked.year.toString();
        expDate = expDate.replaceRange(6, 10, tempExpDateYear);
        if (picked.month.toString().length == 1) {
          tempExpDateMonth = "0" + picked.month.toString();
        } else
          tempExpDateMonth = picked.month.toString();
        expDate = expDate.replaceRange(3, 5, tempExpDateMonth);
      });
    setState(() {

    });
  }

  Future<int> updateRecordsOnQueue(List<DocumentCollectorBean> beanList) async {
      int id;
    for (DocumentCollectorBean item in beanList) {
      id = await AppDatabase.get().updateDocumentsMasters(item);
    }
    return id;
  }



  void addToList() async{
    if(documentCollectorBeanList==null){
      documentCollectorBeanList= new  List<DocumentCollectorBean>();
    }
      proceed();

       if (widget.mleadsId != null &&
        widget.mleadsId != "null" &&
        widget.mleadsId != "") {
      documentCollectorBean.mforeignindicator = widget.mleadsId;
    }
    if (widget.mrefno != null &&
        widget.mrefno != "null" &&
        widget.mrefno != "") {
      documentCollectorBean.loanmrefno = widget.mrefno;
    }
    if (widget.trefno != "null" &&
        widget.trefno != "" &&
        widget.trefno != null) {
      documentCollectorBean.loantrefno = widget.trefno;
    }

       if (documentCollectorBean.trefno == "" ||
           documentCollectorBean.trefno == null ||
           documentCollectorBean.trefno == "null") {
         await AppDatabase.get().generateTrefnoForDocuments().then((onValue) {
           documentCollectorBean.trefno = onValue;
         });
       }


       documentCollectorBean.mlastupdatedt = DateTime.now();
       if (documentCollectorBean.mcreateddt == null) {
         documentCollectorBean.mcreatedby = username;
         documentCollectorBean.mcreateddt = DateTime.now();
       }
       documentCollectorBean.mlastupdateby = username;
       documentCollectorBean.mlastupdatedt = DateTime.now();
       documentCollectorBean.mrefno = documentCollectorBean.mrefno != null ? documentCollectorBean.mrefno : 0;
       if (documentCollectorBean.mcreatedby == null ||
           documentCollectorBean.mcreatedby == '' ||
           documentCollectorBean.mcreatedby == 'null') {
         documentCollectorBean.mcreatedby = username;
       }


       documentCollectorBean.mgeolocation = geoLocation;
       documentCollectorBean.mgeologd = geoLongitude;
       documentCollectorBean.mgeolatd = geoLatitude;
       documentCollectorBeanList.add(documentCollectorBean);
       setState(() {
         documentCollectorBean  =new DocumentCollectorBean();

         tempIssueDateYear="";
         tempIssueDateDay="";
         tempIssueDateMonth="";
         tempExpDateYear="";
         tempExpDateDay="";
         tempExpDateMonth="";
         issueDate= "__-__-____";
         expDate= "__-__-____";
         documenttype= blankBean;
       });
  }




  proceed() async {
    if (!validateSubmit()) {
      return;
    }
    print("documentCollectorBean"+documentCollectorBean.toString());
    DocumentCollectorBean documentCollectorBeanList;
    documentCollectorBean.mcreatedby = username;
    if (widget.mleadsId != null &&
        widget.mleadsId != "null" &&
        widget.mleadsId != "") {
      documentCollectorBean.mforeignindicator = widget.mleadsId;
    }
    if (widget.mrefno != null &&
        widget.mrefno != "null" &&
        widget.mrefno != "") {
      documentCollectorBean.loanmrefno = widget.mrefno;
    }
    if (widget.trefno != "null" &&
        widget.trefno != "" &&
        widget.trefno != null) {
      documentCollectorBean.loantrefno = widget.trefno;
    }




    documentCollectorBean.mlastupdatedt = DateTime.now();
    if (documentCollectorBean.mcreateddt == null) {
      documentCollectorBean.mcreatedby = username;
      documentCollectorBean.mcreateddt = DateTime.now();
    }
    documentCollectorBean.mlastupdateby = username;
    documentCollectorBean.mlastupdatedt = DateTime.now();
    documentCollectorBean.mrefno = documentCollectorBean.mrefno != null ? documentCollectorBean.mrefno : 0;
    if (documentCollectorBean.mcreatedby == null ||
        documentCollectorBean.mcreatedby == '' ||
        documentCollectorBean.mcreatedby == 'null') {
      documentCollectorBean.mcreatedby = username;
    }


    documentCollectorBean.mgeolocation = geoLocation;
    documentCollectorBean.mgeologd = geoLongitude;
    documentCollectorBean.mgeolatd = geoLatitude;
//    documentCollectorBeanList.add(documentCollectorBean);



    if (documentCollectorBean.mrefno == null) {
      documentCollectorBean.mrefno = 0;
    }
    if (documentCollectorBean != null) {
      documentCollectorBeanList = documentCollectorBean;
    }
    print("documentCollectorBeanList"+documentCollectorBeanList.toString());
    await AppDatabase.get().updateDocumentsMasters(documentCollectorBeanList).then((val) {
      print("documentCollectorBeanList"+documentCollectorBeanList.toString());
      print("val here is " + val.toString());
    });
    _successfulSubmit();
    setState(() {
      documentCollectorBean  =new DocumentCollectorBean();

      tempIssueDateYear="";
      tempIssueDateDay="";
      tempIssueDateMonth="";
      tempExpDateYear="";
      tempExpDateDay="";
      tempExpDateMonth="";
      issueDate= "__-__-____";
      expDate= "__-__-____";
      documenttype= blankBean;
    });

    }

  bool validateSubmit() {
    String error = "";

    if(documentCollectorBean.imgstring==null||documentCollectorBean.imgstring.toString().trim()==""){
      _showAlert("Image", "Cannot be Empty");
      return false;

    }


    try {

      try {
        if (DateTime.now().isBefore(documentCollectorBean.missuedate)) {
          _showAlert("Issue Date", "Cannot be Future Date");
        }
      }catch(_){
        _showAlert("Issue Date", "Cannot be Future Date");
      }
    } catch (e) {
      _showAlert("Issue Date", "It is Mandatory");

      return false;
    }

    try {

      if (documentCollectorBean.mexpdate==DateTime.now() || documentCollectorBean.mexpdate.isBefore(DateTime.now())) {
        _showAlert("Expiry Date", "It should be greater than Current Date");

        return false;
      }
    } catch (e) {
      _showAlert("Expiry Date", "It is Mandatory");

      return false;
    }

 /*
    if( documentCollectorBean.missuedate!=null){
          print("documentCollectorBean.missuedate"+documentCollectorBean.missuedate.toString());
        if (DateTime.now().isBefore(documentCollectorBean.missuedate)) {
          _showAlert("Issue Date", "Cannot be Future Date");
          return false;
        }}

      if( documentCollectorBean.mexpdate!=null){

      if (documentCollectorBean.mexpdate==DateTime.now() || documentCollectorBean.mexpdate.isBefore(DateTime.now())) {
        _showAlert("Expiry Date", "It should be greater than Current Date");

        return false;
      }}*/
  /*  } catch (e) {
      //   _showAlert("Id 2 Expiry Date", "It is Mandatory");

      return false;
    }*/

    return true;
  }


  Future<void> _successfulSubmit() async {
    return showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: new Icon(
              Icons.offline_pin,
              color: Colors.green,
              size: 60.0,
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[
                  Text('Done'),
                ],
              ),
            ),
            actions: <Widget>[
              FlatButton(
                child: Text('Ok '),
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();

                },
              ),
            ],
          );
        });
  }


  Future<void> _showAlert(arg, error) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('$arg error'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('$error.'),
              ],
            ),
          ),
          actions: <Widget>[
            FlatButton(
              child: Text('ok'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void getDocumentsList(int mrefno, int trefno) {
    AppDatabase.get().getDocumentListonTrefno(trefno).then(
            (List<DocumentCollectorBean> DocumentCollectorData){
          this.documentCollectorBeanList=DocumentCollectorData;
          print(trefno.toString());
          print(mrefno.toString());
          print("DocumentCollectorData"+DocumentCollectorData.toString());
          Navigator.of(context).pop();
          if(DocumentCollectorData.isEmpty){
            _CheckIfThere();
          }
          else{
            Navigator.push(
              context,
              new MaterialPageRoute(
                  builder: (context) => new ViewDocuments(DocumentCollectorData)), //
              // When Authorized Navigate to the next screen
            );}

        });
  }

  Future<void> _CheckIfThere() async {

    return showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: new Icon(
              Icons.cancel,
              color: Colors.red,
              size: 60.0,
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[
                  new Row(
                    children: <Widget>[
                      new Text(
                          "            No Records Found "),
                    ],
                  ),
                ],
              ),
            ),
            actions: <Widget>[
              FlatButton(
                child: Text('Ok '),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        });
  }}
