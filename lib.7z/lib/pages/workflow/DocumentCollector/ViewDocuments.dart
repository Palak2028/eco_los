
import 'dart:convert';
import 'dart:io';

import 'package:eco_los/Utilities/GetSubLookupAsMis.dart';
import 'package:eco_los/pages/workflow/DocumentCollector/ViewDocuments.dart';
import 'package:eco_los/pages/workflow/GRT/Photo_view.dart';
import 'package:eco_los/pages/workflow/LoanApplication/bean/PurposeOfLoan.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:eco_los/Utilities/globals.dart' as globals;
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:photo_view/photo_view.dart';

import 'package:photo_view/photo_view_gallery.dart';
import '../../../translations.dart';
import '../LookupMasterBean.dart';
import 'DocumentCollectorBean.dart';
import 'package:eco_los/pages/workflow/DocumentCollector/DocumentCollectorBean.dart';

class ViewDocuments extends StatefulWidget {
  final List<DocumentCollectorBean> documentCollectorBeanList;
  ViewDocuments(this.documentCollectorBeanList);


  @override
  _ViewDocuments createState() =>
      _ViewDocuments();
}

class _ViewDocuments
    extends State<ViewDocuments> {
  List<DocumentCollectorBean> documentCollectorBeanList=new List<DocumentCollectorBean>();
  List<DataRow> _sampleDataRows = new List<DataRow>();
  List<DataColumn> _dataColumns = new List<DataColumn>();
  List<int> selectedIndex = new List<int>();
  final dateFormat = DateFormat("yyyy/MM/dd hh:mm:ss");
  PhotoViewGallery DocList=null;
  // double shadowbalance=double.parse(widget.documentCollectorBeanList[0].mtotallienfcy)+double.parse(widget.documentCollectorBeanList[0].macttotballcy);
  var rows2;
  var cols2;

  @override
  void initState() {
    setDocuments();
    super.initState();
    List columnName = [
      /*"SrNo",*/
      "Amount",
      "",
      "",
      "",
      ""
    ];
    //  print("documentCollectorBeanList"+widget.documentCollectorBeanList.toString());



    if(widget.documentCollectorBeanList!=null){
      documentCollectorBeanList =widget.documentCollectorBeanList;
    }
    getRow();
    cols2 = [
     /* new DataColumn(
        label: const Text('SrNo'),

      ),*/
      new DataColumn(
        label: const Text('Document Description'),

      ),
      new DataColumn(
        label: const Text('ID Number'),

      ),
      new DataColumn(
        label: const Text('Issuing Authority'),
      ),
      new DataColumn(
        label: const Text('Issue Date'),
      ),
      new DataColumn(
        label: const Text('Expiry Date'),
      ),
    ];
  }
  void getRow(){
    rows2 = new List.generate(
        documentCollectorBeanList.length,
            (int a) => new DataRow(

            cells: [
         /*     new DataCell(
                  new Text((a+1).toString())),*/
              new DataCell(
                  new Text(documentCollectorBeanList[a].mimgtypedesc==null||documentCollectorBeanList[a].mimgtypedesc.toString()=="null"?"":
                  documentCollectorBeanList[a].mimgtypedesc.toString()
                  )),
              new DataCell(
                  new Text(documentCollectorBeanList[a].mdoctno==null||documentCollectorBeanList[a].mdoctno.toString()=="null"?"":
                  documentCollectorBeanList[a].mdoctno.toString()
                  )),
              new DataCell(
                  new Text(documentCollectorBeanList[a].missuingauth==null||documentCollectorBeanList[a].missuingauth.toString()=="null"?"":
                  documentCollectorBeanList[a].missuingauth.toString()
                  )),
              new DataCell(
                  new Text(documentCollectorBeanList[a].missuedate==null||documentCollectorBeanList[a].missuedate.toString()=="null"?"":
                  documentCollectorBeanList[a].missuedate.toString().substring(0,10)
                  )),
              new DataCell(
                  new Text(documentCollectorBeanList[a].mexpdate==null||documentCollectorBeanList[a].mexpdate.toString()=="null"?"":
                  documentCollectorBeanList[a].mexpdate.toString().substring(0,10)
                  )),


            ]));

  }

  @override
  Widget build(BuildContext context) {
   //  MaterialApp(
     return  Scaffold(
    appBar: AppBar(
    title: Text('Documents'),
    ),
    // Implemented with a PageView, simpler than setting it up yourself
    // You can either specify images directly or by using a builder as in this tutorial
    body:  SingleChildScrollView(
        child: ListBody(
         children: <Widget>[
          Container(
            height: 400.0,width: 200.0,
            child:DocList!=null?DocList:Container(),
          ),
      /*    Row(
            children: <Widget>[

              new Card(
                  child: new Text(widget.documentCollectorBeanList[0].mimgtypedesc.toString()=="null"||widget.documentCollectorBeanList[0].mimgtypedesc.toString()==""?"":widget.documentCollectorBeanList[0].mimgtypedesc.toString(), style: new TextStyle(
                    color: Color(0xff07426A),
                    fontSize: 20.0,
                  ), )
              )
            ],
          ),*/
          new Row(
            children: <Widget>[
              Container(
                height: 600.0,
                child: DataTable(
                  rows: rows2,
                  columns: cols2,
                  columnSpacing:1.0,
                    horizontalMargin:1.0,
                ),

              ),
            ],
          )

    ]
    )
    ),
     //)

    );
  }




  setDocuments() async{
    var DocListView=new List<PhotoViewGalleryPageOptions>();
    for(int docCount=0;docCount<widget.documentCollectorBeanList.length;docCount++){
      DocListView.add(  PhotoViewGalleryPageOptions(

        imageProvider: FileImage(
          File(widget.documentCollectorBeanList[docCount].imgstring),

        ),

       // heroAttributes: PhotoViewHeroAttributes(tag: widget.documentCollectorBeanList[docCount].mimgtypedesc!=null?widget.documentCollectorBeanList[docCount].mimgtypedesc:""),

      )
      );


    }
    DocList=  PhotoViewGallery( pageOptions:DocListView);
    setState(() {

    });


  }
}








