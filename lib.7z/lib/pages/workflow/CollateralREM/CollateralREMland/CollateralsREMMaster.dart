import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';
import 'package:eco_los/db/AppDatabase.dart';
import 'package:eco_los/db/TablesColumnFile.dart';
import 'package:eco_los/pages/workflow/CollateralREM/Bean/CollateralREMlandandhouseBean.dart';
import 'package:eco_los/pages/workflow/CollateralREM/CollateralREMland/CollateralREMlandandbuilding.dart';
import 'package:eco_los/pages/workflow/CollateralREM/CollateralREMland/CollateralREMlandandhouse.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CollateralsREMMaster extends StatefulWidget {
  final collateralPassedObject;
  final collateralREMPassedObject;
  //CollateralsREMMaster({Key key, this.collateralPassedObject}) : super(key: key);

  CollateralsREMMaster(this.collateralPassedObject,this.collateralREMPassedObject);
  @override
  CollateralsREMMasterState createState() => new CollateralsREMMasterState();
}

class CollateralsREMMasterState extends State<CollateralsREMMaster>
    with SingleTickerProviderStateMixin {
  TabController _tabController;
  SharedPreferences prefs;
  String loginTime;
  int usrGrpCode = 0;
  String username;
  String usrRole;
  String branch = "";
  String geoLocation;
  String geoLatitude;
  String geoLongitude;
  String reportingUser;

  DateTime startTime = DateTime.now();
  final dateFormat = DateFormat("yyyy, mm, dd");
  DateTime date;
  TimeOfDay time;
  String approvalAmtLimit="0.0";
  String mreportinguser= "";

  static CollateralREMlandandhouseBean  collateralREMlandandhouseBean =  CollateralREMlandandhouseBean();

  int tabState = 2;
  static const List<String> tabNames = const <String>[
    'REM Land And House',
    'REM Land And Building'
  ];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _tabController = new TabController(vsync: this, initialIndex: 0, length: 2);



    if (widget.collateralREMPassedObject != null) {
      print("Inside if");
      collateralREMlandandhouseBean = widget.collateralREMPassedObject;
    } else {
      print("ELse mai hai");
      collateralREMlandandhouseBean = new CollateralREMlandandhouseBean();
      if(widget.collateralPassedObject.loanmrefno!="null"||widget.collateralPassedObject.loanmrefno!=""||widget.collateralPassedObject.loanmrefno!=null){
        collateralREMlandandhouseBean.mloanmrefno=widget.collateralPassedObject.loanmrefno;

      }

      if(widget.collateralPassedObject.loantrefno!="null"||widget.collateralPassedObject.loantrefno!=""||widget.collateralPassedObject.loantrefno!=null){
        collateralREMlandandhouseBean.mloantrefno=widget.collateralPassedObject.loantrefno;

      }

      if(widget.collateralPassedObject.mrefno!="null"||widget.collateralPassedObject.mrefno!=""||widget.collateralPassedObject.mrefno!=null){
        collateralREMlandandhouseBean.colleteralmrefno=widget.collateralPassedObject.mrefno;

      }

      if(widget.collateralPassedObject.trefno!="null"||widget.collateralPassedObject.trefno!=""||widget.collateralPassedObject.trefno!=null){
        collateralREMlandandhouseBean.colleteraltrefno=widget.collateralPassedObject.trefno;
      }

      collateralREMlandandhouseBean.mfname=widget.collateralPassedObject.mfname;
          collateralREMlandandhouseBean.mmname=widget.collateralPassedObject.mmname;
          collateralREMlandandhouseBean.mlname=widget.collateralPassedObject.mlname;
      collateralREMlandandhouseBean.mtitle=widget.collateralPassedObject.nametitle;
    }
    
    getSessionVariables();




    if(widget.collateralREMPassedObject!=null){
      collateralREMlandandhouseBean  = widget.collateralREMPassedObject;
      CollateralsREMMasterState.collateralREMlandandhouseBean.msrno =
          widget.collateralREMPassedObject.msrno;
      CollateralsREMMasterState.collateralREMlandandhouseBean.mprdacctid =
          widget.collateralREMPassedObject.mprdacctid;
      CollateralsREMMasterState.collateralREMlandandhouseBean.mlbrcode =
          widget.collateralREMPassedObject.mlbrcode;



    }
    else{

      CollateralsREMMasterState.collateralREMlandandhouseBean.msrno  = 0;
      CollateralsREMMasterState.collateralREMlandandhouseBean.mprdacctid = "00";
      CollateralsREMMasterState.collateralREMlandandhouseBean.mlbrcode = 0;
      CollateralsREMMasterState.collateralREMlandandhouseBean.mcreatedby= username;
      CollateralsREMMasterState.collateralREMlandandhouseBean.mcreateddt = DateTime.now();
    }


  }




  Future<Null> getSessionVariables() async {
    prefs = await SharedPreferences.getInstance();
    if(widget.collateralREMPassedObject==null){
      //if(widget.collateralREMPassedObject.trefno==null||widget.collateralREMPassedObject.trefno=="null"||widget.collateralREMPassedObject.trefno==0){
        await AppDatabase.get().getMaxCollateralREMlandandhouseTrefNo().then((val){
          CollateralsREMMasterState.collateralREMlandandhouseBean.trefno =val;
         // print("trefno"+CollateralsREMMasterState.collateralREMlandandhouseBean.trefno.toString());
        });
  //    }
  }


    setState(() {
      branch = prefs.get(TablesColumnFile.musrbrcode).toString();
      username = prefs.getString(TablesColumnFile.musrcode);
      usrRole = prefs.getString(TablesColumnFile.usrDesignation);
      usrGrpCode = prefs.getInt(TablesColumnFile.grpCd);
      loginTime = prefs.getString(TablesColumnFile.LoginTime);
      geoLocation=  prefs.getString(TablesColumnFile.geoLocation);
      geoLatitude  = prefs.get(TablesColumnFile.geoLatitude).toString();
      geoLongitude = prefs.get(TablesColumnFile.geoLongitude).toString();
      reportingUser= prefs.getString(TablesColumnFile.reportingUser);
      if(widget.collateralREMPassedObject==null){
        CollateralsREMMasterState.collateralREMlandandhouseBean.mcreatedby = username;
        CollateralsREMMasterState.collateralREMlandandhouseBean.mcreateddt = DateTime.now();
      }


    });
  }

  @override
  Widget build(BuildContext context) {
    return new WillPopScope(
      onWillPop: () {
        callBackDialog(context);
      },
      child: new Scaffold(
        //key: _scaffoldKeyMaster,
        appBar: new AppBar(
          title: new Text(
            "Collateral Land And Property",
            style: TextStyle(color: Colors.white),
          ),
          elevation: 3.0,
          leading: new IconButton(
            icon: new Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () {
              callBackDialog(context);
            },
          ),
          backgroundColor: Color(0xff07426A),
          brightness: Brightness.light,
          bottom: new TabBar(
            controller: _tabController,
            indicatorColor: Colors.black,
            isScrollable: true,
            tabs: new List.generate(tabNames.length, (index) {
              return new Tab(text: tabNames[index].toUpperCase());
            }),
          ),
          actions: <Widget>[
            new IconButton(
              icon: new Icon(
                Icons.save,
                color: Colors.white,
                size: 40.0,
              ),
              onPressed: () {
                _submitData();
              },
            ),
            new Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5.0),
            ),
          ],

        ),
        body: new TabBarView(
          controller: _tabController,
          children: <Widget>[
            CollateralREMlandandhouse(),
            CollateralREMLandAndBuilding()
          ],
        ),
      ),
    );
  }

  Future<Null> _submitData() async {




    if(CollateralsREMMasterState.collateralREMlandandhouseBean!=null) {


      if (CollateralsREMMasterState.collateralREMlandandhouseBean.mcreateddt == null) {
        CollateralsREMMasterState.collateralREMlandandhouseBean.mcreatedby = username;
        CollateralsREMMasterState.collateralREMlandandhouseBean.mcreateddt = DateTime.now();
      }
      CollateralsREMMasterState.collateralREMlandandhouseBean.mrefno = CollateralsREMMasterState.collateralREMlandandhouseBean.mrefno != null ? CollateralsREMMasterState.collateralREMlandandhouseBean.mrefno : 0;
      if (CollateralsREMMasterState.collateralREMlandandhouseBean.mcreatedby == null ||
          CollateralsREMMasterState.collateralREMlandandhouseBean.mcreatedby == '' ||
          CollateralsREMMasterState.collateralREMlandandhouseBean.mcreatedby == 'null') {
        CollateralsREMMasterState.collateralREMlandandhouseBean.mcreatedby = username;
      }

      CollateralsREMMasterState.collateralREMlandandhouseBean.mlastupdatedt = DateTime.now();
      CollateralsREMMasterState.collateralREMlandandhouseBean.mgeolocation = geoLocation;
      CollateralsREMMasterState.collateralREMlandandhouseBean.mgeologd = geoLongitude;
      CollateralsREMMasterState.collateralREMlandandhouseBean.mgeolatd = geoLatitude;

      CollateralsREMMasterState.collateralREMlandandhouseBean.missynctocoresys = 0;
      CollateralsREMMasterState.collateralREMlandandhouseBean.mlastupdatedt =
          DateTime.now();
      CollateralsREMMasterState.collateralREMlandandhouseBean.mlastupdateby = username;
      CollateralsREMMasterState.collateralREMlandandhouseBean.mlastsynsdate = null;
    

    print("CollateralsREMMasterState.collateralREMlandandhouseBean "+CollateralsREMMasterState.collateralREMlandandhouseBean.toString());
      await AppDatabase.get().updateCollateralREMlandandhouseMaster(
          CollateralsREMMasterState.collateralREMlandandhouseBean);

      _successfulSubmit();
    }




  }

  Future<void> _successfulSubmit() async {
    return showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: new Icon(
              Icons.offline_pin,
              color: Colors.green,
              size: 60.0,
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[
                  Text('REM Collatral Submitted Successfully'),
                ],
              ),
            ),
            actions: <Widget>[
              FlatButton(
                child: Text('Ok '),
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        });
  }





  Future<bool> onPop(BuildContext context, String agrs1, String args2) async{
    return showDialog(
      context: context,
      builder: (context) => new AlertDialog(
        title: new Text(agrs1),
        content: new Text(args2),
        actions: <Widget>[
          new FlatButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: new Text('No'),
          ),
          new FlatButton(
            onPressed: () {
              _submitData();
            },
            child: new Text('Yes'),
          ),
        ],
      ),
    ) ??
        false;
  }


  Future<bool> callBackDialog(BuildContext context) {
    return showDialog(
      context: context,
      builder: (context) => new AlertDialog(
        title: new Text('Are you sure?'),
        content: new Text('Do you want to Go To Loan List without saving data'),
        actions: <Widget>[
          new FlatButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: new Text('No'),
          ),
          new FlatButton(
            onPressed: () {
              collateralREMlandandhouseBean =  new  CollateralREMlandandhouseBean();
              Navigator.of(context).pop(true);
              Navigator.of(context).pop(true);
              Navigator.of(context).pop(true);
              Navigator.of(context).pop(true);

//                CustomerFormationMasterTabsState.applicantDob ="__-__-____";

            },
            child: new Text('Yes'),
          ),
        ],
      ),
    ) ??
        false;
  }


}
