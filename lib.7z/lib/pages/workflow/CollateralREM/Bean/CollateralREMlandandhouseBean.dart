import 'package:eco_los/db/TablesColumnFile.dart';

class CollateralREMlandandhouseBean {
  int trefno;
  int mrefno;
  int mloantrefno;
  int mloanmrefno;
  int colleteraltrefno;
  int colleteralmrefno;
  int mlbrcode;
  String mprdacctid;
  String mtitle;
  String mfname;
  String mmname;
  String mlname;
  String maddress1;
  String maddress2;
  String mcountry;
  String mstate;
  String mdist;
  String msubdist;
  String marea;
  int mpoboxno;
  String mhousebuilttype;
  String menvdescription;
  double mlotarea;
  double mfloorarea;
  String mdescofproperty;
  String msizeofproperty;
  String msizeofpropertyl;
  String msizeofpropertyh;
  int mtctno;
  int msrno;
  DateTime mregdate;
  DateTime mepebdate;
  String mrescodeorremark;
  int mepebno;
  String mregofdeedslocation;
  DateTime mcreateddt;
  String mcreatedby;
  DateTime mlastupdatedt;
  String mlastupdateby;
  String mgeolocation;
  String mgeolatd;

  @override
  String toString() {
    return 'CollateralREMlandandhouseBean{trefno: $trefno, mrefno: $mrefno, mloantrefno: $mloantrefno, mloanmrefno: $mloanmrefno, colleteraltrefno: $colleteraltrefno, colleteralmrefno: $colleteralmrefno, mlbrcode: $mlbrcode, mprdacctid: $mprdacctid, mtitle: $mtitle, mfname: $mfname, mmname: $mmname, mlname: $mlname, maddress1: $maddress1, maddress2: $maddress2, mcountry: $mcountry, mstate: $mstate, mdist: $mdist, msubdist: $msubdist, marea: $marea, mpoboxno: $mpoboxno, mhousebuilttype: $mhousebuilttype, menvdescription: $menvdescription, mlotarea: $mlotarea, mfloorarea: $mfloorarea, mdescofproperty: $mdescofproperty, mtctno: $mtctno, msrno: $msrno, mregdate: $mregdate, mepebdate: $mepebdate, mrescodeorremark: $mrescodeorremark, mepebno: $mepebno, mregofdeedslocation: $mregofdeedslocation, mcreateddt: $mcreateddt, mcreatedby: $mcreatedby, mlastupdatedt: $mlastupdatedt, mlastupdateby: $mlastupdateby, mgeolocation: $mgeolocation, mgeolatd: $mgeolatd, mgeologd: $mgeologd, mlastsynsdate: $mlastsynsdate, merrormessage: $merrormessage, missynctocoresys: $missynctocoresys, mcollno: $mcollno, mpriorsec: $mpriorsec, mcolltype: $mcolltype, mcollsubtype: $mcollsubtype, mtypeofproperty: $mtypeofproperty, mltypeofownercerti: $mltypeofownercerti, mhtypeofownercerti: $mhtypeofownercerti, mlissuednoprop: $mlissuednoprop, mhissuednoprop: $mhissuednoprop, mlissuedt: $mlissuedt, mhissuedt: $mhissuedt, mlissueby: $mlissueby, mhissueby: $mhissueby, mlsizeprop: $mlsizeprop, mhsizeprop: $mhsizeprop, mlnpropborder: $mlnpropborder, mhnpropborder: $mhnpropborder, mlspropborder: $mlspropborder, mhspropborder: $mhspropborder, mlwpropborder: $mlwpropborder, mhwpropborder: $mhwpropborder, mlepropborder: $mlepropborder, mhepropborder: $mhepropborder, mllocprop: $mllocprop, mhlocprop: $mhlocprop, mltitleowener: $mltitleowener, mhtitleowener: $mhtitleowener, mllocalauthvalue: $mllocalauthvalue, mhlocalauthvalue: $mhlocalauthvalue, mlrealestatecmpnyvalue: $mlrealestatecmpnyvalue, mhrealestatecmpnyvalue: $mhrealestatecmpnyvalue, mlaskneighonvalue: $mlaskneighonvalue, mhaskneighonvalue: $mhaskneighonvalue, mlsumonvalprop: $mlsumonvalprop, mhsumonvalprop: $mhsumonvalprop}';
  }

  String mgeologd;
  DateTime mlastsynsdate;
  String merrormessage;
  int missynctocoresys;
  int mcollno;
  String mpriorsec;
  String mcolltype;
  String mcollsubtype;

  String mtypeofproperty;
  String mltypeofownercerti;
  String mhtypeofownercerti;
  String mlissuednoprop;
  String mhissuednoprop;
  DateTime mlissuedt;
  DateTime mhissuedt;
  String mlissueby;
  String mhissueby;
  String mlsizeprop;
  String mhsizeprop;
  String mlnpropborder;
  String mhnpropborder;
  String mlspropborder;
  String mhspropborder;
  String mlwpropborder;
  String mhwpropborder;
  String mlepropborder;
  String mhepropborder;
  String mllocprop;
  String mhlocprop;
  String mltitleowener;
  String mhtitleowener;
  double mllocalauthvalue;
  double mhlocalauthvalue;
  double mlrealestatecmpnyvalue;
  double mhrealestatecmpnyvalue;
  double mlaskneighonvalue;
  double mhaskneighonvalue;
  double mlsumonvalprop;
  double mhsumonvalprop;




  CollateralREMlandandhouseBean(
      {
        this.trefno,
        this.mrefno,
        this.mloantrefno,
        this.mloanmrefno,
        this.colleteraltrefno,
        this.colleteralmrefno,
        this.mlbrcode,
        this.mprdacctid,
        this.mtitle,
        this.mfname,
        this.mmname,
        this.mlname,
        this.maddress1,
        this.maddress2,
        this.mcountry,
        this.mstate,
        this.mdist,
        this.msubdist,
        this.marea,
        this.mpoboxno,
        this.mhousebuilttype,
        this.menvdescription,
        this.mlotarea,
        this.mfloorarea,
        this.mdescofproperty,
        this.msizeofproperty,
        this.msizeofpropertyl,
        this.msizeofpropertyh,
        this.mtctno,
        this.msrno,
        this.mregdate,
        this.mepebdate,
        this.mrescodeorremark,
        this.mepebno,
        this.mregofdeedslocation,
        this.mcreateddt,
        this.mcreatedby,
        this.mlastupdatedt,
        this.mlastupdateby,
        this.mgeolocation,
        this.mgeolatd,
        this.mgeologd,
        this.mlastsynsdate,
        this.merrormessage,
        this.missynctocoresys,
        this.mcollno,
        this.mpriorsec,
        this.mcolltype,
        this.mcollsubtype,
        this.mtypeofproperty,
        this.mltypeofownercerti,
        this.mhtypeofownercerti,
        this.mlissuednoprop,
        this.mhissuednoprop,
        this.mlissueby,
        this.mhissueby,
        this.mlsizeprop,
        this.mhsizeprop,
        this.mlnpropborder,
        this.mhnpropborder,
        this.mlspropborder,
        this.mhspropborder,
        this.mlwpropborder,
        this.mhwpropborder,
        this.mlepropborder,
        this.mhepropborder,
        this.mllocprop,
        this.mhlocprop,
        this.mltitleowener,
        this.mhtitleowener,
        this.mllocalauthvalue,
        this.mhlocalauthvalue,
        this.mlrealestatecmpnyvalue,
        this.mhrealestatecmpnyvalue,
        this.mlaskneighonvalue,
        this.mhaskneighonvalue,
        this.mlsumonvalprop,
        this.mhsumonvalprop,
        this.mlissuedt,
        this.mhissuedt


      });


  factory CollateralREMlandandhouseBean.fromMap(Map<String, dynamic> map) {
    print("inside for map");
    return CollateralREMlandandhouseBean(
      trefno:	map[TablesColumnFile.trefno] as int,
      mrefno:	map[TablesColumnFile.mrefno] as int,
      mloantrefno:	map[TablesColumnFile.loantrefno] as int,
      mloanmrefno:	map[TablesColumnFile.loanmrefno] as int,
      colleteraltrefno:	map[TablesColumnFile.colleteraltrefno] as int,
      colleteralmrefno:	map[TablesColumnFile.colleteralmrefno] as int,
      mlbrcode:	map[TablesColumnFile.mlbrcode] as int,
      mprdacctid:	map[TablesColumnFile.mprdacctid] as String,
      mtitle:	map[TablesColumnFile.mtitle] as String,
      mfname:	map[TablesColumnFile.mfname] as String,
      mmname:	map[TablesColumnFile.mmname] as String,
      mlname:	map[TablesColumnFile.mlname] as String,
      maddress1:	map[TablesColumnFile.maddress1] as String,
      maddress2:	map[TablesColumnFile.maddress2] as String,
      mcountry:	map[TablesColumnFile.mcountry] as String,
      mstate:	map[TablesColumnFile.mstate] as String,
      mdist:	map[TablesColumnFile.mdist] as String,
      msubdist:	map[TablesColumnFile.msubdist] as String,
      marea:	map[TablesColumnFile.marea] as String,
      mpoboxno:	map[TablesColumnFile.mpoboxno] as int,
      mhousebuilttype:	map[TablesColumnFile.mhousebuilttype] as String,
      menvdescription:	map[TablesColumnFile.menvdescription] as String,
      mlotarea:	map[TablesColumnFile.mlotarea] as double,
      mfloorarea:	map[TablesColumnFile.mfloorarea] as double,
      mdescofproperty:	map[TablesColumnFile.mdescofproperty] as String,
      msizeofproperty:	map[TablesColumnFile.msizeofproperty] as String,
      msizeofpropertyl:	map[TablesColumnFile.msizeofpropertyl] as String,
      msizeofpropertyh:	map[TablesColumnFile.msizeofpropertyh] as String,
      mtctno:	map[TablesColumnFile.mtctno] as int,
      msrno:	map[TablesColumnFile.msrno] as int,
      mregdate: (map[TablesColumnFile.mregdate]=="null"||map[TablesColumnFile.mregdate]==null)?null:DateTime.parse(map[TablesColumnFile.mregdate]) as DateTime,
      mepebdate: (map[TablesColumnFile.mepebdate]=="null"||map[TablesColumnFile.mepebdate]==null)?null:DateTime.parse(map[TablesColumnFile.mepebdate]) as DateTime,
      mrescodeorremark:	map[TablesColumnFile.mrescodeorremark] as String,
      mepebno:	map[TablesColumnFile.mepebno] as int,
      mregofdeedslocation:	map[TablesColumnFile.mregofdeedslocation] as String,
      mcreateddt: (map[TablesColumnFile.mcreateddt]=="null"||map[TablesColumnFile.mcreateddt]==null)?null:DateTime.parse(map[TablesColumnFile.mcreateddt]) as DateTime,
      mcreatedby:	map[TablesColumnFile.mcreatedby] as String,
      mlastupdatedt:(map[TablesColumnFile.mlastupdatedt]=="null"||map[TablesColumnFile.mlastupdatedt]==null)?null:DateTime.parse(map[TablesColumnFile.mlastupdatedt]) as DateTime,
      mlastupdateby:	map[TablesColumnFile.mlastupdateby] as String,
      mgeolocation:	map[TablesColumnFile.mgeolocation] as String,
      mgeolatd:	map[TablesColumnFile.mgeolatd] as String,
      mgeologd:	map[TablesColumnFile.mgeologd] as String,
      mlastsynsdate:(map[TablesColumnFile.mlastsynsdate]=="null"||map[TablesColumnFile.mlastsynsdate]==null)?null:DateTime.parse(map[TablesColumnFile.mlastsynsdate]) as DateTime,
      merrormessage:	map[TablesColumnFile.merrormessage] as String,
      missynctocoresys:	map[TablesColumnFile.missynctocoresys] as int,
      mcollno:	map[TablesColumnFile.mcollno] as int,
      mpriorsec:	map[TablesColumnFile.mpriorsec] as String,
      mcolltype:	map[TablesColumnFile.mcolltype] as String,
      mcollsubtype:	map[TablesColumnFile.mcollsubtype] as String,
      mtypeofproperty:	map[TablesColumnFile.mtypeofproperty] as String,
      mltypeofownercerti:	map[TablesColumnFile.mltypeofownercerti] as String,
      mhtypeofownercerti:	map[TablesColumnFile.mhtypeofownercerti] as String,
      mlissuednoprop:	map[TablesColumnFile.mlissuednoprop] as String,
      mhissuednoprop:	map[TablesColumnFile.mhissuednoprop] as String,
      mlissueby:	map[TablesColumnFile.mlissueby] as String,
      mhissueby:	map[TablesColumnFile.mhissueby] as String,
      mlsizeprop:	map[TablesColumnFile.mlsizeprop] as String,
      mhsizeprop:	map[TablesColumnFile.mhsizeprop] as String,
      mlnpropborder:	map[TablesColumnFile.mlnpropborder] as String,
      mhnpropborder:	map[TablesColumnFile.mhnpropborder] as String,
      mlspropborder:	map[TablesColumnFile.mlspropborder] as String,
      mhspropborder:	map[TablesColumnFile.mhspropborder] as String,
      mlwpropborder:	map[TablesColumnFile.mlwpropborder] as String,
      mhwpropborder:	map[TablesColumnFile.mhwpropborder] as String,
      mlepropborder:	map[TablesColumnFile.mlepropborder] as String,
      mhepropborder:	map[TablesColumnFile.mhepropborder] as String,
      mllocprop:	map[TablesColumnFile.mllocprop] as String,
      mhlocprop:	map[TablesColumnFile.mhlocprop] as String,
      mltitleowener:	map[TablesColumnFile.mltitleowener] as String,
      mhtitleowener:	map[TablesColumnFile.mhtitleowener] as String,
      mllocalauthvalue:	map[TablesColumnFile.mllocalauthvalue] as double,
      mhlocalauthvalue:	map[TablesColumnFile.mhlocalauthvalue] as double,
      mlrealestatecmpnyvalue:	map[TablesColumnFile.mlrealestatecmpnyvalue] as double,
      mhrealestatecmpnyvalue:	map[TablesColumnFile.mhrealestatecmpnyvalue] as double,
      mlaskneighonvalue:	map[TablesColumnFile.mlaskneighonvalue] as double,
      mhaskneighonvalue:	map[TablesColumnFile.mhaskneighonvalue] as double,
      mlsumonvalprop:	map[TablesColumnFile.mlsumonvalprop] as double,
      mhsumonvalprop:	map[TablesColumnFile.mhsumonvalprop] as double,
      mlissuedt:(map[TablesColumnFile.mlissuedt]=="null"||map[TablesColumnFile.mlissuedt]==null)?null:DateTime.parse(map[TablesColumnFile.mlissuedt]) as DateTime,
      mhissuedt:(map[TablesColumnFile.mhissuedt]=="null"||map[TablesColumnFile.mhissuedt]==null)?null:DateTime.parse(map[TablesColumnFile.mhissuedt]) as DateTime,








    );

  }
  factory CollateralREMlandandhouseBean.fromMapMiddleware(Map<String, dynamic> map) {
    print("fromMap");
    return CollateralREMlandandhouseBean(
      trefno:	map[TablesColumnFile.trefno] as int,
      mrefno:	map[TablesColumnFile.mrefno] as int,
      mloantrefno:	map[TablesColumnFile.loantrefno] as int,
      mloanmrefno:	map[TablesColumnFile.loanmrefno] as int,
      colleteraltrefno:	map[TablesColumnFile.colleteraltrefno] as int,
      colleteralmrefno:	map[TablesColumnFile.colleteralmrefno] as int,
      mlbrcode:	map[TablesColumnFile.mlbrcode] as int,
      mprdacctid:	map[TablesColumnFile.mprdacctid] as String,
      mtitle:	map[TablesColumnFile.mtitle] as String,
      mfname:	map[TablesColumnFile.mfname] as String,
      mmname:	map[TablesColumnFile.mmname] as String,
      mlname:	map[TablesColumnFile.mlname] as String,
      maddress1:	map[TablesColumnFile.maddress1] as String,
      maddress2:	map[TablesColumnFile.maddress2] as String,
      mcountry:	map[TablesColumnFile.mcountry] as String,
      mstate:	map[TablesColumnFile.mstate] as String,
      mdist:	map[TablesColumnFile.mdist] as String,
      msubdist:	map[TablesColumnFile.msubdist] as String,
      marea:	map[TablesColumnFile.marea] as String,
      mpoboxno:	map[TablesColumnFile.mpoboxno] as int,
      mhousebuilttype:	map[TablesColumnFile.mhousebuilttype] as String,
      menvdescription:	map[TablesColumnFile.menvdescription] as String,
      mlotarea:	map[TablesColumnFile.mlotarea] as double,
      mfloorarea:	map[TablesColumnFile.mfloorarea] as double,
      mdescofproperty:	map[TablesColumnFile.mdescofproperty] as String,
      msizeofproperty:	map[TablesColumnFile.msizeofproperty] as String,
      msizeofpropertyl:	map[TablesColumnFile.msizeofpropertyl] as String,
      msizeofpropertyh:	map[TablesColumnFile.msizeofpropertyh] as String,
      mtctno:	map[TablesColumnFile.mtctno] as int,
      msrno:	map[TablesColumnFile.msrno] as int,
      mregdate: (map[TablesColumnFile.mregdate]=="null"||map[TablesColumnFile.mregdate]==null)?null:DateTime.parse(map[TablesColumnFile.mregdate]) as DateTime,
      mepebdate: (map[TablesColumnFile.mepebdate]=="null"||map[TablesColumnFile.mepebdate]==null)?null:DateTime.parse(map[TablesColumnFile.mepebdate]) as DateTime,
      mrescodeorremark:	map[TablesColumnFile.mrescodeorremark] as String,
      mepebno:	map[TablesColumnFile.mepebno] as int,
      mregofdeedslocation:	map[TablesColumnFile.mregofdeedslocation] as String,
      mcreateddt: (map[TablesColumnFile.mcreateddt]=="null"||map[TablesColumnFile.mcreateddt]==null)?null:DateTime.parse(map[TablesColumnFile.mcreateddt]) as DateTime,
      mcreatedby:	map[TablesColumnFile.mcreatedby] as String,
      mlastupdatedt:(map[TablesColumnFile.mlastupdatedt]=="null"||map[TablesColumnFile.mlastupdatedt]==null)?null:DateTime.parse(map[TablesColumnFile.mlastupdatedt]) as DateTime,
      mlastupdateby:	map[TablesColumnFile.mlastupdateby] as String,
      mgeolocation:	map[TablesColumnFile.mgeolocation] as String,
      mgeolatd:	map[TablesColumnFile.mgeolatd] as String,
      mgeologd:	map[TablesColumnFile.mgeologd] as String,
      mlastsynsdate:(map[TablesColumnFile.mlastsynsdate]=="null"||map[TablesColumnFile.mlastsynsdate]==null)?null:DateTime.parse(map[TablesColumnFile.mlastsynsdate]) as DateTime,
      merrormessage:	map[TablesColumnFile.merrormessage] as String,
      missynctocoresys:	map[TablesColumnFile.missynctocoresys] as int,
      mcollno:	map[TablesColumnFile.mcollno] as int,
      mpriorsec:	map[TablesColumnFile.mpriorsec] as String,
      mcolltype:	map[TablesColumnFile.mcolltype] as String,
      mcollsubtype:	map[TablesColumnFile.mcollsubtype] as String,
      mtypeofproperty:	map[TablesColumnFile.mtypeofproperty] as String,
      mltypeofownercerti:	map[TablesColumnFile.mltypeofownercerti] as String,
      mhtypeofownercerti:	map[TablesColumnFile.mhtypeofownercerti] as String,
      mlissuednoprop:	map[TablesColumnFile.mlissuednoprop] as String,
      mhissuednoprop:	map[TablesColumnFile.mhissuednoprop] as String,
      mlissueby:	map[TablesColumnFile.mlissueby] as String,
      mhissueby:	map[TablesColumnFile.mhissueby] as String,
      mlsizeprop:	map[TablesColumnFile.mlsizeprop] as String,
      mhsizeprop:	map[TablesColumnFile.mhsizeprop] as String,
      mlnpropborder:	map[TablesColumnFile.mlnpropborder] as String,
      mhnpropborder:	map[TablesColumnFile.mhnpropborder] as String,
      mlspropborder:	map[TablesColumnFile.mlspropborder] as String,
      mhspropborder:	map[TablesColumnFile.mhspropborder] as String,
      mlwpropborder:	map[TablesColumnFile.mlwpropborder] as String,
      mhwpropborder:	map[TablesColumnFile.mhwpropborder] as String,
      mlepropborder:	map[TablesColumnFile.mlepropborder] as String,
      mhepropborder:	map[TablesColumnFile.mhepropborder] as String,
      mllocprop:	map[TablesColumnFile.mllocprop] as String,
      mhlocprop:	map[TablesColumnFile.mhlocprop] as String,
      mltitleowener:	map[TablesColumnFile.mltitleowener] as String,
      mhtitleowener:	map[TablesColumnFile.mhtitleowener] as String,
      mllocalauthvalue:	map[TablesColumnFile.mllocalauthvalue] as double,
      mhlocalauthvalue:	map[TablesColumnFile.mhlocalauthvalue] as double,
      mlrealestatecmpnyvalue:	map[TablesColumnFile.mlrealestatecmpnyvalue] as double,
      mhrealestatecmpnyvalue:	map[TablesColumnFile.mhrealestatecmpnyvalue] as double,
      mlaskneighonvalue:	map[TablesColumnFile.mlaskneighonvalue] as double,
      mhaskneighonvalue:	map[TablesColumnFile.mhaskneighonvalue] as double,
      mlsumonvalprop:	map[TablesColumnFile.mlsumonvalprop] as double,
      mhsumonvalprop:	map[TablesColumnFile.mhsumonvalprop] as double,
      mlissuedt:(map[TablesColumnFile.mlissuedt]=="null"||map[TablesColumnFile.mlissuedt]==null)?null:DateTime.parse(map[TablesColumnFile.mlissuedt]) as DateTime,
      mhissuedt:(map[TablesColumnFile.mhissuedt]=="null"||map[TablesColumnFile.mhissuedt]==null)?null:DateTime.parse(map[TablesColumnFile.mhissuedt]) as DateTime,
    );
  }

}

