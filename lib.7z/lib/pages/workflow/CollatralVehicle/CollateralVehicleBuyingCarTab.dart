import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:eco_los/Utilities/app_constant.dart';
import 'package:eco_los/Utilities/globals.dart' as globals;
import 'package:eco_los/pages/workflow/CollatralVehicle/CollateralVehicleBean.dart';
import 'package:eco_los/pages/workflow/CollatralVehicle/CollateralVehicleMaster.dart';
import 'package:eco_los/pages/workflow/LookupMasterBean.dart';
import 'package:eco_los/pages/workflow/address/FullScreenDialogForAreaSelection.dart';
import 'package:eco_los/pages/workflow/address/FullScreenDialogForCountrySelection.dart';
import 'package:eco_los/pages/workflow/address/FullScreenDialogForDistrictSelection.dart';
import 'package:eco_los/pages/workflow/address/FullScreenDialogForStateSelection.dart';
import 'package:eco_los/pages/workflow/address/FullScreenDialogForSubDistrictSelection.dart';
import 'package:eco_los/pages/workflow/address/beans/AreaDropDownBean.dart';
import 'package:eco_los/pages/workflow/address/beans/CountryDropDownBean.dart';
import 'package:eco_los/pages/workflow/address/beans/DistrictDropDownBean.dart';
import 'package:eco_los/pages/workflow/address/beans/StateDropDownBean.dart';
import 'package:eco_los/pages/workflow/address/beans/SubDistrictDropDownBean.dart';
import 'package:eco_los/db/AppDatabase.dart';


class CollateralVehicleBuying extends StatefulWidget {
  CollateralVehicleBuying({Key key}) : super(key: key);

  static Container _get(Widget child,
      [EdgeInsets pad = const EdgeInsets.all(6.0)]) =>
      new Container(
        padding: pad,
        child: child,
      );

  @override
  _CollateralVehicleBuyingState createState() =>
      new _CollateralVehicleBuyingState();
}

class _CollateralVehicleBuyingState
    extends State<CollateralVehicleBuying> {

  final GlobalKey<FormState> _formKey = new GlobalKey<FormState>();
  bool ifNullCheck(String value) {
    bool isNull = false;
    try {
      if (value == null || value == 'null' || value.trim()=='') {
        isNull = true;
      }
    }catch(_){
      isNull =true;
    }
    return isNull;
  }
  @override
  void initState() {
    getSessionVariables();

    if(CollateralVehicleMasterState.collateralVehicleBean==null){
      CollateralVehicleMasterState.collateralVehicleBean= new CollateralVehicleBean();
    }
  }





  Future<Null> getSessionVariables() async {

  }









  Widget getTextContainer(String textValue) {
    return new Container(
      padding: EdgeInsets.fromLTRB(5.0, 20.0, 0.0, 20.0),
      child: new Text(
        textValue,
        //textDirection: TextDirection,
        textAlign: TextAlign.start,
        /*overflow: TextOverflow.ellipsis,*/
        style: new TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.grey,
            fontStyle: FontStyle.normal,
            fontSize: 12.0),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    return Card(
      child: ListView(
        shrinkWrap: true,
        padding: const EdgeInsets.symmetric(horizontal: 8.0),
        children: <Widget>[
          new Form(
            key: _formKey,
            autovalidate: false,
            onWillPop: () {
              return Future(() => true);
            },
            onChanged: () {
              final FormState form = _formKey.currentState;
              form.save();
            },
            child: new Column(
              children: [

                new TextFormField(
                  keyboardType: TextInputType.text,
                  decoration: const InputDecoration(

                    hintText: 'Enter Brand',
                    labelText: 'Brand',
                    hintStyle: TextStyle(color: Colors.grey),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.blue,
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),
                  inputFormatters: [new LengthLimitingTextInputFormatter(30),globals.onlyAphaNumeric],
                  initialValue:
                  CollateralVehicleMasterState.collateralVehicleBean.mbrand!= null&&
                      CollateralVehicleMasterState.collateralVehicleBean.mbrand!="null" ?
                  CollateralVehicleMasterState.collateralVehicleBean.mbrand: "",
                  onSaved: (val) => CollateralVehicleMasterState.collateralVehicleBean.mbrand= val,
                ),
                Container(
                    color: Constant.semiMandatoryColor,
                    child:
                new TextFormField(
                  keyboardType: TextInputType.multiline,
                  decoration: const InputDecoration(

                    hintText: 'Enter Type',
                    labelText: 'Type',
                    hintStyle: TextStyle(color: Colors.grey),
                    /*labelStyle: TextStyle(color: Colors.grey),*/
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.blue,
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),
                  initialValue:  CollateralVehicleMasterState.collateralVehicleBean.mtype!= null&&
                      CollateralVehicleMasterState.collateralVehicleBean.mtype!="null"
                      ? CollateralVehicleMasterState.collateralVehicleBean.mtype
                      : "",
                  onSaved: (val) => CollateralVehicleMasterState.collateralVehicleBean.mtype= val,
                )),
                Container(
                  child: new TextFormField(
                    keyboardType: TextInputType.multiline,
                    decoration: const InputDecoration(
                      hintText: 'Enter Color',
                      labelText: 'Color',
                      hintStyle: TextStyle(color: Colors.grey),
                      /*labelStyle: TextStyle(color: Colors.grey),*/
                      border: UnderlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.black,
                          )),
                      focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xff5c6bc0),
                          )),
                      contentPadding: EdgeInsets.all(20.0),
                    ),
                    controller: CollateralVehicleMasterState.collateralVehicleBean.mcolor != null
                        ? TextEditingController(text: CollateralVehicleMasterState.collateralVehicleBean.mcolor)
                        : TextEditingController(text: ""),

                    onSaved: (val) {
                      //  if(val!=null) {
                      CollateralVehicleMasterState.collateralVehicleBean.mcolor = val;
                      // }
                    },
                  ),
                ),

                Container(
                    color: Constant.semiMandatoryColor,
                    child:
                new TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Enter Body Number',
                    labelText: 'Body Number',
                    hintStyle: TextStyle(color: Colors.grey),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.red,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff07426A),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),

                  controller: CollateralVehicleMasterState.collateralVehicleBean.mbodyno != null&&CollateralVehicleMasterState.collateralVehicleBean.mbodyno!= 0
                      ? TextEditingController(text:CollateralVehicleMasterState.collateralVehicleBean.mbodyno.toString())
                      : TextEditingController(text:""),
                  keyboardType: TextInputType.text,
                  onSaved: (val) {
                    if(val!=null&&val!="") {

                      try{
                        CollateralVehicleMasterState.collateralVehicleBean.mbodyno= val;
                      }catch(e){

                      }

                    }
                    else{
                      CollateralVehicleMasterState.collateralVehicleBean.mbodyno = '0';
                    }

                    //}
                  },
                )),
                Container(
                    color: Constant.semiMandatoryColor,
                    child:
                new TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Enter Engine Number',
                    labelText: 'Engine Number',
                    hintStyle: TextStyle(color: Colors.grey),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.red,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff07426A),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),

                  controller: CollateralVehicleMasterState.collateralVehicleBean.mengineno != null&&CollateralVehicleMasterState.collateralVehicleBean.mengineno!= 0
                      ? TextEditingController(text:CollateralVehicleMasterState.collateralVehicleBean.mengineno.toString())
                      : TextEditingController(text:""),
                  keyboardType: TextInputType.text,
                  onSaved: (val) {
                    if(val!=null&&val!="") {

                      try{
                        CollateralVehicleMasterState.collateralVehicleBean.mengineno= val;
                      }catch(e){

                      }

                    }
                    else{
                      CollateralVehicleMasterState.collateralVehicleBean.mengineno = '0';
                    }

                    //}
                  },
                )),
                Container(
                    color: Constant.semiMandatoryColor,
                    child:
                new TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Enter Chassis Number',
                    labelText: 'Chassis Number',
                    hintStyle: TextStyle(color: Colors.grey),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.red,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff07426A),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),

                  controller: CollateralVehicleMasterState.collateralVehicleBean.mchassisno != null&&CollateralVehicleMasterState.collateralVehicleBean.mchassisno!= 0
                      ? TextEditingController(text:CollateralVehicleMasterState.collateralVehicleBean.mchassisno.toString())
                      : TextEditingController(text:""),
                  keyboardType: TextInputType.text,
                  onSaved: (val) {
                    if(val!=null&&val!="") {

                      try{
                        CollateralVehicleMasterState.collateralVehicleBean.mchassisno= (val);
                      }catch(e){

                      }

                    }
                  },
                )),
                Container(
                  color: Constant.mandatoryColor,
                  child: new TextFormField(
                    keyboardType: TextInputType.text,
                    decoration: const InputDecoration(

                      hintText: 'Enter Made By',
                      labelText: 'Made By',
                      hintStyle: TextStyle(color: Colors.grey),
                      /*labelStyle: TextStyle(color: Colors.grey),*/
                      border: UnderlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.black,
                          )),
                      focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.blue,
                          )),
                      contentPadding: EdgeInsets.all(20.0),
                    ),
                    controller:CollateralVehicleMasterState.collateralVehicleBean.mmadeby == null
                        ? TextEditingController(text: "")
                        : TextEditingController(
                        text: CollateralVehicleMasterState.collateralVehicleBean.mmadeby),
                    onSaved: (val) {
                      if(val!=null&&val!=""){
                        try{
                          CollateralVehicleMasterState.collateralVehicleBean.mmadeby= (val);
                        }catch(e){

                        }
                      }

                    },
                  ),
                ),

                new TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Enter Number Of Axles',
                    labelText: 'Number Of Axles',
                    hintStyle: TextStyle(color: Colors.grey),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.red,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff07426A),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),

                  controller: CollateralVehicleMasterState.collateralVehicleBean.mnoofaxles!= null&&CollateralVehicleMasterState.collateralVehicleBean.mnoofaxles!= 0
                      ? TextEditingController(text:CollateralVehicleMasterState.collateralVehicleBean.mnoofaxles.toString())
                      : TextEditingController(text:""),
                  keyboardType: TextInputType.number,
                  onSaved: (val) {
                    if(val!=null&&val!="") {

                      try{
                        CollateralVehicleMasterState.collateralVehicleBean.mnoofaxles= int.parse(val);
                      }catch(e){

                      }
                    }
                    else{
                      CollateralVehicleMasterState.collateralVehicleBean.mnoofaxles = 0;
                    }
                  },
                ),


                Container(
                      color: Constant.semiMandatoryColor,
                    child:
                new TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Enter Number Of Cylinders',
                    labelText: 'Numbers Cylinders',
                    hintStyle: TextStyle(color: Colors.grey),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.red,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff07426A),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),

                  controller: CollateralVehicleMasterState.collateralVehicleBean.mnoofcylinder!= null&&CollateralVehicleMasterState.collateralVehicleBean.mnoofcylinder!= 0
                      ? TextEditingController(text:CollateralVehicleMasterState.collateralVehicleBean.mnoofcylinder.toString())
                      : TextEditingController(text:""),
                  keyboardType: TextInputType.number,
                  onSaved: (val) {
                    if(val!=null&&val!="") {

                      try{
                        CollateralVehicleMasterState.collateralVehicleBean.mnoofcylinder= int.parse(val);
                      }catch(e){

                      }

                    }
                    else{
                      CollateralVehicleMasterState.collateralVehicleBean.mnoofcylinder = 0;
                    }
                  },
                )),

                new TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Enter Size of cylinder',
                    labelText: 'Size of cylinder',
                    hintStyle: TextStyle(color: Colors.grey),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.red,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff07426A),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),

                  controller: CollateralVehicleMasterState.collateralVehicleBean.msizeofcylinder!= null&&CollateralVehicleMasterState.collateralVehicleBean.msizeofcylinder!= 0
                      ? TextEditingController(text:CollateralVehicleMasterState.collateralVehicleBean.msizeofcylinder.toString())
                      : TextEditingController(text:""),
                  keyboardType: TextInputType.number,
                  onSaved: (val) {
                    if(val!=null&&val!="") {

                      try{
                        CollateralVehicleMasterState.collateralVehicleBean.msizeofcylinder= int.parse(val);
                      }catch(e){

                      }

                    }
                    else{
                      CollateralVehicleMasterState.collateralVehicleBean.msizeofcylinder = 0;
                    }
                  },
                ),

                Container(
                  child: new TextFormField(

                    decoration: const InputDecoration(
                      hintText: 'Enter Engine Power',
                      labelText: 'Engine Power',
                      hintStyle: TextStyle(color: Colors.grey),
                      labelStyle: TextStyle(color: Colors.grey),
                      border: UnderlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.black,
                          )),
                      focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xff07426A),
                          )),
                      contentPadding: EdgeInsets.all(20.0),
                    ),
                    keyboardType: TextInputType.numberWithOptions(),
                    controller:CollateralVehicleMasterState.collateralVehicleBean.menginepower == null
                        ? TextEditingController(text: "")
                        : TextEditingController(
                        text: CollateralVehicleMasterState.collateralVehicleBean.menginepower.toString()),
                    inputFormatters: [
                      globals.onlyDoubleNumber
                    ],
                    onSaved: (val) {
                      if (val != null && val != "") {
                        globals.income = double.parse(val);
                        CollateralVehicleMasterState.collateralVehicleBean.menginepower =
                            double.parse(val);
                      } else {
                        CollateralVehicleMasterState.collateralVehicleBean.menginepower = null;
                      }
                    },
                  ),
                ),
                new TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Enter Year Made',
                    labelText: 'Year Made',
                    hintStyle: TextStyle(color: Colors.grey),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.red,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff07426A),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),

                  controller: CollateralVehicleMasterState.collateralVehicleBean.myearmade!= null&&CollateralVehicleMasterState.collateralVehicleBean.myearmade!= 0
                      ? TextEditingController(text:CollateralVehicleMasterState.collateralVehicleBean.myearmade.toString())
                      : TextEditingController(text:""),
                  keyboardType: TextInputType.number,
                  onSaved: (val) {
                    if(val!=null&&val!="") {

                      try{
                        CollateralVehicleMasterState.collateralVehicleBean.myearmade= int.parse(val);
                      }catch(e){

                      }
                    }
                    else{
                      CollateralVehicleMasterState.collateralVehicleBean.myearmade = 0;
                    }
                  },
                ),
                Container(
                    color: Constant.semiMandatoryColor,
                    child:
                new TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Enter Car No',
                    labelText: 'Car No',
                    hintStyle: TextStyle(color: Colors.grey),
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.red,
                        )),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0xff07426A),
                        )),
                    contentPadding: EdgeInsets.all(20.0),
                  ),

                  controller: CollateralVehicleMasterState.collateralVehicleBean.midentitycarno!= null&&CollateralVehicleMasterState.collateralVehicleBean.midentitycarno!= 0
                      ? TextEditingController(text:CollateralVehicleMasterState.collateralVehicleBean.midentitycarno.toString())
                      : TextEditingController(text:""),
                  keyboardType: TextInputType.text,
                  onSaved: (val) {
                    if(val!=null&&val!="") {

                      try{
                        CollateralVehicleMasterState.collateralVehicleBean.midentitycarno= (val);
                      }catch(e){

                      }

                    }
                  },
                )),






              ],
            ),
          ),
        ],
      ),
    );

  }


}


