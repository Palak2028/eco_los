class BaseBean{
   DateTime mcreateddt;
   String mcreatedby;
   DateTime mlastupdatedt;
   String mlastupdateby;
   String mgeolocation;
   String mgeolatd;
   String mgeologd;
   String missync;
   DateTime mlastsynsdate;
}